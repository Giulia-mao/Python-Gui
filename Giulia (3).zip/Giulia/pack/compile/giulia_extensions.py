from pack.compile.giulia_interpreter import GiuliaInterpreter
from pack.compile.giulia_stdlib import stdlib

class ExtendedGiuliaInterpreter(GiuliaInterpreter):
    def __init__(self):
        super().__init__()
        self.setup_extensions()
        self.symbol_table = {}
        self.output = []
        self.errors = []
    
    def interpret(self, code):
        """基础解释器功能"""
        from pack.compile.giulia_interpreter import compile_giulia
        return compile_giulia(code), ""
    
    def setup_extensions(self):
        # 添加模块支持
        self.modules.update(stdlib)
        
        # 添加继承支持
        self.setup_inheritance()
    
    def setup_inheritance(self):
        # 在visit_class方法中处理继承
        pass
    
    def visit_import(self, node):
        module_name = node.children[0].value.strip('"\'')
        if module_name in self.modules:
            module = self.modules[module_name]
            if len(node.children) > 1:  # import as
                alias = node.children[1].value
                self.current_symbols.set(alias, module)
            else:
                # 导入所有公共成员
                for name in dir(module):
                    if not name.startswith('_'):
                        self.current_symbols.set(name, getattr(module, name))
        else:
            raise Exception(f"Module '{module_name}' not found")
    
    def visit_class(self, node):
        if len(node.children) == 3:  # 有继承
            class_name = node.children[0].value
            parent_name = node.children[1].value
            class_members = node.children[2]
            
            parent_class = self.classes.get(parent_name)
            if not parent_class:
                raise Exception(f"Parent class '{parent_name}' not found")
            
            # 创建新类，继承父类
            class_dict = parent_class.copy()
        else:
            class_name = node.children[0].value
            class_members = node.children[1]
            class_dict = {}
        
        # 处理类成员（覆盖或新增）
        old_symbols = self.current_symbols
        self.current_symbols = SymbolTable(parent=old_symbols)
        
        for member in class_members.children:
            if member.type == 'function':
                method_name = member.children[0].value
                self.visit(member)
                class_dict[method_name] = self.current_symbols.get(method_name)
            elif member.type == 'var_decl':
                var_name = member.children[1].value if len(member.children) == 3 else member.children[0].value
                value = self.visit(member.children[-1])
                class_dict[var_name] = value
        
        self.classes[class_name] = class_dict
        self.current_symbols = old_symbols
        return class_dict
    
    def visit_new(self, node):
        class_name = node.children[0].value
        class_dict = self.classes.get(class_name)
        
        if not class_dict:
            raise Exception(f"Class '{class_name}' not defined")
        
        # 创建实例
        instance = {'__class__': class_name}
        instance.update(class_dict)
        
        # 调用构造函数（如果存在）
        if 'constructor' in instance and callable(instance['constructor']):
            args = self.visit(node.children[1])
            instance['constructor'](*(args.children if args else []))
        
        return instance
    
    def visit_method_call(self, node):
        instance = self.visit(node.children[0])
        method_name = node.children[1].value
        args = self.visit(node.children[2])
        
        if method_name not in instance:
            raise Exception(f"Method '{method_name}' not found in class '{instance.get('__class__', 'unknown')}'")
        
        method = instance[method_name]
        if not callable(method):
            raise Exception(f"'{method_name}' is not a method")
        
        return method(*(args.children if args else []))

def run_extended_giulia(code):
    interpreter = ExtendedGiuliaInterpreter()
    return interpreter.interpret(code)