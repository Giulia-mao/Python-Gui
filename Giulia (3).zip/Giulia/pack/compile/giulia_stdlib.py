# Giulia 标准库

class GiuliaMath:
    @staticmethod
    def sqrt(x):
        return x ** 0.5
    
    @staticmethod
    def pow(x, y):
        return x ** y
    
    @staticmethod
    def abs(x):
        return abs(x)

class GiuliaString:
    @staticmethod
    def split(s, delimiter):
        return s.split(delimiter)
    
    @staticmethod
    def join(arr, delimiter):
        return delimiter.join(str(x) for x in arr)
    
    @staticmethod
    def upper(s):
        return s.upper()
    
    @staticmethod
    def lower(s):
        return s.lower()

# 内置模块
stdlib = {
    'math': GiuliaMath,
    'string': GiuliaString
}