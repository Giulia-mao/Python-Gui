# Giulia/pack/compile/giulia_tokens.py
# 完整的令牌定义

tokens = (
    # 数据类型
    'NUMBER', 'STRING', 'IDENTIFIER',
    
    # 运算符
    'PLUS', 'MINUS', 'TIMES', 'DIVIDE', 'MODULO',
    'EQ', 'NEQ', 'LT', 'LE', 'GT', 'GE',
    'AND', 'OR', 'NOT',
    
    # 赋值和符号
    'ASSIGN', 'LPAREN', 'RPAREN', 'LBRACE', 'RBRACE',
    'COMMA', 'SEMICOLON'
)

# 保留关键字（确保所有在语法中使用的关键字都包含）
reserved = {
    'print': 'PRINT',
    'if': 'IF',
    'else': 'ELSE', 
    'while': 'WHILE',
    'for': 'FOR',
    'function': 'FUNCTION',
    'return': 'RETURN',
    'true': 'TRUE',
    'false': 'FALSE',
    'null': 'NULL',
    'int': 'INT_TYPE',
    'float': 'FLOAT_TYPE',
    'string': 'STRING_TYPE',
    'bool': 'BOOL_TYPE',
    'void': 'VOID',
    'var': 'VAR'
}

# 合并令牌列表
tokens = tokens + tuple(reserved.values())