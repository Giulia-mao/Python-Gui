from pack.compile.giulia_parser import parser

class GiuliaInterpreter:
    def __init__(self):
        self.symbol_table = {}
        self.functions = {}  # 存储函数定义
        self.output = []
        self.errors = []
        self.return_value = None
        self.should_return = False
    
    def interpret(self, code):
        """解释执行Giulia代码"""
        self.symbol_table = {}
        self.functions = {}
        self.output = []
        self.errors = []
        self.return_value = None
        self.should_return = False
        
        try:
            # 语法分析
            ast = parser.parse(code)
            
            if ast:
                result = self.execute(ast)
                output_text = "\n".join(self.output)
                return output_text, ""
            else:
                return "", "语法分析失败"
                
        except Exception as e:
            error_msg = f"错误: {str(e)}"
            return "", error_msg
    
    def execute(self, node):
        if node is None:
            return None
        
        node_type = node[0]
        
        if node_type == 'program':
            return self.execute_program(node)
        elif node_type == 'block':  # 确保有对 'block' 的处理
            return self.execute_block(node)

        elif node_type == 'var_decl':
            return self.execute_var_decl(node)
        elif node_type == 'function':
            return self.execute_function_decl(node)
        elif node_type == 'print':
            return self.execute_print(node)
        elif node_type == 'if':
            return self.execute_if(node)
        elif node_type == 'while':
            return self.execute_while(node)
        elif node_type == 'return':
            return self.execute_return(node)
        elif node_type == 'assign':
            return self.execute_assign(node)
        elif node_type == 'call':
            return self.execute_call(node)
        elif node_type == 'binary':
            return self.execute_binary(node)
        elif node_type == 'unary':
            return self.execute_unary(node)
        elif node_type == 'literal':
            return node[1]
        elif node_type == 'empty':
            return None
        else:
            # 如果是标识符，从符号表中查找
            if isinstance(node, str):
                return self.symbol_table.get(node, None)
            return node
    
    def execute_program(self, node):
        statements = node[1]
        result = None
        for stmt in statements:
            result = self.execute(stmt)
            if self.should_return:
                break
        return result
    
    def execute_block(self, node):
        statements = node[1]
        old_table = self.symbol_table.copy()
        result = None
        
        for stmt in statements:
            result = self.execute(stmt)
            if self.should_return:
                break
        
        self.symbol_table = old_table
        return result
    
    def execute_var_decl(self, node):
        var_name, value_expr = node[1], node[2]
        value = self.execute(value_expr) if value_expr is not None else None
        self.symbol_table[var_name] = value
        return value
    
    def execute_function_decl(self, node):
        func_name, params, body = node[1], node[2], node[3]
        self.functions[func_name] = {
            'params': params,
            'body': body
        }
        return None
    
    def execute_print(self, node):
        value = self.execute(node[1])
        output = str(value)
        self.output.append(output)
        print(output)  # 同时在控制台输出
        return None
    
    def execute_if(self, node):
        condition, true_block, false_block = node[1], node[2], node[3]
        condition_value = self.execute(condition)
        
        if condition_value:
            return self.execute(true_block)
        elif false_block:
            return self.execute(false_block)
        return None
    
    def execute_while(self, node):
        condition, body = node[1], node[2]
        result = None
        
        while self.execute(condition):
            result = self.execute(body)
            if self.should_return:
                break
        
        return result
    
    def execute_return(self, node):
        value = self.execute(node[1]) if node[1] is not None else None
        self.return_value = value
        self.should_return = True
        return value
    
    def execute_assign(self, node):
        var_name, value_expr = node[1], node[2]
        value = self.execute(value_expr)
        self.symbol_table[var_name] = value
        return value
    
    def execute_call(self, node):
        func_name, args = node[1], node[2]
        
        # 内置函数
        if func_name == 'print':
            values = [self.execute(arg) for arg in args]
            output = ' '.join(str(v) for v in values)
            self.output.append(output)
            print(output)
            return None
        
        # 用户定义函数
        if func_name not in self.functions:
            raise Exception(f"函数 '{func_name}' 未定义")
        
        func = self.functions[func_name]
        old_table = self.symbol_table.copy()
        old_return = self.return_value
        old_should_return = self.should_return
        
        # 设置参数
        arg_values = [self.execute(arg) for arg in args]
        for i, param in enumerate(func['params']):
            if i < len(arg_values):
                self.symbol_table[param] = arg_values[i]
        
        # 执行函数体
        self.return_value = None
        self.should_return = False
        result = self.execute(func['body'])
        
        # 恢复状态
        return_value = self.return_value
        self.symbol_table = old_table
        self.return_value = old_return
        self.should_return = old_should_return
        
        return return_value if self.should_return else result
    
    def execute_binary(self, node):
        op, left, right = node[1], node[2], node[3]
        left_val = self.execute(left)
        right_val = self.execute(right)
        
        if op == '+':
            return left_val + right_val
        elif op == '-':
            return left_val - right_val
        elif op == '*':
            return left_val * right_val
        elif op == '/':
            if right_val == 0:
                raise Exception("除零错误")
            return left_val / right_val
        elif op == '%':
            return left_val % right_val
        elif op == '==':
            return left_val == right_val
        elif op == '!=':
            return left_val != right_val
        elif op == '<':
            return left_val < right_val
        elif op == '<=':
            return left_val <= right_val
        elif op == '>':
            return left_val > right_val
        elif op == '>=':
            return left_val >= right_val
        elif op == '&&':
            return bool(left_val) and bool(right_val)
        elif op == '||':
            return bool(left_val) or bool(right_val)
        else:
            raise Exception(f"未知运算符: {op}")
    
    def execute_unary(self, node):
        op, expr = node[1], node[2]
        value = self.execute(expr)
        
        if op == '-':
            return -value
        elif op == '!':
            return not value
        else:
            raise Exception(f"未知一元运算符: {op}")

def compile_giulia(code):
    """编译Giulia代码并返回结果"""
    interpreter = GiuliaInterpreter()
    output, errors = interpreter.interpret(code)
    return errors if errors else output

def run_giulia_code(code):
    return compile_giulia(code)