import ply.yacc as yacc
from pack.compile.giulia_lexer import tokens, lexer

# 优先级定义
precedence = (
    ('left', 'OR'),
    ('left', 'AND'),
    ('left', 'EQ', 'NEQ'),
    ('left', 'LT', 'LE', 'GT', 'GE'),
    ('left', 'PLUS', 'MINUS'),
    ('left', 'TIMES', 'DIVIDE', 'MODULO'),
    ('right', 'NOT', 'UMINUS'),
)

def p_program(p):
    '''program : statements'''
    p[0] = ('program', p[1])

def p_statements(p):
    '''statements : statement
                  | statements statement'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_statement(p):
    '''statement : expression SEMICOLON
                 | print_statement SEMICOLON
                 | variable_declaration SEMICOLON
                 | function_declaration
                 | if_statement
                 | while_statement
                 | return_statement SEMICOLON
                 | SEMICOLON'''
    if len(p) == 3:
        p[0] = p[1]
    else:
        p[0] = ('empty',)

def p_variable_declaration(p):
    '''variable_declaration : VAR IDENTIFIER ASSIGN expression
                            | VAR IDENTIFIER'''
    if len(p) == 5:
        p[0] = ('var_decl', p[2], p[4])
    else:
        p[0] = ('var_decl', p[2], None)

def p_function_declaration(p):
    '''function_declaration : FUNCTION IDENTIFIER LPAREN parameter_list RPAREN block_statement
                            | FUNCTION IDENTIFIER LPAREN RPAREN block_statement'''
    if len(p) == 7:
        p[0] = ('function', p[2], p[4], p[6])
    else:
        p[0] = ('function', p[2], [], p[5])

def p_parameter_list(p):
    '''parameter_list : IDENTIFIER
                      | parameter_list COMMA IDENTIFIER'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_return_statement(p):
    '''return_statement : RETURN expression
                        | RETURN'''
    if len(p) == 3:
        p[0] = ('return', p[2])
    else:
        p[0] = ('return', None)

def p_block_statement(p):
    '''block_statement : LBRACE statements RBRACE'''
    p[0] = ('block', p[2])

def p_print_statement(p):
    '''print_statement : PRINT LPAREN expression RPAREN'''
    p[0] = ('print', p[3])

def p_if_statement(p):
    '''if_statement : IF LPAREN expression RPAREN statement
                    | IF LPAREN expression RPAREN block_statement
                    | IF LPAREN expression RPAREN statement ELSE statement
                    | IF LPAREN expression RPAREN block_statement ELSE statement
                    | IF LPAREN expression RPAREN statement ELSE block_statement
                    | IF LPAREN expression RPAREN block_statement ELSE block_statement'''
    if len(p) == 6:
        p[0] = ('if', p[3], p[5], None)
    else:
        p[0] = ('if', p[3], p[5], p[7])

def p_while_statement(p):
    '''while_statement : WHILE LPAREN expression RPAREN statement
                       | WHILE LPAREN expression RPAREN block_statement'''
    p[0] = ('while', p[3], p[5])

def p_expression(p):
    '''expression : assignment_expression
                  | logical_expression'''
    p[0] = p[1]

def p_assignment_expression(p):
    '''assignment_expression : IDENTIFIER ASSIGN expression
                             | logical_expression'''
    if len(p) == 4:
        p[0] = ('assign', p[1], p[3])
    else:
        p[0] = p[1]

def p_logical_expression(p):
    '''logical_expression : equality_expression
                          | logical_expression AND equality_expression
                          | logical_expression OR equality_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('binary', p[2], p[1], p[3])

def p_equality_expression(p):
    '''equality_expression : relational_expression
                           | equality_expression EQ relational_expression
                           | equality_expression NEQ relational_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('binary', p[2], p[1], p[3])

def p_relational_expression(p):
    '''relational_expression : additive_expression
                             | relational_expression LT additive_expression
                             | relational_expression LE additive_expression
                             | relational_expression GT additive_expression
                             | relational_expression GE additive_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('binary', p[2], p[1], p[3])

def p_additive_expression(p):
    '''additive_expression : multiplicative_expression
                           | additive_expression PLUS multiplicative_expression
                           | additive_expression MINUS multiplicative_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('binary', p[2], p[1], p[3])

def p_multiplicative_expression(p):
    '''multiplicative_expression : unary_expression
                                 | multiplicative_expression TIMES unary_expression
                                 | multiplicative_expression DIVIDE unary_expression
                                 | multiplicative_expression MODULO unary_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('binary', p[2], p[1], p[3])

def p_unary_expression(p):
    '''unary_expression : primary_expression
                        | MINUS unary_expression %prec UMINUS
                        | NOT unary_expression'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = ('unary', p[1], p[2])

def p_primary_expression(p):
    '''primary_expression : literal
                          | IDENTIFIER
                          | function_call
                          | LPAREN expression RPAREN'''
    if len(p) == 2:
        p[0] = p[1]
    else:
        p[0] = p[2]

def p_function_call(p):
    '''function_call : IDENTIFIER LPAREN argument_list RPAREN
                     | IDENTIFIER LPAREN RPAREN'''
    if len(p) == 5:
        p[0] = ('call', p[1], p[3])
    else:
        p[0] = ('call', p[1], [])

def p_argument_list(p):
    '''argument_list : expression
                     | argument_list COMMA expression'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[3]]

def p_literal(p):
    '''literal : NUMBER
               | STRING
               | TRUE
               | FALSE
               | NULL'''
    p[0] = ('literal', p[1])

def p_error(p):
    if p:
        print(f"第{p.lineno}行: 语法错误，意外的 '{p.value}'")
    else:
        print("语法错误: 意外的文件结束")

# 构建语法分析器
parser = yacc.yacc()