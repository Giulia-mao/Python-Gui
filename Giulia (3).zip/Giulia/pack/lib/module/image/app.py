from PySide6.QtWidgets import QApplication, QToolButton, QVBoxLayout, QWidget
from PySide6.QtGui import QMovie, QIcon
from PySide6.QtCore import Qt

class AnimatedIconButton(QToolButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 加载动画GIF
        self.movie = QMovie(r"C:\Users\Administrator\Desktop\GIF.gif")  # 替换为你的GIF文件路径
        self.movie.frameChanged.connect(self.update_icon)
        
        # 设置按钮初始状态
        self.setFixedSize(180, 40)
        self.setIconSize(self.size())
        
    def update_icon(self):
        self.setIcon(QIcon(self.movie))
        
    def start_animation(self):
        self.movie.start()
        
    def stop_animation(self):
        self.movie.stop()

app = QApplication([])

window = QWidget()
layout = QVBoxLayout()

btn = AnimatedIconButton()
btn.setText("搜索")
layout.addWidget(btn)

# 点击按钮开始/停止动画
btn.clicked.connect(lambda: btn.start_animation() if not btn.movie.state() else btn.stop_animation())

window.setLayout(layout)
window.show()
app.exec()