from pack.lib.module.physics.core.gui.QtPack import *

class MainWindow(QMainWindow):
    def __init__ (self,parent : QWidget = None, title : str = "MainWindow", width : int = 800, height : int = 600):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(width, height)
        
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                QMainWindow {{
                    background-color : #121212;
                    color: white;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QMainWindow {{
                    background-color : #f0f0f0;
                    color: black;
                }}
            """)


class Button(QPushButton):
    def __init__ (self, content="", parent : QWidget = None, border_width : int = 1, border_radius : int = 4):
        """
        自定义按钮类，继承自QPushButton，支持边框和圆角设置。
        
        Args:
            content: 按钮显示的文本内容
            parent: 父组件
            border_width: 边框宽度
            border_radius: 边框圆角半径
        """
        super().__init__(str(content), parent)
        self.border_width = border_width
        self.border_radius = border_radius

        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color : rgba(0,0,0,190);
                    color: white;
                    border-radius: 0px;
                }}
                QPushButton:hover {{
                    background-color:rgba(25,25,25,160);
                }}
                QPushButton:pressed {{
                    background-color: rgba(0,102,255,120);
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QPushButton {{
                    background-color : #dedede;
                    color: black;
                    border: 0px solid black;
                    border-radius: 0px;
                }}
                QPushButton:hover {{
                    background-color: rgba(104,164,255,160);
                }}
                QPushButton:pressed {{
                    background-color: rgba(0,102,255,120);
                }}
            """)


class ToolButton(QToolButton):
    def __init__ (self, content="", parent : QWidget = None, border_width : int = 1, border_radius : int = 4):
        """
        自定义工具按钮类，继承自QToolButton，支持边框和圆角设置。
        
        Args:
            content: 按钮显示的文本内容
            parent: 父组件
            border_width: 边框宽度
            border_radius: 边框圆角半径
        """
        super().__init__(parent)
        self.setText(str(content))
        self.border_width = border_width
        self.border_radius = border_radius


        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                QToolButton {{
                    background-color : rgba(0,0,0,190);
                    color: white;
                    border-radius: 0px;
                }}
                QToolButton:hover {{
                    background-color: rgba(0,0,0,160);
                }}
                QToolButton:pressed {{
                    background-color: rgba(0,102,255,120);
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QToolButton {{
                    background-color : #f0f0f0;
                    color: black;
                    border-radius: 0px;
                }}
                QToolButton:hover {{
                    background-color: lightgray;
                }}
                QToolButton:pressed {{
                    background-color: gray;
                }}
            """)
class ComboBox(QComboBox):
    def __init__(self, parent=None, border_radius: int = 4,font_size : int = 13):
        super().__init__(parent)
        self.font_size = font_size
        self.border_radius = border_radius
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        self._arrow_color = QColor()
        
        # Customize the combobox appearance
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        
        # Set up color animation
        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(200)
        self._animation.setEasingCurve(QEasingCurve.Type.OutQuad)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # Dark mode colors
            self._default_color = QColor(0,0,0,190)
            self._border_color = QColor(0,0,0,0)
            self._top_border_color = QColor(0,0,0)
            self._hover_color = QColor(98,135,190,160)
            self._pressed_color = QColor(0,102,255,120)
            self._text_color = QColor(255,255,255)
            self._arrow_color = QColor(255,255,255)
            self._dropdown_bg = QColor(0,0,0)
            self._dropdown_text = QColor(255,255,255)
            self._dropdown_hover = QColor(66,66,66)
        else:
            # Light mode colors
            self._default_color = QColor(218,218,218)
            self._border_color = QColor(201,201,201)
            self._top_border_color = QColor(190,190,190)
            self._hover_color = QColor(200,200,200)
            self._pressed_color = QColor(185,185,185)
            self._text_color = QColor(0,0,0)
            self._arrow_color = QColor(0,0,0)
            self._dropdown_bg = QColor(255,255,255)
            self._dropdown_text = QColor(0,0,0)
            self._dropdown_hover = QColor(240,240,240)

        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """Update the combobox style sheet with custom arrow button borders"""
        style = f"""
        ComboBox {{
            font-size : {self.font_size}px;
            background-color: {self._bg_color.name()};
            border: 0px solid {self._border_color.name()};
            border-top: 0px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            border-radius: 0px;
            padding: 5px 10px;
            min-width: 100px;
            text-align: left;
        }}
        
        ComboBox:hover {{
            border-top: 0px solid {self._top_border_color.name()};
        }}
        
        ComboBox:pressed {{
            border-top: 0px solid {self._top_border_color.name()};
        }}
        
        /* Dropdown arrow button styling */
        ComboBox::drop-down {{
            subcontrol-origin: padding;
            subcontrol-position: center right;
            width: 20px;
            border-left: 0px solid {self._border_color.name()};
            border-top-right-radius: 0px;
            border-bottom-right-radius: 0px;
            background-color: transparent;
        }}
        
        /* Dropdown list styling */
        ComboBox QAbstractItemView {{
            background-color: {self._dropdown_bg.name()};
            color: {self._dropdown_text.name()};
            border: 1px solid {self._border_color.name()};
            border-radius: 0px;
            selection-background-color: {self._dropdown_hover.name()};
            selection-color: {self._dropdown_text.name()};
            outline: none;
        }}
        
        ComboBox QAbstractItemView::item {{
            padding: 6px 10px;
        }}
        
        ComboBox QAbstractItemView::item:hover {{
            background-color: {self._dropdown_hover.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def paintEvent(self, event):
        # First paint the default combobox
        super().paintEvent(event)
        
        # Then draw our custom arrow
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get the arrow button rectangle
        opt = QStyleOptionComboBox()
        self.initStyleOption(opt)
        arrow_rect = self.style().subControlRect(
            QStyle.CC_ComboBox, 
            opt, 
            QStyle.SC_ComboBoxArrow,
            self
        )
        
        # Draw the arrow
        painter.setPen(QPen(self._arrow_color, 1.5))
        
        # Calculate arrow points (downward pointing triangle)
        arrow_size = 4
        center = arrow_rect.center()
        top = QPoint(center.x() - arrow_size, center.y() - arrow_size//2)
        bottom = QPoint(center.x(), center.y() + arrow_size//2)
        right = QPoint(center.x() + arrow_size, center.y() - arrow_size//2)
        
        # Draw the arrow as a polygon
        arrow = QPolygon([top, bottom, right])
        painter.drawPolyline(arrow)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()

    def showPopup(self):
        self._animate_color(self._pressed_color)
        super().showPopup()
    
    def hidePopup(self):
        self._animate_color(self._hover_color if self.underMouse() else self._default_color)
        super().hidePopup()
class CheckBox(QCheckBox):
    def __init__(self, content="", parent: QWidget = None):
        super().__init__(str(content), parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                QCheckBox {{
                    color: white;
                }}
                QCheckBox::indicator {{
                    width: 15px;
                    height: 15px;
                    border: 1px solid white;
                    border-radius: 7.5px;
                    background-color: rgba(0,0,0,190);
                }}
                QCheckBox::indicator:hover {{
                    background-color: rgba(0,6,91,160);
                }}
                QCheckBox::indicator:pressed {{
                    background-color: rgba(0,0,0,120);
                }}
                QCheckBox::indicator:checked {{
                    background-color: #0078d7;
                    border: 1px solid #0078d7;
                }}
                QCheckBox::indicator:checked:hover {{
                    background-color: #005a9e;
                    border: 1px solid #005a9e;
                }}
                QCheckBox::indicator:checked:pressed {{
                    background-color: #004578;
                    border: 1px solid #004578;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QCheckBox {{
                    color: black;
                }}
                QCheckBox::indicator {{
                    width: 15px;
                    height: 15px;
                    border: 1px solid black;
                    border-radius: 7.5px;
                    background-color: white;
                }}
                QCheckBox::indicator:hover {{
                    background-color: lightgray;
                }}
                QCheckBox::indicator:pressed {{
                    background-color: gray;
                }}
                QCheckBox::indicator:checked {{
                    background-color: #0078d7;
                    border: 1px solid #0078d7;
                }}
                QCheckBox::indicator:checked:hover {{
                    background-color: #005a9e;
                    border: 1px solid #005a9e;
                }}
                QCheckBox::indicator:checked:pressed {{
                    background-color: #004578;
                    border: 1px solid #004578;
                }}
            """)
class Separator(QFrame):
    def __init__ (self, parent : QWidget = None):
        super().__init__(parent)
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Sunken)
        self.setObjectName("Separator")
        style = """
        Separator#Separator {{
            background-color: transparent;
        }}
        """
        self.setStyleSheet(style)
        self.setFixedHeight(2)
class ControlList(QWidget):
    def __init__(self, parent=None,border_radius : int = 0,border_width : int = 0):
        super().__init__(parent)
        self.border_radius = border_radius
        self.border_width = border_width
        self.initUI()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.setStyleSheet(f"""

                ControlList{{
                    background-color : rgba(0,0,0,190);
                    border-color : rgba(0,0,0,190);
                    border-style : solid;
                    border-width : {self.border_width}px;
                    border-radius : {self.border_radius}px;
                }}
                ControlList::scroll-bar:vertical,
                ControlList::scroll-bar:horizontal {{
                    width: 0;
                    height: 0;
                    background: transparent;
                }}
            """)
            self.button_container.setStyleSheet(f"""

                QWidget{{
                    background-color : rgba(0,0,0,190);
                    border-color : rgba(0,0,0,190);
                    border-style : solid;
                    border-width : {self.border_width}px;
                    border-radius : {self.border_radius}px;
                }}
                QWidget::scroll-bar:vertical,
                QWidget::scroll-bar:horizontal {{
                    width: 0;
                    height: 0;
                    background: transparent;
                }}
            """)
        else:
            self.setStyleSheet(
                f"""
                ControlList{{
                    background-color : rgba(225,225,225,180);
                    border-color : rgba(225,225,225,180);
                    border-style : solid;
                    border-radius : {self.border_radius}px;

                    border-width : {self.border_width}px;
                }}
            """
            )
            self.button_container.setStyleSheet(
                f"""
                QWidget{{
                    background-color : rgba(225,225,225,180);
                    border-color : rgba(225,225,225,180);
                    border-style : solid;
                    border-radius : {self.border_radius}px;

                    border-width : {self.border_width}px;
                }}
            """
            )
    def initUI(self):
        # 主布局
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # 创建可滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # 禁用水平滚动条
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)    # 需要时显示垂直滚动条
        self.scroll_area.setStyleSheet("QScrollArea { border: none; }")

        # 创建包含按钮的容器
        self.button_container = QWidget()
        # self.button_container.setStyleSheet("background: red;")
        self.button_layout = QVBoxLayout(self.button_container)
        self.button_layout.setContentsMargins(0,0, 0, 0)
        self.button_layout.setSpacing(0)
        
        self.button_layout.setAlignment(Qt.AlignTop)  # 按钮从顶部开始排列
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 隐藏水平滚动条
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 将容器设置为滚动区域的子部件
        self.scroll_area.setWidget(self.button_container)
        
        # 将滚动区域添加到主布局
        self.main_layout.addWidget(self.scroll_area)

        # 设置示例按钮（实际使用时可以动态添加）
    def addSeparator(self):
        """动态添加分割线"""
        separator = Separator(self)
        self.button_layout.addWidget(separator)
        
    def addControl(self, widget: QWidget):
        """动态添加控件"""
        self.button_layout.addWidget(widget)

    def clearControls(self):
        """清除所有按钮"""
        while self.button_layout.count():
            item = self.button_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
class ControlFrame(QFrame):
    def __init__ (self, parent : QWidget = None, border_radius : int = 0):
        super().__init__(parent)
        self.border_radius = border_radius
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.setMinimumHeight(30)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                ControlFrame{{
                    background-color : rgba(0,0,0,190);
                    border-color : rgba(0,0,0,190);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : {self.border_radius}px;
                }}
                ControlFrame:hover{{
                    background-color : rgba(0,0,0,190);
                    border-color : rgba(50,50,50,190);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : {self.border_radius}px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                ControlFrame{{
                    background-color : rgba(225,225,225,180);
                    border-color : rgba(225,225,225,180);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : {self.border_radius}px;
                }}
                ControlFrame:hover{{
                    background-color : rgba(225,225,225,180);
                    border-color : rgba(150,150,150,180);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : {self.border_radius}px;
                }}
            """)
class ControlWidget(QWidget):
    def __init__ (self, parent : QWidget = None):
        super().__init__(parent)
        self.update_colors()

        self.setAttribute(Qt.WA_StyledBackground, True)
        QApplication.instance().paletteChanged.connect(self.update_colors)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                ControlWidget{{
                    background-color : rgba(8,8,8,250);
                    border-color : rgba(8,8,8,250);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : 0px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                ControlWidget{{
                    background-color : rgba(225,225,225,180);
                    border-color : rgba(225,225,225,180);
                    border-style : solid;
                    border-width : 1px;
                    border-radius : 0px;
                }}
            """)
class Menu(QMenu):
    def __init__(self,title:str="",parent:QWidget=None)-> None:
        super().__init__(title,parent)
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            dark_theme = """
            QMenu {
                background-color: #2d2d30;
                border: 1px solid #3e3e42;
                color: #cccccc;
                border-radius: 4px;
            }

            QMenu::item {
                padding: 8px 20px;
            }

            QMenu::item:selected {
                background-color: #0078d4;
                color: white;
            }
            """
            self.setStyleSheet(dark_theme)
        else:
            light_theme = """
            QMenu {
                background-color: white;
                border: 1px solid #dcdfe6;
                color: #606266;
                margin: 0px;
                border-radius: 4px;
            }

            QMenu::item {
                padding: 8px 20px;
            }

            QMenu::item:selected {
                background-color: #ecf5ff;
                color: #409eff;
                border-radius: 4px
            }
            """
            self.setStyleSheet(light_theme)
class PushButton(QPushButton):
    def __init__(self,text:str="",parent:QWidget=None)-> None:
        super().__init__(text,parent)
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 浅色主题
            dark_icon_style = """
QPushButton {
    background-color: #2b2b2b;
    border: 1px solid #404040;
    border-radius: 6px;
    color: #ffffff;
    font-family: 'Segoe UI', system-ui;
    font-size: 13px;
    font-weight: 500;
    padding: 8px 16px;
    margin: 2px;
}

QPushButton:hover {
    background-color: #363636;
    border-color: #505050;
}

QPushButton:pressed {
    background-color: #404040;
    border-color: #606060;
}

QPushButton:disabled {
    background-color: #1f1f1f;
    border-color: #2a2a2a;
    color: #666666;
}

QPushButton:focus {
    border: 1px solid #4a90e2;
    outline: none;
}
"""

            self.setStyleSheet(dark_icon_style)
        else:
            light_icon_style = """
            QPushButton {
                background-color: #f5f5f5;
                border: 1px solid #e0e0e0;
                border-radius: 6px;
                color: #666666;
                font-family: 'Segoe UI', system-ui;
                font-size: 13px;
                padding: 8px 16px;
                min-height: 32px;
                min-width: 32px;
            }

            QPushButton:hover {
                background-color: #e8e8e8;
                border-color: #cccccc;
                color: #333333;
            }

            QPushButton:pressed {
                background-color: #dcdcdc;
                border-color: #bbbbbb;
            }

            QPushButton:disabled {
                background-color: #f9f9f9;
                border-color: #eeeeee;
                color: #bbbbbb;
            }
            """
            self.setStyleSheet(light_icon_style)
class MenuButton(Button):
    def __init__(self, content='', parent=None, border_radius=4, border_width: int = 1):
        """
        带菜单功能的按钮
        
        Args:
            content: 按钮显示的文本内容
            parent: 父组件
            border_radius: 边框圆角半径
            border_width: 边框宽度
        """
        super().__init__(str(content), parent, border_width=border_width, border_radius=border_radius)
        self.menu = None  # 初始化菜单对象
        self.clicked.connect(self._on_click)
    
    def _on_click(self):
        """按钮点击事件处理"""
        if not self.menu:
            self.menu = QMenu(self)
        
        # 计算菜单位置：按钮左下角偏移
        pos = self.mapToGlobal(QPoint(0, self.height()))
        self.menu.popup(pos)
    
    def add_action(self, text, on_click=None, icon=None, tool_tip=None):
        """
        添加菜单项
        
        Args:
            text: 菜单项文本
            on_click: 点击菜单项的回调函数
            icon: 菜单项图标
            tool_tip: 菜单项提示文本
        """
        if not self.menu:
            self.menu = Menu(self)
        
        action = QAction(text, self)
        
        if icon:
            action.setIcon(icon)
        
        if tool_tip:
            action.setToolTip(tool_tip)
        
        if on_click:
            action.triggered.connect(on_click)
        
        self.menu.addAction(action)
        return action
    
    def add_separator(self):
        """添加分隔线"""
        if not self.menu:
            self.menu = QMenu(self)
        
        self.menu.addSeparator()
    
    def clear_menu(self):
        """清空菜单"""
        if self.menu:
            self.menu.clear()
    
    def show_menu(self):
        """显示菜单"""
        if self.menu and not self.menu.isEmpty():
            pos = self.mapToGlobal(QPoint(0, self.height()))
            self.menu.popup(pos)
        
