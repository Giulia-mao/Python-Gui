from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtUiTools import *
from PySide6.QtSvg import *
from PySide6.QtOpenGLWidgets import *
from PySide6.QtOpenGL import *
from PySide6.QtNetwork import *