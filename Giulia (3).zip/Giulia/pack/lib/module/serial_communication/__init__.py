import serial
import serial.tools.list_ports


def list_com_ports():
    ports = serial.tools.list_ports.comports()
    port_list = [port.device for port in ports]

    return port_list

def monitor_com_port(port_name, baudrate=9600):
    try:
        ser = serial.Serial(port_name, baudrate, timeout=1)
        print(f"开始监听 {port_name}，波特率 {baudrate}...")
        
        while True:
            if ser.in_waiting > 0:  # 检查是否有数据可读
                data = ser.readline().decode('utf-8').strip()  # 读取一行数据并解码
                print(f"收到数据: {data}")
    
    except serial.SerialException as e:
        print(f"串口错误: {e}")
    except KeyboardInterrupt:
        print("\n停止监听...")
        ser.close()

print(list_com_ports())