from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.opacity import *
from pack.lib.module.gui.widget import *
from pack.lib.module.gui.shadow import *
from pack.lib.module.gui.button import *

class PopWidget_Msg(QFrame):
    def __init__(self, parent: QWidget = None, title : str = "", width: int = 400, height: int = 210,close_button : bool = True):
        super().__init__(parent)
        self.setStyleSheet("""
            background-color: #000000;
            border-radius: 5px;
        """)
        self.titleb = title
        self.parentc = parent
        self.widthc = width
        self.heightc = height
        self.widthcs = self.parent().width()
        self.heightcs = self.parent().height()
        self.backsw = False
        self.close_button = close_button
        self.animSw = False
        self.animation_started = False  # 添加动画启动标志
        # anim
        self.opacity = Opacity.GraphicsOpacityEffect(self, 0)
        self.opacity_anim = Opacity.GraphicsOpacityEffect_Anim(self, self.opacity, 0, 0.5, Duration=500, EasingCurve=QEasingCurve.Type.OutCubic)
        self.opacity_anim.start()
        # gui
        self._init_gui__()
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)



    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.shadow_color = Qt.black
        else:
            self.shadow_color = Qt.gray

    
    
    def _init_gui__(self):
        self.widget = QFrame(self.parentc)
        self.widget.resize(self.widthc, self.heightc)
        # 设置初始位置（从底部开始）
        start_y = self.heightcs
        self.widget.setGeometry(QRect(
            self.widthcs//2 - self.widthc//2, 
            start_y,
            self.widthc, 
            self.heightc
        ))
        self.widget.show()
        
        # 保存为实例变量
        self.widget_opacity = Opacity.GraphicsOpacityEffect(self.widget, 0)
        self.widget.setGraphicsEffect(self.widget_opacity)  # 必须设置效果
        
        self.widget_opacity_anim = Opacity.GraphicsOpacityEffect_Anim(self.widget, self.widget_opacity, 0, 1, Duration=450)
        self.widget_opacity_anim.start()
        self.widget_opacity_anim.finished.connect(lambda: Shadow.Show(self.widget, QColor("#111111"), r=20, dy=5))

        # 给self.widget一个内置控件
        

        self.layoutc = QVBoxLayout(self.widget)
        self.layoutc.setContentsMargins(0, 0, 0, 0)
        self.layoutc.setSpacing(0)
        self.layoutc.setAlignment(Qt.AlignTop)

        # 状态栏
        self.status_bar = QWidget(self.widget)
        self.status_bar.setFixedHeight(35)
        self.status_bar.setStyleSheet("""
           background-color: #3a3a3a;   
           border-width : 0px;                      
        """)
        self.status_bar_layout = QHBoxLayout(self.status_bar)
        self.status_bar_layout.setContentsMargins(10, 0, 10, 0)
        self.status_bar_layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.status_label = QLabel(self.titleb)
        self.status_label.setStyleSheet("color:white;")
        self.status_bar_layout.addWidget(self.status_label)
        self.status_bar_layout.addStretch()  # 添加弹性空间将按钮推到右侧
        
        stylec = [[QColor("#3a3a3a"),QColor("#ff8f8f"),QColor("#ff8f8f"),QColor("#ff8f8f"),QColor("#FFFFFF"),QColor("#ff2a2a")],
                 [QColor("#3a3a3a"),QColor("#ff8f8f"),QColor("#ff8f8f"),QColor("#ff8f8f"),QColor("#ffffff"),QColor("#ff2a2a")]
                ]
        if self.close_button == True:

            self.exit_button = StyleButton("x", None, border_width=0,border_radius=3,style=stylec)
            self.exit_button.setFixedSize(25, 25)
            self.status_bar_layout.addWidget(self.exit_button)

            self.exit_button.clicked.connect(self.__back__)
        else:
            pass
        self.layoutc.addWidget(self.status_bar)
        
        # 动画开关 
        self.animSw = True

    def addWidget(self,widget):
        self.layoutc.addWidget(widget)

    def isclose(self):
        self.__back__()
        return super().close()

    def __back__(self):
        self.backsw = True
        self.widget.deleteLater()

        # 背景渐变动画
        self.opacity_anim = Opacity.GraphicsOpacityEffect_Anim(
            self, self.opacity, self.opacity.opacity(), 0, Duration=420, EasingCurve=QEasingCurve.Type.OutExpo
        )
        self.opacity_anim.start()
        
        self.opacity_anim.finished.connect(self.deleteLater)

    def __anim_off__(self):
        self.animSw = False
        # 动画结束后确保widget居中
        self.keep_widget_centered()

    def keep_widget_centered(self):
        """确保widget持续居中"""
        if self.widget:
            center_x = self.parent().width()//2 - self.widthc//2
            center_y = self.parent().height()//2 - self.heightc//2
            self.widget.move(center_x, center_y)

    def paintEvent(self, event):
        self.setGeometry(self.parent().rect())
        # 更新父组件尺寸
        self.widthcs = self.parent().width()
        self.heightcs = self.parent().height()

        if self.animSw and not self.animation_started:
            # 只在第一次进入时启动动画
            self.animation_started = True
                
            # 获取当前Y位置
            current_y = self.widget.y()
            
            Start = QRect(
                self.widthcs//2 - self.widthc//2, 
                current_y,  # 使用当前Y位置
                self.widthc, 
                self.heightc
            )
            end = QRect(
                self.widthcs//2 - self.widthc//2, 
                self.heightcs//2 - self.heightc//2, 
                self.widthc, 
                self.heightc
            )
            
            self.animation = QPropertyAnimation(self.widget, b'geometry')
            self.animation.setStartValue(Start)
            self.animation.setEndValue(end)
            self.animation.setDuration(900)
            self.animation.setEasingCurve(QEasingCurve.Type.OutExpo)
            self.animation.finished.connect(self.__anim_off__)
            self.animation.start()
        elif not self.animSw:
            if self.backsw == False:

                # 动画结束后，持续保持居中
                self.keep_widget_centered()
            else:
                if self.backsw:
                    pass
        return super().paintEvent(event)

    def resizeEvent(self, event):
        """处理窗口大小变化时重新居中"""
        super().resizeEvent(event)
        if not self.animSw:  # 只有在动画结束后才重新居中
            if self.backsw == False:

                self.keep_widget_centered()
            else:
                if self.backsw:
                    pass