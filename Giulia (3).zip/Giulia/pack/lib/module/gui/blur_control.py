from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *
try:
    import numpy as np
    from scipy.ndimage import gaussian_filter
except ImportError:
    raise ImportError("This module requires numpy and scipy. Please install them using 'pip install numpy scipy'.")

class BlurringWidget(QLabel):
    def __init__(self, parent, Update_Frequency: int = 1000, blur: bool = False):
        super().__init__(parent)
        self.Refresh_on_Demand = False  # 修正原代码中的赋值错误
        self.Update_Frequency = Update_Frequency
        self.Blur = blur  # 添加Blur变量

        # 定时器刷新模式
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.capture_and_clear)
        self.timer.start(self.Update_Frequency)

    def apply_gaussian_blur(self, pixmap, radius=6):
        """应用高斯模糊效果"""
        if pixmap.isNull():
            return pixmap
            
        # 创建一个场景和视图来应用效果
        scene = QGraphicsScene()
        item = QGraphicsPixmapItem(pixmap)
        
        # 创建模糊效果并应用到项目
        blur_effect = QGraphicsBlurEffect()
        blur_effect.setBlurRadius(radius)
        item.setGraphicsEffect(blur_effect)
        
        scene.addItem(item)
        
        # 渲染模糊后的图像到新的pixmap
        blurred_pixmap = QPixmap(pixmap.size())
        blurred_pixmap.fill(Qt.transparent)
        
        painter = QPainter(blurred_pixmap)
        scene.render(painter)
        painter.end()
        
        return blurred_pixmap

    def capture_and_clear(self):
        """定时器刷新模式使用的更新方法"""
        if self.parent() is not None:
            # 获取并设置截图
            screenshot = self.parent().grab()
            rect = self.geometry()
            pixmap = screenshot.copy(rect)
            
            # 根据Blur变量决定是否应用模糊效果
            if self.Blur:
                pixmap = self.apply_gaussian_blur(pixmap)
                
            self.setPixmap(pixmap)
        
            # 清理并重新获取（原逻辑保留）
            self.clear()
            self.capture_internal_screenshot()

    def capture_internal_screenshot(self):
        """capture_and_clear方法的辅助函数"""
        if self.parent() is not None:
            screenshot = self.parent().grab()
            rect = self.geometry()
            pixmap = screenshot.copy(rect)
            
            # 根据Blur变量决定是否应用模糊效果
            if self.Blur:
                pixmap = self.apply_gaussian_blur(pixmap)
                
            self.setPixmap(pixmap)

    def setRefreshMode(self, on_demand: bool):
        """动态切换刷新模式"""
        if hasattr(self, 'timer'):
            self.timer.stop()
        
        self.Refresh_on_Demand = on_demand
        
        if not on_demand:
            if not hasattr(self, 'timer'):
                self.timer = QTimer(self)
            self.timer.timeout.connect(self.capture_and_clear)
            self.timer.start(self.Update_Frequency)
        elif self.parent():
            self.parent().installEventFilter(self)
class BlurringWidgetS(QLabel):
    """
    # Building a Blurring Widget with Dynamic Refresh and Gaussian Blur
    继承于BlurringWidget的优化版
    优化如下
    * 降低CPU功耗
    * 支持自定义模糊半径

    """
    def __init__(self, parent, update_frequency: int = 1000, blur: bool = False, blur_radius: int = 8):
        super().__init__(parent)
        self._refresh_on_demand = False
        self._update_frequency = update_frequency
        self._blur = blur
        self._blur_radius = blur_radius  # 可配置的模糊半径
        
        self._init_timer()

    def _init_timer(self):
        """初始化定时器"""
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_screenshot)
        self._timer.start(self._update_frequency)

    def _apply_gaussian_blur(self, pixmap):
        """高效应用高斯模糊"""
        if pixmap.isNull() or not self._blur:
            return pixmap
            
        scene = QGraphicsScene()
        item = QGraphicsPixmapItem(pixmap)
        
        blur_effect = QGraphicsBlurEffect()
        blur_effect.setBlurRadius(self._blur_radius)
        blur_effect.setBlurHints(QGraphicsBlurEffect.QualityHint)  # 优化质量
        item.setGraphicsEffect(blur_effect)
        
        scene.addItem(item)
        
        # 使用与源图像相同格式的QPixmap
        blurred_pixmap = QPixmap(pixmap.size())
        blurred_pixmap.fill(Qt.transparent)
        
        painter = QPainter(blurred_pixmap)
        scene.render(painter)
        painter.end()
        
        return blurred_pixmap

    def _capture_screenshot(self):
        """捕获并处理截图"""
        if not self.parent():
            return QPixmap()
            
        screenshot = self.parent().grab()
        rect = self.geometry()
        pixmap = screenshot.copy(rect)
        
        if self._blur:
            return self._apply_gaussian_blur(pixmap)
        return pixmap

    def _update_screenshot(self):
        """更新显示的截图"""
        pixmap = self._capture_screenshot()
        if not pixmap.isNull():
            self.setPixmap(pixmap)

    def set_refresh_mode(self, on_demand: bool):
        """动态切换刷新模式"""
        self._timer.stop() if self._timer.isActive() else None
        self._refresh_on_demand = on_demand
        
        if not on_demand:
            self._timer.start(self._update_frequency)
        else:
            self.parent().installEventFilter(self) if self.parent() else None

    # 属性封装
    @property
    def blur(self):
        return self._blur
        
    @blur.setter
    def blur(self, value: bool):
        if self._blur != value:
            self._blur = value
            self._update_screenshot()  # 立即更新以反映变化
            
    @property
    def blur_radius(self):
        return self._blur_radius
        
    @blur_radius.setter
    def blur_radius(self, value: int):
        if value > 0 and self._blur_radius != value:
            self._blur_radius = value
            if self._blur:
                self._update_screenshot()  # 仅在启用模糊时更新
                
    @property
    def update_frequency(self):
        return self._update_frequency
        
    @update_frequency.setter
    def update_frequency(self, value: int):
        if value > 0 and self._update_frequency != value:
            self._update_frequency = value
            if not self._refresh_on_demand:
                self._timer.setInterval(value)
class BlurringWidget_simplification(QLabel):
    """
    自动刷新的毛玻璃效果控件
    改进点：
    1. 保持自动刷新定时器
    2. 每次刷新前自动清除旧图像
    3. 优化内存管理
    4. 保留所有模糊效果功能
    """
    def __init__(self, parent, update_frequency: int = 1000, blur: bool = False, blur_radius: int = 8):
        super().__init__(parent)
        self._blur = blur
        self._blur_radius = blur_radius
        self._update_frequency = update_frequency
        self._timer = QTimer(self)
        
        # 初始化设置
        self.setAttribute(Qt.WA_TranslucentBackground)
        self._init_timer()

    def _init_timer(self):
        """初始化自动刷新定时器"""
        self._timer.timeout.connect(self._update_with_clear)
        self._timer.start(self._update_frequency)

    def _update_with_clear(self):
        """先清除旧图像再更新"""
        self.clear()  # 清除当前显示的图像
        self._update_screenshot()

    def _apply_glass_effect(self, pixmap):
        """应用毛玻璃效果(保持不变)"""
        if pixmap.isNull() or not self._blur:
            return pixmap
            
        image = pixmap.toImage()
        width, height = image.width(), image.height()
        scale_factor = max(2, self._blur_radius // 2)
        
        # 缩小图像
        scaled_image = image.scaled(
            width // scale_factor, 
            height // scale_factor, 
            Qt.IgnoreAspectRatio, 
            Qt.SmoothTransformation
        )
        
        # 应用模糊
        blurred_image = self._custom_box_blur(scaled_image, radius=2)
        
        # 放大回原尺寸
        return QPixmap.fromImage(
            blurred_image.scaled(
                width, height, 
                Qt.IgnoreAspectRatio, 
                Qt.SmoothTransformation
            )
        )

    def _custom_box_blur(self, image, radius=2):
        """自定义盒模糊算法(保持不变)"""
        width, height = image.width(), image.height()
        result = QImage(width, height, image.format())
        
        for y in range(height):
            for x in range(width):
                r_sum = g_sum = b_sum = a_sum = count = 0
                for dy in range(-radius, radius+1):
                    for dx in range(-radius, radius+1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < width and 0 <= ny < height:
                            color = image.pixelColor(nx, ny)
                            r_sum += color.red()
                            g_sum += color.green()
                            b_sum += color.blue()
                            a_sum += color.alpha()
                            count += 1
                if count > 0:
                    result.setPixelColor(x, y, QColor(
                        r_sum//count, g_sum//count, b_sum//count, a_sum//count))
        return result

    def _capture_screenshot(self):
        """捕获截图(保持不变)"""
        if not self.parent():
            return QPixmap()
        return self.parent().grab().copy(self.geometry())

    def _update_screenshot(self):
        """更新截图显示"""
        pixmap = self._capture_screenshot()
        if not pixmap.isNull() and self._blur:
            pixmap = self._apply_glass_effect(pixmap)
        if not pixmap.isNull():
            self.setPixmap(pixmap)

    def set_update_frequency(self, frequency: int):
        """设置刷新频率(毫秒)"""
        self._update_frequency = max(50, frequency)
        self._timer.setInterval(self._update_frequency)

    # 属性封装(保持不变)
    @property
    def blur(self):
        return self._blur
        
    @blur.setter
    def blur(self, value: bool):
        if self._blur != value:
            self._blur = value
            self._update_with_clear()

    @property
    def blur_radius(self):
        return self._blur_radius
        
    @blur_radius.setter
    def blur_radius(self, value: int):
        if value > 0 and self._blur_radius != value:
            self._blur_radius = value
            if self._blur:
                self._update_with_clear()
class passive_BlurringWidget_simplification(QLabel):
    """
    继承于BlurringWidget的优化版
    使用自定义毛玻璃效果算法替代内置模糊
    被动刷新模式，需要手动调用refresh()方法更新
    """
    def __init__(self, parent, blur: bool = False, blur_radius: int = 8):
        super().__init__(parent)
        self._blur = blur
        self._blur_radius = blur_radius
        self._refresh_on_demand = True
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.clear()  # 初始时清除内容

    def refresh(self):
        """手动刷新方法，先清除旧图像再更新"""
        self.clear()  # 先清除当前显示的图像
        self._update_screenshot()

    def _apply_glass_effect(self, pixmap):
        """应用毛玻璃效果"""
        if pixmap.isNull() or not self._blur:
            return pixmap
            
        image = pixmap.toImage()
        width, height = image.width(), image.height()
        scale_factor = max(2, self._blur_radius // 2)
        
        # 缩小图像尺寸
        small_width = width // scale_factor
        small_height = height // scale_factor
        
        # 缩放图像
        scaled_image = image.scaled(
            small_width, 
            small_height, 
            Qt.IgnoreAspectRatio, 
            Qt.SmoothTransformation
        )
        
        # 应用自定义盒模糊
        blurred_image = self._custom_box_blur(scaled_image, radius=2)
        
        # 放大回原尺寸
        final_image = blurred_image.scaled(
            width, 
            height, 
            Qt.IgnoreAspectRatio, 
            Qt.SmoothTransformation
        )
        
        return QPixmap.fromImage(final_image)

    def _custom_box_blur(self, image, radius=2):
        """自定义盒模糊算法"""
        width, height = image.width(), image.height()
        result = QImage(width, height, image.format())
        
        for y in range(height):
            for x in range(width):
                r_sum, g_sum, b_sum, a_sum, count = 0, 0, 0, 0, 0
                
                for dy in range(-radius, radius+1):
                    for dx in range(-radius, radius+1):
                        nx, ny = x + dx, y + dy
                        
                        if 0 <= nx < width and 0 <= ny < height:
                            pixel = image.pixelColor(nx, ny)
                            r_sum += pixel.red()
                            g_sum += pixel.green()
                            b_sum += pixel.blue()
                            a_sum += pixel.alpha()
                            count += 1
                
                if count > 0:
                    avg_color = QColor(
                        r_sum // count,
                        g_sum // count,
                        b_sum // count,
                        a_sum // count
                    )
                    result.setPixelColor(x, y, avg_color)
        
        return result

    def _capture_screenshot(self):
        """捕获并处理截图"""
        if not self.parent():
            return QPixmap()
            
        screenshot = self.parent().grab()
        rect = self.geometry()
        return screenshot.copy(rect)

    def _update_screenshot(self):
        """更新显示的截图"""
        pixmap = self._capture_screenshot()
        if not pixmap.isNull():
            if self._blur:
                pixmap = self._apply_glass_effect(pixmap)
            self.setPixmap(pixmap)

    @property
    def blur(self):
        return self._blur
        
    @blur.setter
    def blur(self, value: bool):
        if self._blur != value:
            self._blur = value
            self.refresh()

    @property
    def blur_radius(self):
        return self._blur_radius
        
    @blur_radius.setter
    def blur_radius(self, value: int):
        if value > 0 and self._blur_radius != value:
            self._blur_radius = value
            if self._blur:
                self.refresh()
class Gradient_blur(QLabel):
    """
    继承于QtLpassive_BlurringWidget_simplification的优化版
    使用自定义毛玻璃效果算法替代内置模糊
    支持模糊渐变效果和方向控制
    被动刷新模式，需要手动调用refresh()方法更新
    """
    def __init__(self, parent, blur: bool = False, blur_radius: int = 8):
        super().__init__(parent)
        self._blur = blur
        self._blur_radius = blur_radius
        self._refresh_on_demand = True
        self._gradient_enabled = False
        self._gradient_direction = "Right"  # 默认从右向左渐变
        self._gradient_length = 0.3  # 渐变区域占比(0-1)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.clear()  # 初始时清除内容

    def refresh(self):
        """手动刷新方法，先清除旧图像再更新"""
        self.clear()  # 先清除当前显示的图像
        self._update_screenshot()

    def _apply_glass_effect(self, pixmap):
        """应用毛玻璃效果，支持渐变模糊"""
        if pixmap.isNull() or not self._blur:
            return pixmap
            
        image = pixmap.toImage()
        width, height = image.width(), image.height()
        
        if self._gradient_enabled:
            # 创建渐变蒙版
            mask = QImage(width, height, QImage.Format.Format_ARGB32)
            mask.fill(Qt.GlobalColor.transparent)
            
            painter = QPainter(mask)
            gradient = QLinearGradient(0, 0, 0, 0)
            
            # 根据方向设置渐变
            if self._gradient_direction == "Right":
                gradient.setStart(0, 0)
                gradient.setFinalStop(width * self._gradient_length, 0)
            elif self._gradient_direction == "Left":
                gradient.setStart(width, 0)
                gradient.setFinalStop(width * (1 - self._gradient_length), 0)
            elif self._gradient_direction == "Bottom":
                gradient.setStart(0, 0)
                gradient.setFinalStop(0, height * self._gradient_length)
            elif self._gradient_direction == "Top":
                gradient.setStart(0, height)
                gradient.setFinalStop(0, height * (1 - self._gradient_length))
            
            gradient.setColorAt(0, QColor(0, 0, 0, 255))  # 完全不透明
            gradient.setColorAt(1, QColor(0, 0, 0, 0))     # 完全透明
            
            painter.fillRect(QRect(0, 0, width, height), QBrush(gradient))
            painter.end()
            
            # 应用模糊效果
            blurred_image = self._blur_image(image)
            
            # 合并原始图像和模糊图像
            result = QImage(width, height, QImage.Format.Format_ARGB32)
            result_painter = QPainter(result)
            result_painter.drawImage(0, 0, image)  # 原始图像
            result_painter.drawImage(0, 0, blurred_image)  # 模糊图像
            result_painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
            result_painter.drawImage(0, 0, mask)  # 应用蒙版
            result_painter.end()
            
            return QPixmap.fromImage(result)
        else:
            # 普通模糊处理
            return QPixmap.fromImage(self._blur_image(image))

    def _blur_image(self, image):
        """应用模糊效果到图像"""
        width, height = image.width(), image.height()
        scale_factor = max(2, self._blur_radius // 2)
        
        # 缩小图像尺寸
        small_width = width // scale_factor
        small_height = height // scale_factor
        
        # 缩放图像
        scaled_image = image.scaled(
            small_width, 
            small_height, 
            Qt.AspectRatioMode.IgnoreAspectRatio, 
            Qt.TransformationMode.SmoothTransformation
        )
        
        # 应用自定义盒模糊
        blurred_image = self._custom_box_blur(scaled_image, radius=2)
        
        # 放大回原尺寸
        final_image = blurred_image.scaled(
            width, 
            height, 
            Qt.AspectRatioMode.IgnoreAspectRatio, 
            Qt.TransformationMode.SmoothTransformation
        )
        
        return final_image

    def _custom_box_blur(self, image, radius=2):
        """自定义盒模糊算法"""
        width, height = image.width(), image.height()
        result = QImage(width, height, image.format())
        
        for y in range(height):
            for x in range(width):
                r_sum, g_sum, b_sum, a_sum, count = 0, 0, 0, 0, 0
                
                for dy in range(-radius, radius+1):
                    for dx in range(-radius, radius+1):
                        nx, ny = x + dx, y + dy
                        
                        if 0 <= nx < width and 0 <= ny < height:
                            pixel = image.pixelColor(nx, ny)
                            r_sum += pixel.red()
                            g_sum += pixel.green()
                            b_sum += pixel.blue()
                            a_sum += pixel.alpha()
                            count += 1
                
                if count > 0:
                    avg_color = QColor(
                        r_sum // count,
                        g_sum // count,
                        b_sum // count,
                        a_sum // count
                    )
                    result.setPixelColor(x, y, avg_color)
        
        return result

    def _capture_screenshot(self):
        """捕获并处理截图"""
        if not self.parent():
            return QPixmap()
            
        screenshot = self.parent().grab()
        rect = self.geometry()
        return screenshot.copy(rect)

    def _update_screenshot(self):
        """更新显示的截图"""
        pixmap = self._capture_screenshot()
        if not pixmap.isNull():
            if self._blur:
                pixmap = self._apply_glass_effect(pixmap)
            self.setPixmap(pixmap)

    # 新增属性和方法
    @property
    def gradient_enabled(self):
        return self._gradient_enabled
        
    @gradient_enabled.setter
    def gradient_enabled(self, value: bool):
        if self._gradient_enabled != value:
            self._gradient_enabled = value
            if self._blur:
                self.refresh()

    @property
    def gradient_direction(self):
        return self._gradient_direction
        
    @gradient_direction.setter
    def gradient_direction(self, direction: str):
        if direction in ["Left", "Right", "Top", "Bottom"] and self._gradient_direction != direction:
            self._gradient_direction = direction
            if self._gradient_enabled and self._blur:
                self.refresh()

    @property
    def gradient_length(self):
        return self._gradient_length
        
    @gradient_length.setter
    def gradient_length(self, value: float):
        if 0 < value <= 1 and self._gradient_length != value:
            self._gradient_length = value
            if self._gradient_enabled and self._blur:
                self.refresh()

    @property
    def blur(self):
        return self._blur
        
    @blur.setter
    def blur(self, value: bool):
        if self._blur != value:
            self._blur = value
            self.refresh()

    @property
    def blur_radius(self):
        return self._blur_radius
        
    @blur_radius.setter
    def blur_radius(self, value: int):
        if value > 0 and self._blur_radius != value:
            self._blur_radius = value
            if self._blur:
                self.refresh()