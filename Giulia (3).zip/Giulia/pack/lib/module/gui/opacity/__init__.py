from pack.lib.module.gui.QtPack import *

class Opacity:
    class GraphicsOpacityEffect(QGraphicsOpacityEffect):

        def __init__(self, parent : QWidget,Opacity : float = 0.5):
            super().__init__(parent)
            self.setOpacity(Opacity)
            parent.setGraphicsEffect(self)
            parent.setAutoFillBackground(True)

    class GraphicsOpacityEffect_Anim(QPropertyAnimation):
        def __init__(self, parent : QWidget = None,TargetObject:QGraphicsOpacityEffect = None , StartValue : int = 1,EndValue : int = 0.1 ,EasingCurve : QEasingCurve.Type = QEasingCurve.Type.InBack,Duration : int = 500):
            super().__init__(parent)
            self.setTargetObject(TargetObject)
            self.setPropertyName(b'opacity')
            self.setStartValue(StartValue)
            self.setEndValue(EndValue)
            self.setEasingCurve(EasingCurve)
            self.setDuration(Duration)

        def Animation_end_event(self,event):
            self.finished.connect(event)
        def Animation_team_add(self,animTeam: QSequentialAnimationGroup):
            animTeam.addAnimation(self)    
