from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.frame import *
from pack.lib.module.gui.widget import *
from pack.lib.module.gui.shadow import *
from pack.lib.module.gui.button import *


class MdiSubWindow(QMdiSubWindow):
    def __init__(self, parent=None, title: str = None):
        super().__init__(parent)
        self.title = title
        self.__init_gui__()
        self.setMinimumSize(130, 120)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)

        # 拖动相关变量
        self._drag_start_position = None
        self._window_start_position = None
        self._is_dragging = False

        # 边界检查相关
        self._margin = 10  # 距离边界的保留距离

        Shadow.Show(self, r=10, dy=3)

    def __init_gui__(self):
        stylec = [
            [QColor("#262626"), QColor("#ff8f8f"), QColor("#ff8f8f"), QColor("#ff8f8f"), QColor("#FFFFFF"), QColor("#ff2a2a")],
            [QColor("#FFFFFF"), QColor("#ff8f8f"), QColor("#ff8f8f"), QColor("#ff8f8f"), QColor("#000000"), QColor("#ff2a2a")]
        ]
        
        self.title_bar = FrameC(self, border_radius=0)
        self.title_layout = QHBoxLayout(self.title_bar)
        self.title_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.title_layout.setContentsMargins(10, 0, 0, 0)
        self.title_layout.setSpacing(0)

        self.titles = QLabel(str(self.title), None)

        self.close_button = StyleButton("x", None, style=stylec, border_width=0, border_radius=5)
        self.close_button.clicked.connect(lambda: self.deleteLater())
        self.close_button.setFixedSize(32, 32)

        self.title_layout.addWidget(self.titles)
        self.title_layout.addStretch()
        self.title_layout.addWidget(self.close_button)

        # 设置标题栏可接收鼠标事件
        self.title_bar.setMouseTracking(True)
        self.title_bar.installEventFilter(self)

    def get_parent_rect(self):
        """获取父窗口的有效区域"""
        if self.parent():
            # 如果是 MDI 区域，返回 MDI 区域的视口矩形
            if isinstance(self.parent(), QMdiArea):
                return self.parent().viewport().rect()
            else:
                return self.parent().rect()
        return QRect(0, 0, 800, 600)  # 默认值

    def constrain_position(self, position):
        """约束窗口位置，确保在父窗口范围内"""
        parent_rect = self.get_parent_rect()
        window_rect = self.rect()
        
        # 计算允许的最小和最大坐标
        min_x = parent_rect.left() + self._margin
        min_y = parent_rect.top() + self._margin
        max_x = parent_rect.right() - window_rect.width() - self._margin
        max_y = parent_rect.bottom() - window_rect.height() - self._margin
        
        # 约束坐标在允许范围内
        constrained_x = max(min_x, min(position.x(), max_x))
        constrained_y = max(min_y, min(position.y(), max_y))
        
        return QPoint(constrained_x, constrained_y)

    def is_position_valid(self, position):
        """检查位置是否在有效范围内"""
        parent_rect = self.get_parent_rect()
        window_rect = self.rect()
        
        # 检查是否超出边界
        if (position.x() < parent_rect.left() + self._margin or
            position.y() < parent_rect.top() + self._margin or
            position.x() + window_rect.width() > parent_rect.right() - self._margin or
            position.y() + window_rect.height() > parent_rect.bottom() - self._margin):
            return False
        return True

    def eventFilter(self, obj, event):
        """事件过滤器，用于处理标题栏的鼠标事件"""
        if obj == self.title_bar:
            if event.type() == QEvent.MouseButtonPress:
                return self.title_bar_mouse_press_event(event)
            elif event.type() == QEvent.MouseMove:
                return self.title_bar_mouse_move_event(event)
            elif event.type() == QEvent.MouseButtonRelease:
                return self.title_bar_mouse_release_event(event)
        
        return super().eventFilter(obj, event)

    def title_bar_mouse_press_event(self, event):
        """标题栏鼠标按下事件"""
        if event.button() == Qt.LeftButton:
            # 检查当前位置是否有效
            current_pos = self.pos()
            if not self.is_position_valid(current_pos):
                # 如果当前位置无效，自动修正到有效位置
                corrected_pos = self.constrain_position(current_pos)
                self.move(corrected_pos)
            
            self._is_dragging = True
            self._drag_start_position = event.globalPosition().toPoint()
            self._window_start_position = self.pos()
            
            # 改变鼠标光标为移动光标
            self.title_bar.setCursor(Qt.ClosedHandCursor)
            
            event.accept()
            return True
        
        return False

    def title_bar_mouse_move_event(self, event):
        """标题栏鼠标移动事件"""
        if self._is_dragging and event.buttons() & Qt.LeftButton:
            # 计算移动距离
            delta = event.globalPosition().toPoint() - self._drag_start_position
            new_position = self._window_start_position + delta
            
            # 约束新位置在父窗口范围内
            constrained_position = self.constrain_position(new_position)
            
            # 移动窗口到约束后的位置
            self.move(constrained_position)
            
            # 如果位置被约束，可以给用户一些视觉反馈
            if constrained_position != new_position:
                # 可以在这里添加边界碰撞的视觉反馈
                pass
            
            event.accept()
            return True
        else:
            # 鼠标悬停时显示可移动光标
            if not self._is_dragging:
                self.title_bar.setCursor(Qt.OpenHandCursor)
        
        return False

    def title_bar_mouse_release_event(self, event):
        """标题栏鼠标释放事件"""
        if event.button() == Qt.LeftButton and self._is_dragging:
            self._is_dragging = False
            self._drag_start_position = None
            self._window_start_position = None
            
            # 确保最终位置在有效范围内
            final_position = self.constrain_position(self.pos())
            if final_position != self.pos():
                self.move(final_position)
            
            # 恢复鼠标光标
            self.title_bar.setCursor(Qt.ArrowCursor)
            
            event.accept()
            return True
        
        return False

    def mousePressEvent(self, event):
        """重写窗口的鼠标按下事件，防止事件穿透"""
        # 如果点击的是标题栏区域，让标题栏处理
        if event.pos().y() <= 35:  # 标题栏高度
            event.ignore()
        else:
            event.accept()

    def mouseMoveEvent(self, event):
        """重写窗口的鼠标移动事件"""
        # 如果不在标题栏区域，恢复默认光标
        if event.pos().y() > 35 and not self._is_dragging:
            self.title_bar.setCursor(Qt.ArrowCursor)
        
        event.accept()

    def paintEvent(self, paintEvent):
        """重绘事件"""
        self.title_bar.setGeometry(0, 0, self.width(), 35)
        return super().paintEvent(paintEvent)

    def setWindowTitle(self, title):
        """设置窗口标题"""
        self.title = title
        if hasattr(self, 'titles'):
            self.titles.setText(str(title))
        super().setWindowTitle(title)

    def resizeEvent(self, event):
        """窗口大小改变事件"""
        super().resizeEvent(event)
        # 确保标题栏始终占据整个宽度
        self.title_bar.setGeometry(0, 0, self.width(), 35)
        
        # 窗口大小改变后，检查并修正位置
        current_pos = self.pos()
        if not self.is_position_valid(current_pos):
            corrected_pos = self.constrain_position(current_pos)
            self.move(corrected_pos)

    def moveEvent(self, event):
        """窗口移动事件"""
        super().moveEvent(event)
        # 可以在移动时实时检查边界（可选）
        current_pos = self.pos()
        if not self.is_position_valid(current_pos):
            corrected_pos = self.constrain_position(current_pos)
            if corrected_pos != current_pos:
                self.move(corrected_pos)