from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.listwidget import *
from pack.lib.module.gui.button import *
from pack.lib import *

import pkg_resources

class PackageExplorer(QDialog):
    def __init__(self,parent : QWidget):
        super().__init__(parent)
        self.initUI()
        
    def initUI(self):
        
        main_layout = QHBoxLayout()
        
        # 左侧：包名称列表（类似文件管理器左侧）
        left_frame = QFrame()
        left_frame.setFrameStyle(QFrame.Box)
        left_layout = QVBoxLayout()
        
        left_title = QLabel("包名称")
        left_title.setFont(QFont("Arial", 10, QFont.Bold))
        left_layout.addWidget(left_title)
        
        self.name_list = ListWidget(None,ScrollBar=True)
        left_layout.addWidget(self.name_list)
        
        left_frame.setLayout(left_layout)
        
        right_frame = QFrame()
        right_frame.setFrameStyle(QFrame.Box)
        right_layout = QVBoxLayout()
        
        add_pack = Button("添加包",None)
        add_pack.setMinimumHeight(30)

        del_pack = Button("删除包",None)
        del_pack.setMinimumHeight(30)

        cmd_pack = Button("使用命令行查看",None)
        cmd_pack.setMinimumHeight(30)

        packinto = Button("查看选中包信息",None)
        packinto.setMinimumHeight(30)

        close = Button("关闭窗口",None)
        close.setMinimumHeight(30)

        right_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        right_layout.addWidget(add_pack)
        right_layout.addWidget(del_pack)
        right_layout.addWidget(cmd_pack)
        right_layout.addWidget(packinto)
        right_layout.addStretch()
        right_layout.addWidget(close)
        
        right_frame.setLayout(right_layout)
        
        # 设置比例
        main_layout.addWidget(left_frame, 3)  # 左侧占3份
        main_layout.addWidget(right_frame, 1)  # 右侧占1份
        
        self.setLayout(main_layout)
        self.load_packages()
    
    def load_packages(self):

        names, versions = list_packages_pkg_resources('list')
        
        self.name_list.addItems(names)

