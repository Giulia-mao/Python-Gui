from pack.lib.module.gui.button import Button
from pack.lib.module.gui.widget import PopupWidget
from pack.lib.module.gui.scrollablelist import ScrollableButtonList
from pack.lib.module.gui.opacity import Opacity
from pack.lib.module.gui.shadow import Shadow
from pack.lib.module.gui.QtPack import *

class FlyOut(Button):
    def __init__(self, Content='', parent=None, border_radius=4, 
                 Widget_Height: int = 100, Widget_Width: int = 200, button_shadow_r: int = 5):
        super().__init__(Content, parent)
        self.ShadowEfS = [True]  # 使用列表保持引用，初始为True表示启用阴影
        self.clicked.connect(self._on_click)
        self.button_shadow_r = button_shadow_r
        self.border_radius = border_radius
        self.Widget_Width = max(Widget_Width, 100)
        self.Widget_Height = Widget_Height
        self._init_menu_()

    def _init_menu_(self):
        self._menu = PopupWidget(self)
        self._menu.setAttribute(Qt.WA_TranslucentBackground)
        self._menu.setStyleSheet("background: transparent; border: none;")
        self._menu.resize(self.Widget_Width, self.Widget_Height)
        
        self.item_list = QWidget(self._menu)
        self.item_list.setObjectName("FlyOutMenu")
        self.item_list.show()
        
        self.ButtonC = Button(self.item_list)
        self.ButtonC.setText("测试按钮")
        self.ButtonC.setGeometry(0, 0, self.Widget_Width, self.Widget_Height)
        
        self._menu.setFocusOutEvent(self._on_menu_focus_out)

    def _on_menu_focus_out(self):
        """菜单失去焦点时的处理"""
        if hasattr(self, 'ShadowEf'):
            try:
                self.ShadowEf.deleteLater()
            except:
                pass
        self._menu.hide()

    def animation(self):
        """显示动画效果"""
        if hasattr(self, '_menu'):
            # 确保先清除旧的动画连接
            try:
                self.animo.finished.disconnect()
            except:
                pass
            
            self.animo = QPropertyAnimation(self.ButtonC)
            self.animo.setTargetObject(self.item_list)
            self.animo.setPropertyName(b'geometry')
            self.animo.setStartValue(QRect(10, -self.item_list.height(), self.Widget_Width-20, self.Widget_Height))
            self.animo.setEndValue(QRect(10, 0, self.Widget_Width-20, self.Widget_Height))
            self.animo.setDuration(600)
            self.animo.setEasingCurve(QEasingCurve.Type.OutExpo)
            
            # 连接动画结束信号到阴影动画
            self.animo.finished.connect(self._start_shadow_animation)
            self.animo.start()

    def _start_shadow_animation(self):
        """在几何动画完成后启动阴影动画"""
        if self.ShadowEfS[0]:  # 检查阴影是否启用
            try:
                # 先清除旧的阴影效果
                if hasattr(self, 'ShadowEf'):
                    self.item_list.setGraphicsEffect(None)
                    self.ShadowEf.deleteLater()
                
                # 创建新的阴影效果
                self.ShadowEf = Shadow.Shadow_Show(self.item_list, r=self.button_shadow_r)
                self.item_list.setGraphicsEffect(self.ShadowEf)
                
                # 启动阴影动画
                if hasattr(self.ShadowEf, 'animation'):
                    self.ShadowEf.animation.start()
            except Exception as e:
                print(f"阴影动画错误: {e}")

    def _on_click(self):
        """按钮点击处理"""
        if hasattr(self, '_menu'):
            # 切换阴影状态
            self.ShadowEfS[0] = not self.ShadowEfS[0]
            
            # 计算显示位置（按钮左下角）
            pos = self.mapToGlobal(QPoint(-10, self.height()+5))
            self._menu.move(pos)
            
            # 显示菜单并启动动画
            self._menu.show()
            self.animation()