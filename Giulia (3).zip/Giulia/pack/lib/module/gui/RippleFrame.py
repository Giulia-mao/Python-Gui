from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.native.Button import *
from pack.lib.module.gui.shadow import *

class RippleFrame(QFrame):
    '''

    * shadow : tuple (dx,dy,r) 阴影参数
    * text : str 按钮文本
    * parent : QWidget 父窗口
    * x : int 按钮x坐标
    * y : int 按钮y坐标
    * border_color : QColor 边框颜色
    * background_color_switch : bool 是否使用系统调色板颜色
    * start_color : QColor 起始颜色
    * hover_color : QColor 悬停颜色
    * press_color : QColor 按下颜色
    * alpha : int 透明度
    * border_width : int 边框宽度
    * corner_radius : int 圆角半径
    * air_event : function 点击事件
    * Gradient_switch : bool 是否使用渐变颜色
    * event : function 点击事件
    * width : int 按钮宽度
    * height : int 按钮高度
    * background_color_switch : bool 是否使用系统调色板颜色
    * start_color : QColor 起始颜色
    '''
    clicked_with_data = Signal(object)
    def __init__(self, parent=None,
                 background_color_switch=False, start_color=QColor("#272727"), hover_color=QColor("#565656"),
                 press_color=QColor("#878787"), alpha: int = 255, border_width: int = 1, corner_radius: int = 5,
                 Gradient_switch=True,font_color : QColor = None,data = None,text_align = Qt.AlignmentFlag.AlignCenter):
        
        super().__init__(parent)
        self._data = data
        self.text_align = text_align
        self.ripples = []
        self.setFocusPolicy(Qt.NoFocus)
        self.setCursor(Qt.PointingHandCursor)
        self.alpha = alpha
        self.border_width = border_width
        self.hovered = False
        self.pressed = False
        self.animation_value = 0
        self.press_animation = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.corner_radius = corner_radius
        self.Gradient_switch = Gradient_switch  # 新增的颜色渐变控制属性
        
        # 初始更新颜色
        self.update_colors()
        # 监听系统调色板变化
        if not background_color_switch:
            app = QApplication.instance()
            app.paletteChanged.connect(self.update_colors)
        else:
            if font_color is None:
                pass
            else:
                self.text_color = font_color 
            self.start_color = start_color
            self.hover_color = hover_color
            self.press_color = press_color
    def _emit_clicked(self):
        self.clicked_with_data.emit(self._data)
    
    @property
    def data(self):
        return self._data
    
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.text_color = Qt.white
            self.hover_border = QColor(66,66,66)
            self.start_color = QColor(38, 38, 38, 0)  # 半透明黑色
            self.hover_color = QColor(66, 66, 66, self.alpha)  # 半透明深灰色
            self.press_color = QColor(78, 78, 78, self.alpha)  # 半透明灰色
        else:
            self.text_color = Qt.black
            self.hover_border = QColor(198,198,198)
            self.start_color = QColor(255, 255, 255, 0)  # 半透明白色
            self.hover_color = QColor(221, 221, 221, self.alpha)  # 半透明浅灰色
            self.press_color = QColor(194, 194, 194, self.alpha)  # 半透明灰色

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.pressed = True
            pos = QPointF(event.position())
            self.ripples.append({"pos": pos, "radius": 0, "opacity": 0.7})
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.pressed = False
        super().mouseReleaseEvent(event)

    def enterEvent(self, event):
        self.hovered = True
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        super().leaveEvent(event)

    def update_animation(self):
        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        new_ripples = []
        for ripple in self.ripples:
            ripple["radius"] += self.width()//10
            if not self.pressed:
                ripple["opacity"] -= 0.02
            if ripple["opacity"] > 0:
                new_ripples.append(ripple)
        self.ripples = new_ripples
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 创建裁剪区域（圆角矩形）
        clip_path = QPainterPath()
        clip_path.addRoundedRect(self.rect(), self.corner_radius, self.corner_radius)
        painter.setClipPath(clip_path)

        if self.Gradient_switch:
            # 计算背景颜色
            base_bg_color = QColor(
                self.start_color.red() + int((self.hover_color.red() - self.start_color.red()) * self.animation_value),
                self.start_color.green() + int((self.hover_color.green() - self.start_color.green()) * self.animation_value),
                self.start_color.blue() + int((self.hover_color.blue() - self.start_color.blue()) * self.animation_value),
                self.start_color.alpha()  # 保持透明度不变
            )

            final_bg_color = QColor(
                base_bg_color.red() + int((self.press_color.red() - base_bg_color.red()) * self.press_animation),
                base_bg_color.green() + int((self.press_color.green() - base_bg_color.green()) * self.press_animation),
                base_bg_color.blue() + int((self.press_color.blue() - base_bg_color.blue()) * self.press_animation),
                base_bg_color.alpha()  # 保持透明度不变
            )
        else:
            if self.hovered and self.pressed:
                final_bg_color = self.press_color
            elif self.hovered:
                final_bg_color = self.hover_color
            else:
                final_bg_color = self.start_color

        # 绘制背景
        path = QPainterPath()
        path.addRoundedRect(self.rect(), self.corner_radius, self.corner_radius)
        painter.fillPath(path, final_bg_color)

        # 绘制边框（不应用裁剪，确保边框完整显示）
        painter.save()
        painter.setClipRect(self.rect())  # 重置裁剪区域为整个按钮
        if self.border_width > 0:
            painter.setPen(QPen(self.hover_border, int(self.border_width)))
            painter.drawRoundedRect(self.rect(), self.corner_radius, self.corner_radius)
        painter.restore()

        # 绘制光源效果（涟漪效果）
        for ripple in self.ripples:
            gradient = QRadialGradient(
                ripple["pos"],
                ripple["radius"],
                ripple["pos"]
            )
            palette = QApplication.palette()
            is_dark = palette.window().color().lightness() < 128
            center_color = QColor(255, 255, 255, int(ripple["opacity"] * 128)) if is_dark else QColor(0, 0, 0, int(ripple["opacity"] * 128))
            outer_color = QColor(60, 60, 60, 1)
            gradient.setColorAt(0, center_color)
            gradient.setColorAt(1, outer_color)

            painter.setBrush(QBrush(gradient))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(ripple["pos"].toPoint(), int(ripple["radius"]), int(ripple["radius"]))
