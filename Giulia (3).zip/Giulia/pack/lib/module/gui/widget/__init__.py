
from pack.lib.module.gui.QtPack import *
class PopupWidget(QWidget):
    focusOut = Signal()  # 修改为无参数的信号
    
    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.Popup |               # 弹出式窗口
            Qt.FramelessWindowHint |  # 无边框
            Qt.NoDropShadowWindowHint  # 明确禁用阴影
        )

        self.installEventFilter(self)
    
    def eventFilter(self, obj, event):
        if event.type() == QEvent.FocusOut:
            self.focusOut.emit()  # 发射无参数信号
        return super().eventFilter(obj, event)
    
    def setFocusOutEvent(self, handler):
        """设置焦点离开事件处理器"""
        self.focusOut.connect(handler)

class Widget(QWidget):
    focusOut = Signal()  # 修改为无参数的信号
    def __init__(self, parent=None, border_radius : int = 4):
        super().__init__(parent)
        self.border_radius = border_radius
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")
            style = f"""
            Widget {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
            }}
            """
            self.setStyleSheet(style)

        else:
            # 浅色模式颜色
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")

            style = f"""
            Widget {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
            }}
            """
            self.setStyleSheet(style)
    def setFocusOutEvent(self, handler):
        """设置焦点离开事件处理器"""
        self.focusOut.connect(handler)
    def eventFilter(self, obj, event):
        if event.type() == QEvent.FocusOut:
            self.focusOut.emit()  # 发射无参数信号
        return super().eventFilter(obj, event)