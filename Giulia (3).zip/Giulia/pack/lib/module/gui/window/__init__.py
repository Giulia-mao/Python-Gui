
from pack.lib.module.gui.QtPack import *

class MainWindow(QMainWindow):
    def __init__ (self,parent : QWidget = None, title : str = "MainWindow", width : int = 800, height : int = 600):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(width, height)
        
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
                QMainWindow {{
                    background-color : #121212;
                    color: white;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QMainWindow {{
                    background-color : #f0f0f0;
                    color: black;
                }}
            """)
