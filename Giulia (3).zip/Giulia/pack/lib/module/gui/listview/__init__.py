from pack.lib.module.gui.QtPack import *

class ListView(QListView):
    hover = Signal(bool)
    pressed = Signal(bool)
    Release = Signal(bool)
    unhover = Signal(bool)
    focus = Signal(bool)
    selectionActivated = Signal(QStandardItem)  # 修改为 QStandardItem
    itemClicked = Signal(QStandardItem)  # 添加 itemClicked 信号
    
    def __init__(self, parent: QWidget = None, focus: bool = False, border_radius: int = 4, ScrollBar: bool = False):
        super().__init__(parent)
        self.border_radius = border_radius
        
        # 设置模型
        self.model = QStandardItemModel()
        self.setModel(self.model)
        
        # 连接信号
        self.selectionModel().currentChanged.connect(self._on_current_changed)
        self.clicked.connect(self._on_item_clicked)
        
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        
        # Focus policy
        if not ScrollBar:
            self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        if not focus:
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    
    def getitem(self):
        """获取当前选中的项"""
        index = self.currentIndex()
        if index.isValid():
            item = self.model.itemFromIndex(index)
            if item:
                return item.text()
        return None
    
    def addItem(self, text):
        """添加项"""
        item = QStandardItem(text)
        self.model.appendRow(item)
    
    def addItems(self, texts):
        """添加多个项"""
        for text in texts:
            self.addItem(text)
    
    def clear(self):
        """清空所有项"""
        self.model.clear()
    
    def count(self):
        """获取项数量"""
        return self.model.rowCount()
    
    def item(self, row):
        """获取指定行的项"""
        if 0 <= row < self.model.rowCount():
            return self.model.item(row)
        return None
    
    def currentItem(self):
        """获取当前选中的项"""
        index = self.currentIndex()
        if index.isValid():
            return self.model.itemFromIndex(index)
        return None
    
    def setCurrentItem(self, item):
        """设置当前选中的项"""
        if isinstance(item, QStandardItem):
            index = self.model.indexFromItem(item)
            self.setCurrentIndex(index)
    
    def _on_current_changed(self, current, previous):
        """当前项变化时触发"""
        if current.isValid():
            item = self.model.itemFromIndex(current)
            self.selectionActivated.emit(item)
    
    def _on_item_clicked(self, index):
        """项被点击时触发"""
        if index.isValid():
            item = self.model.itemFromIndex(index)
            self.itemClicked.emit(item)
    
    def setSelectedEvent(self, handler):
        """设置选中事件处理器"""
        self.selectionActivated.connect(handler)
    
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self.setStyleSheet(f"""
            ListView{{
                background-color : #262626;
                border: 1px solid #262626;
                border-radius: {self.border_radius}px;
                outline: none;
                border-top: 1px solid #424242;
                border: 1px solid #2E2E2E;
            }}
            ListView::scroll-bar:vertical,
            ListView::scroll-bar:horizontal {{
                width: 0;
                height: 0;
                background: transparent;
            }}
            ListView::item{{
                background-color : #262626;
                border: 1px solid #262626;
                border-radius: 0px;
                outline: none;
                height: 25px;
            }}
            ListView::item:hover{{
                background-color : #424242;
                border: 1px solid #474747;
                border-top: 1px solid #424242;
                border: 1px solid #2E2E2E;
            }}
            ListView::item:focus {{
                background-color : #262626;
                border: 1px solid #0066ff;
                outline: none;
            }}
            ListView::item:focus:hover {{
                background-color : #474747;
                border: 1px solid #3a89ff;
                outline: none;
            }}
            ListView::item:focus:selected{{
                background-color : #535353;
                border: 1px solid #535353;
            }}
            ListView::item:selected{{
                background-color : #535353;
                border: 1px solid #535353;
                color: white;
            }}
            """)
        else:
            self.setStyleSheet(f"""
            ListView{{
                background-color : #FFFFFF;
                border: 1px solid #C9C9C9;
                border-radius: {self.border_radius}px;
                outline: none;
            }}
            ListView::scroll-bar:vertical,
            ListView::scroll-bar:horizontal {{
                width: 0;
                height: 0;
                background: transparent;
            }}
            ListView::item{{
                background-color : #FFFFFF;
                border: 1px solid #FFFFFF;
                border-radius: 0px;
                outline: none;
                height: 25px;
            }}
            ListView::item:hover{{
                background-color : #DADADA;
                border: 1px solid #DADADA;
            }}
            ListView::item:focus {{
                background-color : #c0c0c0;
                border: 1px solid #0066ff;
                outline: none;
            }}
            ListView::item:focus:hover {{
                background-color : #c0c0c0;
                border: 1px solid #3a89ff;
                outline: none;
            }}
            ListView::item:focus:selected{{
                background-color : #2193ff;
                border: 1px solid #2193ff;
                color: white;
            }}
            ListView::item:selected{{
                background-color : #2193ff;
                border: 1px solid #2193ff;
                color: white;
            }}
            """)
    
    def enterEvent(self, event):
        self.hovered = True
        self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        self.unhover.emit(True)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        self.pressed.emit(True)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        self.Release.emit(True)
        super().mouseReleaseEvent(event)

    def focusInEvent(self, event):
        self.focus.emit(True)
        super().focusInEvent(event)

    def focusOutEvent(self, event):
        self.focus.emit(False)
        super().focusOutEvent(event)


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setGeometry(100, 100, 400, 500)
    
    list_view = ListView(window, focus=True, border_radius=8)
    list_view.setGeometry(50, 50, 300, 400)
    
    # 添加项
    list_view.addItem("Item 1")
    list_view.addItem("Item 2")
    list_view.addItem("Item 3")
    list_view.addItem("Item 4")
    list_view.addItem("Item 5")
    
    # 连接信号
    def on_selection_changed(item):
        if item:
            print(f"选中: {item.text()}")
    
    def on_item_clicked(item):
        if item:
            print(f"点击: {item.text()}")
    
    list_view.selectionActivated.connect(on_selection_changed)
    list_view.itemClicked.connect(on_item_clicked)
    
    window.show()
    sys.exit(app.exec())