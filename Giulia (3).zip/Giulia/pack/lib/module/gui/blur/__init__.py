from pack.lib.module.gui.QtPack import *

class Blur:
    '''
    # 模糊效果
    * BlurEffect   模糊效果
    * Blur_Animation_Show   显示模糊动画
    * Blur_Animation_Back   隐藏模糊动画
    * Show         显示模糊效果
    * Back         隐藏模糊效果
    * Effect       效果
    * Static       静态模糊效果
    '''
    class BlurEffect(QGraphicsBlurEffect):
        """
        # 模糊效果
        * parent : 父控件
        * BlurRadius : 模糊半径
        """
        def __init__(self, 
                     parent : QWidget = None, 
                     BlurRadius : int = 20
                ):
            super().__init__(parent)

            self.setBlurRadius(BlurRadius)
            parent.setGraphicsEffect(self)  
            self.setBlurHints(QGraphicsBlurEffect.PerformanceHint)     

    class Blur_Animation_Show(QGraphicsBlurEffect):
        
        def __init__(self, parent : QWidget = None ,BlurRadius = 10, Duration : int = 500,EasingCurve : QEasingCurve.Type = QEasingCurve.Type.OutExpo) -> None:
            super(Blur.Blur_Animation_Show, self).__init__(parent)
            self.setBlurRadius(BlurRadius)
                    
                    
            self._radius = 0
                    
            self.animation = QPropertyAnimation(self)
            self.animation.setTargetObject(self)
            self.animation.setStartValue(0)
            self.animation.setEndValue(BlurRadius)
            self.animation.setDuration(Duration)
            self.animation.setEasingCurve(EasingCurve)
            self.animation.setPropertyName(b'radius')
                    

        def start(self):
            self.animation.start()

        @Property(int)
        def radius(self):
            return self._radius

        @radius.setter
        def radius(self, r):
            self._radius = r
            self.setBlurRadius(r)

    class Blur_Animation_Back(QGraphicsBlurEffect):
                
        def __init__(self, parent : QWidget = None ,BlurRadius = 10,Duration : int = 500,EasingCurve : QEasingCurve.Type = QEasingCurve.Type.OutExpo) -> None:
            super(Blur.Blur_Animation_Back, self).__init__(parent)
            self.setBlurRadius(BlurRadius)                    
            self._radius = 0    
            self.animation = QPropertyAnimation(self)
            self.animation.setTargetObject(self)
            self.animation.setStartValue(BlurRadius)  # 一次循环时间
            self.animation.setEndValue(0)
            self.animation.setEasingCurve(EasingCurve)
            self.animation.setDuration(Duration)
            self.animation.setPropertyName(b'radius')

        def start(self):
            self.animation.start()

        @Property(int)
        def radius(self):
            return self._radius

        @radius.setter
        def radius(self, r):
            self._radius = r
            self.setBlurRadius(r)      
    class Show(Blur_Animation_Show):
        def __init__(self, parent: QWidget = None, BlurRadius : int = 20,Duration : int = 500,EasingCurve : QEasingCurve.Type = QEasingCurve.Type.OutExpo) -> None:
            super().__init__(parent, BlurRadius,Duration,EasingCurve)
            parent.setGraphicsEffect(self)
            self.start()
    class Back(Blur_Animation_Back):
            def __init__(self, parent: QWidget = None,BlurRadius = 10,Duration : int = 500,EasingCurve : QEasingCurve.Type = QEasingCurve.Type.OutExpo) -> None:
                super().__init__(parent, BlurRadius,Duration,EasingCurve)
                parent.setGraphicsEffect(self)
                self.start()