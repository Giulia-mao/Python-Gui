from PySide6.QtCore import *
from PySide6.QtWidgets import *

class ListWidget(QListWidget):
    hover = Signal(bool)
    pressed = Signal(bool)
    Release = Signal(bool)
    unhover = Signal(bool)
    focus = Signal(bool)
    focusOut = Signal()  # 修改为无参数的信号

    selectionActivated = Signal(QListWidgetItem)  # 自定义选中信号
    def __init__(self,parent:QWidget,focus : bool = False,border_radius : int = 4,ScrollBar : bool = False):
        super().__init__(parent)
        self.border_radius = border_radius
        # 连接内置的itemSelectionChanged信号到自定义槽函数
        self.setSelectionMode(QListWidget.SingleSelection)
        self.currentItemChanged.connect(self._on_current_changed)
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        # Focus policy
        if ScrollBar == False:

            self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            # 隐藏水平滚动条
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        else:
            pass
        if not focus:
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    def getitem(self):
        selectedItem = self.currentItem()
        if selectedItem:
            text = selectedItem.text()
                    
            return text
        else:
            return None
        
    def setFocusOutEvent(self, handler):
        """设置焦点离开事件处理器"""
        self.focusOut.connect(handler)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        if is_dark:
            self.setStyleSheet("""
            ListWidget{
                background-color : #262626;
                border: 1px solid #262626;
                border-radius: """+str(self.border_radius)+"""px;
                outline: none;
                border-top: 1px solid #424242;
                border: 1px solid #2E2E2E;
                padding: 3px;
            }
            ListWidget::scroll-bar:vertical,
            ListWidget::scroll-bar:horizontal {
                width: 0;
                height: 0;
                background: transparent;
            }
            ListWidget:item{
                background-color : #262626;
                border: 1px solid #262626;
                border-radius: 0px;
                padding: 3px;
                outline: none;
            }
            ListWidget:item:hover{
                background-color : #424242;
                border: 1px solid #474747;
                border-top: 1px solid #424242;
                border: 1px solid #2E2E2E;

            }
            ListWidget:item:focus {
                background-color : #262626;
                border: 1px solid #0066ff;
                outline: none;
            }
            ListWidget:item:focus:hover {
                background-color : #474747;
                border: 1px solid #3a89ff;
                outline: none;
            }
            ListWidget:item:focus:selected{
                background-color : #535353;
                border: 1px solid #535353;
            }
            ListWidget:item:selected{
                background-color : #535353;
                border: 1px solid #535353;
            }


        """)
        else:
            self.setStyleSheet("""
            ListWidget{
                background-color : #FFFFFF;
                border: 1px solid #C9C9C9;
                border-radius: """+str(self.border_radius)+"""px;
                outline: none;
                padding: 3px;

            }
            ListWidget::scroll-bar:vertical,
            ListWidget::scroll-bar:horizontal {
                width: 0;
                height: 0;
                background: transparent;
            }
            ListWidget:item{
                background-color : #FFFFFF;
                border: 1px solid #FFFFFF;
                border-radius: 0px;
                padding: 3px;
                outline: none;
            }
            ListWidget:item:hover{
                background-color : #DADADA;
                border: 1px solid #DADADA;

            }
            ListWidget:item:focus {
                background-color : #c0c0c0;
                border: 1px solid #0066ff;
                outline: none;
            }
            ListWidget:item:focus:hover {
                background-color : #c0c0c0;
                border: 1px solid #3a89ff;
                outline: none;
            }
            ListWidget:item:focus:selected{
                background-color : #2193ff;
                border: 1px solid #2193ff;
            }
            ListWidget:item:selected{
                background-color : #2193ff;
                border: 1px solid #2193ff;
            }


        """)
        
    def _on_current_changed(self, current, previous):
        """当前项变化时触发"""
        if current:
            self.selectionActivated.emit(current)
            
    def setSelectedEvent(self, handler):
        """设置选中事件处理器"""
        self.selectionActivated.connect(handler)
        
    def mousePressEvent(self, event):
        """鼠标点击时确保触发选中事件"""
        item = self.itemAt(event.pos())
        if item and not item.isSelected():
            self.setCurrentItem(item)
        super().mousePressEvent(event)

    def enterEvent(self, event):
        self.hovered = True
        self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        self.unhover.emit(True)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        self.pressed.emit(True)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        self.Release.emit(True)
        super().mouseReleaseEvent(event)

    def focusInEvent(self, event):
        self.focus.emit(True)
        super().focusInEvent(event)

    def focusOutEvent(self, event):
        self.focus.emit(False)
        super().focusOutEvent(event)

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = QMainWindow()
    list_widget = ListWidget(window, focus=True, border_radius=8)
    list_widget.setGeometry(50, 50, 200, 300)
    list_widget.addItem("Item 1")
    list_widget.addItem("Item 2")
    list_widget.addItem("Item 3")
    list_widget.show()
    window.show()
    sys.exit(app.exec())