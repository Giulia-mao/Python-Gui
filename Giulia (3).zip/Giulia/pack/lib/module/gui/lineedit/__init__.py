from pack.lib.module.gui.QtPack import *

class LineEdit(QLineEdit):
    hover = Signal(bool)
    pressed = Signal(bool)
    Release = Signal(bool)
    unhover = Signal(bool)
    focus = Signal(bool)
    keyPressed = Signal(QKeyEvent)
    keyReleased = Signal(QKeyEvent)
    def __init__(self, parent=None, border_radius: int = 3, border_width: int = 1, 
                 setCursor: Qt.CursorShape = None, alpha: int = 255,
                  minsize: QSize = None, maxsize: QSize = None):
        super().__init__(parent)
        self.setMouseTracking(True)
        
        if minsize is not None:
            self.setMinimumSize(minsize)
        if maxsize is not None:
            self.setMaximumSize(minsize)
    
        self.animation_value = 0
        self.pressed_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.hovered = False
        self.pressed_state = False
        
        self.border_width = border_width
        self.border_radius = border_radius
        if setCursor == None:
            pass
        else:
            self.setCursor(setCursor)
        self.alpha = alpha
        
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.start_color = QColor(45,45,45)
            self.end_color = QColor(61, 61, 61)
            self.border_color = QColor(61, 61, 61)
            self.end_border_color = QColor(61, 61, 61)
            self.pressed_color = QColor(40, 40, 40)
            self.focus_border_color = QColor(61, 61, 61)
            self.focus_hover_border_color = QColor(61, 61, 61)
        else:
            self.border_color = QColor(168, 168, 168)
            self.start_color = QColor(243, 243, 243)
            self.end_color = QColor(220, 220, 220)
            self.end_border_color = QColor(168, 168, 168)
            self.pressed_color = QColor(195, 195, 195)
            self.focus_border_color = QColor(0, 119, 255)
            self.focus_hover_border_color = QColor(69, 143, 255)

    def keyPressEvent(self, event):
        self.keyPressed.emit(event)
        super().keyPressEvent(event)
    
    def keyReleaseEvent(self, event):
        self.keyReleased.emit(event)
        super().keyReleaseEvent(event)

    def enterEvent(self, event):
        self.hovered = True
        self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        self.unhover.emit(True)
        super().leaveEvent(event)

    def focusInEvent(self, event):
        self.focus.emit(True)
        super().focusInEvent(event)
        self.update_animation()

    def focusOutEvent(self, event):
        self.focus.emit(False)
        super().focusOutEvent(event)
        self.update_animation()

    def setOpacity(self, Opacity_num: float):
        effect = QGraphicsOpacityEffect()
        effect.setOpacity(Opacity_num)
        self.setGraphicsEffect(effect)
    
    def setPlaceholderColor(self, color):
        self.setStyleSheet(self.styleSheet() + f"""
        QLineEdit::placeholder {{
            color: {color.name()};
        }}
        """)

    def update_animation(self):
        # Update animation values
        if self.pressed_state and self.pressed_animation_value < 1:
            self.pressed_animation_value += 0.1
            if self.pressed_animation_value > 1:
                self.pressed_animation_value = 1
        elif not self.pressed_state and self.pressed_animation_value > 0:
            self.pressed_animation_value -= 0.1
            if self.pressed_animation_value < 0:
                self.pressed_animation_value = 0

        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        base_color = QColor(
            self.start_color.red() + int((self.end_color.red() - self.start_color.red()) * self.animation_value),
            self.start_color.green() + int((self.end_color.green() - self.start_color.green()) * self.animation_value),
            self.start_color.blue() + int((self.end_color.blue() - self.start_color.blue()) * self.animation_value),
            self.alpha
        )

        current_color = QColor(
            base_color.red() + int((self.pressed_color.red() - base_color.red()) * self.pressed_animation_value),
            base_color.green() + int((self.pressed_color.green() - base_color.green()) * self.pressed_animation_value),
            base_color.blue() + int((self.pressed_color.blue() - base_color.blue()) * self.pressed_animation_value),
            self.alpha
        )

        if self.hasFocus():
            if self.hovered:
                border_color = self.focus_hover_border_color
            else:
                border_color = self.focus_border_color
        else:
            border_color = QColor(
                self.border_color.red() + int((self.end_border_color.red() - self.border_color.red()) * self.animation_value),
                self.border_color.green() + int((self.end_border_color.green() - self.border_color.green()) * self.animation_value),
                self.border_color.blue() + int((self.end_border_color.blue() - self.border_color.blue()) * self.animation_value),
                self.alpha
            )

        style = f"""
        background-color: rgba({current_color.red()}, {current_color.green()}, {current_color.blue()}, {self.alpha/255});
        border-color: rgba({border_color.red()}, {border_color.green()}, {border_color.blue()}, {self.alpha/255});
        border-style: solid;
        outline: none;
        border-width: {self.border_width}px;
        border-radius: {self.border_radius}px;
        font-size: 13px;
        padding : 5px;
        """
        
        self.setStyleSheet(style)
