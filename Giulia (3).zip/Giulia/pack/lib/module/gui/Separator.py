from pack.lib.module.gui.QtPack import *


class Separator(QFrame):
    def __init__(self, parent: QWidget = None, orientation: Qt.Orientation = Qt.Horizontal, style_type: str = "modern"):
        super().__init__(parent)
        
        self.orientation = orientation
        self.style_type = style_type
        
        # 设置框架形状
        if orientation == Qt.Horizontal:
            self.setFrameShape(QFrame.HLine)
            self.setFixedHeight(1)
        else:
            self.setFrameShape(QFrame.VLine)
            self.setFixedWidth(1)
            
        self.setFrameShadow(QFrame.Plain)
        self.setObjectName("Separator")
        
        # 应用样式
        self.apply_style(style_type)
    
    def apply_style(self, style_type: str = None):
        """应用不同的分隔符样式"""
        if style_type:
            self.style_type = style_type
            
        if self.style_type == "modern":
            style = """
            Separator {
                background-color: #e0e0e0;
                border: none;
                margin: 2px 0px;
            }
            """
        elif self.style_type == "minimal":
            style = """
            Separator {
                background-color: #f0f0f0;
                border: none;
                margin: 1px 0px;
            }
            """
        elif self.style_type == "bold":
            style = """
            Separator {
                background-color: #cccccc;
                border: none;
                margin: 3px 0px;
                height: 2px;
            }
            """
        elif self.style_type == "gradient":
            style = """
            Separator {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 transparent, stop:0.5 #c0c0c0, stop:1 transparent);
                border: none;
                margin: 4px 0px;
            }
            """
        elif self.style_type == "dotted":
            style = """
            Separator {
                background: repeating-linear-gradient(to right, 
                    #c0c0c0, #c0c0c0 2px, transparent 2px, transparent 4px);
                border: none;
                margin: 3px 0px;
                height: 1px;
            }
            """
        else:  # 默认样式
            style = """
            Separator {
                background-color: #d0d0d0;
                border: none;
                margin: 2px 0px;
            }
            """
        
        self.setStyleSheet(style)
    
    def set_color(self, color: str):
        """动态设置分隔符颜色"""
        style = f"""
        Separator {{
            background-color: {color};
            border: none;
            margin: 2px 0px;
        }}
        """
        self.setStyleSheet(style)
    
    def set_thickness(self, thickness: int):
        """设置分隔符粗细"""
        if self.orientation == Qt.Horizontal:
            self.setFixedHeight(thickness)
        else:
            self.setFixedWidth(thickness)