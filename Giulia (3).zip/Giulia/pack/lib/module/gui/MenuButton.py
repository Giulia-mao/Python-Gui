from pack.lib.module.gui.button import Button
from pack.lib.module.gui.QtPack import *


class MenuButton(Button):
    def __init__(self, content='', parent=None, border_radius=4, border_width: int = 1):
        """
        带菜单功能的按钮
        
        Args:
            content: 按钮显示的文本内容
            parent: 父组件
            border_radius: 边框圆角半径
            border_width: 边框宽度
        """
        super().__init__(str(content), parent, border_width=border_width, border_radius=border_radius)
        self.menu = None  # 初始化菜单对象
        self.clicked.connect(self._on_click)
    
    def _on_click(self):
        """按钮点击事件处理"""
        if not self.menu:
            self.menu = QMenu(self)
        
        # 计算菜单位置：按钮左下角偏移
        pos = self.mapToGlobal(QPoint(0, self.height()))
        self.menu.popup(pos)
    
    def add_action(self, text, on_click=None, icon=None, tool_tip=None):
        """
        添加菜单项
        
        Args:
            text: 菜单项文本
            on_click: 点击菜单项的回调函数
            icon: 菜单项图标
            tool_tip: 菜单项提示文本
        """
        if not self.menu:
            self.menu = QMenu(self)
        
        action = QAction(text, self)
        
        if icon:
            action.setIcon(icon)
        
        if tool_tip:
            action.setToolTip(tool_tip)
        
        if on_click:
            action.triggered.connect(on_click)
        
        self.menu.addAction(action)
        return action
    
    def add_separator(self):
        """添加分隔线"""
        if not self.menu:
            self.menu = QMenu(self)
        
        self.menu.addSeparator()
    
    def clear_menu(self):
        """清空菜单"""
        if self.menu:
            self.menu.clear()
    
    def show_menu(self):
        """显示菜单"""
        if self.menu and not self.menu.isEmpty():
            pos = self.mapToGlobal(QPoint(0, self.height()))
            self.menu.popup(pos)
    
    def set_menu_style(self, style_sheet):
        """
        设置菜单样式
        
        Args:
            style_sheet: QSS样式表
        """
        if self.menu:
            self.menu.setStyleSheet("background-color : red;")