from PySide6.QtWidgets import QComboBox, QStyledItemDelegate, QStyle, QStyleOptionComboBox, QApplication
from PySide6.QtCore import Qt, QPropertyAnimation, Property, QEasingCurve, QRect, QPoint
from PySide6.QtGui import QColor, QPalette, QPainter, QPen, QPolygon

class ComboBox(QComboBox):
    def __init__(self, parent=None, border_radius: int = 4,font_size : int = 13,border_width :int = 1):
        super().__init__(parent)
        self.font_size = font_size
        self.border_radius = border_radius
        self.border_width  = border_width
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        self._arrow_color = QColor()
        
        # Customize the combobox appearance
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        
        # Set up color animation
        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(200)
        self._animation.setEasingCurve(QEasingCurve.Type.OutQuad)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # Dark mode colors
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")
            self._arrow_color = QColor("#FFFFFF")
            self._dropdown_bg = QColor("#2E2E2E")
            self._dropdown_text = QColor("#FFFFFF")
            self._dropdown_hover = QColor("#424242")
        else:
            # Light mode colors
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
            self._arrow_color = QColor("#000000")
            self._dropdown_bg = QColor("#FFFFFF")
            self._dropdown_text = QColor("#000000")
            self._dropdown_hover = QColor("#F0F0F0")
        
        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """Update the combobox style sheet with custom arrow button borders"""
        style = f"""
        ComboBox {{
            font-size : {self.font_size}px;
            background-color: {self._bg_color.name()};
            border: {self.border_width}px solid {self._border_color.name()};
            border-top: {self.border_width}px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            border-radius: {self.border_radius}px;
            padding: 5px 10px;
            min-width: 100px;
            text-align: left;
        }}
        
        ComboBox:hover {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        
        ComboBox:pressed {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        
        /* Dropdown arrow button styling */
        ComboBox::drop-down {{
            subcontrol-origin: padding;
            subcontrol-position: center right;
            width: 20px;
            border-left: 0px solid {self._border_color.name()};
            border-top-right-radius: {self.border_radius}px;
            border-bottom-right-radius: {self.border_radius}px;
            background-color: transparent;
        }}
        
        /* Dropdown list styling */
        ComboBox QAbstractItemView {{
            background-color: {self._dropdown_bg.name()};
            color: {self._dropdown_text.name()};
            border: 1px solid {self._border_color.name()};
            border-radius: {self.border_radius}px;
            selection-background-color: {self._dropdown_hover.name()};
            selection-color: {self._dropdown_text.name()};
            outline: none;
        }}
        
        ComboBox QAbstractItemView::item {{
            padding: 5px 10px;
        }}
        
        ComboBox QAbstractItemView::item:hover {{
            background-color: {self._dropdown_hover.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def paintEvent(self, event):
        # First paint the default combobox
        super().paintEvent(event)
        
        # Then draw our custom arrow
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Get the arrow button rectangle
        opt = QStyleOptionComboBox()
        self.initStyleOption(opt)
        arrow_rect = self.style().subControlRect(
            QStyle.CC_ComboBox, 
            opt, 
            QStyle.SC_ComboBoxArrow,
            self
        )
        
        # Draw the arrow
        painter.setPen(QPen(self._arrow_color, 1.5))
        
        # Calculate arrow points (downward pointing triangle)
        arrow_size = 4
        center = arrow_rect.center()
        top = QPoint(center.x() - arrow_size, center.y() - arrow_size//2)
        bottom = QPoint(center.x(), center.y() + arrow_size//2)
        right = QPoint(center.x() + arrow_size, center.y() - arrow_size//2)
        
        # Draw the arrow as a polygon
        arrow = QPolygon([top, bottom, right])
        painter.drawPolyline(arrow)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()

    def showPopup(self):
        self._animate_color(self._pressed_color)
        super().showPopup()
    
    def hidePopup(self):
        self._animate_color(self._hover_color if self.underMouse() else self._default_color)
        super().hidePopup()


class ButtonComboBoxItemDelegate(QStyledItemDelegate):
    def __init__(self, parent=None):
        super().__init__(parent)
    
    def paint(self, painter, option, index):
        option.palette.setColor(QPalette.Highlight, QColor("transparent"))
        option.palette.setColor(QPalette.HighlightedText, index.data(Qt.ForegroundRole))
        super().paint(painter, option, index)