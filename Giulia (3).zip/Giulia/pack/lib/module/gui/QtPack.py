from turtle import Shape
from PySide6.QtCore import *
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from enum import Enum
import socket

class Pack:

    def check_port_connectivity(host, port=80, timeout=5):
        try:
            socket.setdefaulttimeout(timeout)
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((host, port))
            s.close()
            return True, "TCP : True"
        except socket.error as e:
            return False, f"TCP Error: {str(e)}"
