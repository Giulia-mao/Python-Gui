from pack.lib.module.gui.QtPack import *

class ToggleSwitchButton(QToolButton):
    def __init__(self, parent: QWidget, focus: bool = False):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setCheckable(True)
        
        # Focus policy
        if not focus:
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        
        # Animation properties
        self.checked_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        
        # Visual properties
        self.border_radius = 13  # More rounded for switch look
        self.switch_width = 50   # Width of the switch
        self.switch_height = 30  # Height of the switch
        self.thumb_margin = 3    # Margin around the thumb
        self.thumb_radius = 10   # Radius of the thumb
        
        # Set fixed size
        
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            # Track colors
            self.track_off = QColor("#424242")
            self.track_on = QColor("#0084FF")
            
            # Thumb colors
            self.thumb_off = QColor("#E0E0E0")
            self.thumb_on = QColor("#FFFFFF")
        else:
            # Track colors
            self.track_off = QColor("#E0E0E0")
            self.track_on = QColor("#0084FF")
            
            # Thumb colors
            self.thumb_off = QColor("#FFFFFF")
            self.thumb_on = QColor("#FFFFFF")

    def update_animation(self):
        # Update checked animation only
        if self.isChecked() and self.checked_animation_value < 1:
            self.checked_animation_value += 0.1
            if self.checked_animation_value > 1:
                self.checked_animation_value = 1
        elif not self.isChecked() and self.checked_animation_value > 0:
            self.checked_animation_value -= 0.1
            if self.checked_animation_value < 0:
                self.checked_animation_value = 0

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Calculate track color
        track_color = QColor(
            self.track_off.red() + int((self.track_on.red() - self.track_off.red()) * self.checked_animation_value),
            self.track_off.green() + int((self.track_on.green() - self.track_off.green()) * self.checked_animation_value),
            self.track_off.blue() + int((self.track_on.blue() - self.track_off.blue()) * self.checked_animation_value)
        )
        
        # Draw track
        painter.setBrush(QBrush(track_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(self.rect(), self.border_radius, self.border_radius)
        
        # Calculate thumb position (left to right)
        thumb_x = self.thumb_margin + (self.width() - 2 * self.thumb_margin - self.thumb_radius * 2) * self.checked_animation_value
        
        # Calculate thumb color
        thumb_color = QColor(
            self.thumb_off.red() + int((self.thumb_on.red() - self.thumb_off.red()) * self.checked_animation_value),
            self.thumb_off.green() + int((self.thumb_on.green() - self.thumb_off.green()) * self.checked_animation_value),
            self.thumb_off.blue() + int((self.thumb_on.blue() - self.thumb_off.blue()) * self.checked_animation_value)
        )
        
        # Draw thumb
        painter.setBrush(QBrush(thumb_color))
        painter.setPen(Qt.PenStyle.NoPen)
        thumb_rect = QRectF(thumb_x, self.thumb_margin, 
                           self.thumb_radius * 2, self.height() - 2 * self.thumb_margin)
        painter.drawRoundedRect(thumb_rect, self.thumb_radius, self.thumb_radius)

    def Checked(self, value: bool):
        self.setChecked(value)

    def returnChecked(self):
        return self.isChecked()
class ToggleButton(QPushButton):
    def __init__(self, Content: str, parent: QWidget = None, focus: bool = False):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setCheckable(True)
        
        # Focus policy
        if not focus:
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setText(Content)
        # Animation properties
        self.animation_value = 0
        self.pressed_animation_value = 0
        self.checked_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.hovered = False
        self.pressed_state = False
        
        # Visual properties
        self.border_radius = 4
        self.font_size = 13
        
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            # Normal state colors
            self.normal_bg = QColor("#262626")
            self.normal_border = QColor("#2E2E2E")
            self.hover_bg = QColor("#424242")
            self.hover_border = QColor("#2E2E2E")
            self.pressed_bg = QColor("#5A5A5A")
            self.pressed_border = QColor("#2E2E2E")
            
            # Checked state colors
            self.checked_bg = QColor(0, 132, 255)  # #0084ff
            self.checked_border = QColor(0, 132, 255)
            self.checked_hover_bg = QColor(0, 123, 237)  # #007bed
            self.checked_pressed_bg = QColor(0, 104, 201)  # #0068c9
            
            # Focus state colors
            self.focus_border = QColor(0, 102, 255)  # #0066ff
            self.focus_hover_border = QColor(58, 137, 255)  # #3a89ff
            
            self.text_color = QColor(255, 255, 255)
            self.checked_text_color = QColor(0, 0, 0)
            self._border_top = QColor("#424242")
        else:
            # Normal state colors
            self.normal_bg = QColor("#FFFFFF")  # #eaeaea
            self.normal_border = QColor("#C9C9C9")  # #cbcbcb
            self.hover_bg = QColor("#DADADA")  # #d8d8d8
            self.hover_border = QColor("#C9C9C9")  # #c7c7c7
            self.pressed_bg = QColor(183, 183, 183)  # #c6c6c6
            self.pressed_border = QColor(198, 198, 198)
            
            # Checked state colors
            self.checked_bg = QColor(0, 132, 255)  # #0084ff
            self.checked_border = QColor(0, 132, 255)
            self.checked_hover_bg = QColor(0, 123, 237)  # #007bed
            self.checked_pressed_bg = QColor(0, 104, 201)  # #0068c9
            
            # Focus state colors
            self.focus_border = QColor(116, 172, 255)  # #74acff
            self.focus_hover_border = QColor(69, 143, 255)  # #458fff
            
            self.text_color = QColor(0, 0, 0)
            self.checked_text_color = QColor(255, 255, 255)

    def enterEvent(self, event):
        self.hovered = True
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        super().mouseReleaseEvent(event)

    def update_animation(self):
        # Update hover animation
        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        # Update pressed animation
        if self.pressed_state and self.pressed_animation_value < 1:
            self.pressed_animation_value += 0.1
            if self.pressed_animation_value > 1:
                self.pressed_animation_value = 1
        elif not self.pressed_state and self.pressed_animation_value > 0:
            self.pressed_animation_value -= 0.1
            if self.pressed_animation_value < 0:
                self.pressed_animation_value = 0

        # Update checked animation
        if self.isChecked() and self.checked_animation_value < 1:
            self.checked_animation_value += 0.1
            if self.checked_animation_value > 1:
                self.checked_animation_value = 1
        elif not self.isChecked() and self.checked_animation_value > 0:
            self.checked_animation_value -= 0.1
            if self.checked_animation_value < 0:
                self.checked_animation_value = 0

        # Calculate background color
        if self.checked_animation_value > 0:
            # Transition to checked state
            base_bg = QColor(
                self.normal_bg.red() + int((self.checked_bg.red() - self.normal_bg.red()) * self.checked_animation_value),
                self.normal_bg.green() + int((self.checked_bg.green() - self.normal_bg.green()) * self.checked_animation_value),
                self.normal_bg.blue() + int((self.checked_bg.blue() - self.normal_bg.blue()) * self.checked_animation_value)
            )
            
            hover_bg = QColor(
                self.hover_bg.red() + int((self.checked_hover_bg.red() - self.hover_bg.red()) * self.checked_animation_value),
                self.hover_bg.green() + int((self.checked_hover_bg.green() - self.hover_bg.green()) * self.checked_animation_value),
                self.hover_bg.blue() + int((self.checked_hover_bg.blue() - self.hover_bg.blue()) * self.checked_animation_value)
            )
            
            pressed_bg = QColor(
                self.pressed_bg.red() + int((self.checked_pressed_bg.red() - self.pressed_bg.red()) * self.checked_animation_value),
                self.pressed_bg.green() + int((self.checked_pressed_bg.green() - self.pressed_bg.green()) * self.checked_animation_value),
                self.pressed_bg.blue() + int((self.checked_pressed_bg.blue() - self.pressed_bg.blue()) * self.checked_animation_value)
            )
            
            current_bg = QColor(
                base_bg.red() + int((hover_bg.red() - base_bg.red()) * self.animation_value),
                base_bg.green() + int((hover_bg.green() - base_bg.green()) * self.animation_value),
                base_bg.blue() + int((hover_bg.blue() - base_bg.blue()) * self.animation_value)
            )
            final_bg = QColor(
                current_bg.red() + int((pressed_bg.red() - current_bg.red()) * self.pressed_animation_value),
                current_bg.green() + int((pressed_bg.green() - current_bg.green()) * self.pressed_animation_value),
                current_bg.blue() + int((pressed_bg.blue() - current_bg.blue()) * self.pressed_animation_value)
            )
        else:
            # Normal state
            base_bg = self.normal_bg
            hover_bg = self.hover_bg
            pressed_bg = self.pressed_bg
            
            current_bg = QColor(
                base_bg.red() + int((hover_bg.red() - base_bg.red()) * self.animation_value),
                base_bg.green() + int((hover_bg.green() - base_bg.green()) * self.animation_value),
                base_bg.blue() + int((hover_bg.blue() - base_bg.blue()) * self.animation_value)
            )
            
            final_bg = QColor(
                current_bg.red() + int((pressed_bg.red() - current_bg.red()) * self.pressed_animation_value),
                current_bg.green() + int((pressed_bg.green() - current_bg.green()) * self.pressed_animation_value),
                current_bg.blue() + int((pressed_bg.blue() - current_bg.blue()) * self.pressed_animation_value)
            )

        # Calculate border color
        if self.hasFocus():
            if self.hovered:
                border_color = self.focus_hover_border
            else:
                border_color = self.focus_border
        elif self.checked_animation_value > 0:
            if self.hovered:
                border_color = QColor(
                    self.checked_border.red() + int((self.checked_hover_bg.red() - self.checked_border.red()) * self.animation_value),
                    self.checked_border.green() + int((self.checked_hover_bg.green() - self.checked_border.green()) * self.animation_value),
                    self.checked_border.blue() + int((self.checked_hover_bg.blue() - self.checked_border.blue()) * self.animation_value)
                )
            else:
                border_color = self.checked_border
        else:
            if self.hovered:
                border_color = self.hover_border
            else:
                border_color = self.normal_border

        # Calculate Content color
        text_color = QColor(
            self.text_color.red() + int((self.checked_text_color.red() - self.text_color.red()) * self.checked_animation_value),
            self.text_color.green() + int((self.checked_text_color.green() - self.text_color.green()) * self.checked_animation_value),
            self.text_color.blue() + int((self.checked_text_color.blue() - self.text_color.blue()) * self.checked_animation_value)
        )

        # Set style
        style = f"""
        background-color: rgb({final_bg.red()}, {final_bg.green()}, {final_bg.blue()});
        border: 1px solid rgb({border_color.red()}, {border_color.green()}, {border_color.blue()});
        color: rgb({text_color.red()}, {text_color.green()}, {text_color.blue()});
        border-radius: {self.border_radius}px;
        font-size: {self.font_size}px;
        padding: 5px 10px;
        """

        self.setStyleSheet(style)

    def Checked(self, value: bool):
        self.setChecked(value)

    def returnChecked(self):
        return self.isChecked()   
class ToolButton(QToolButton):
    def __init__(self, text="", parent=None,border_width : int = 1,text_alignment : str = "center"):
        super().__init__(parent)
        self.border_width = border_width
        self.text_alignment = text_alignment

        self.setText(text)
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        

        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

            
        
        # 设置颜色动画
        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(400)  # 更合理的动画时长
        self._animation.setEasingCurve(QEasingCurve.Type.OutExpo)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")

        else:
            # 浅色模式颜色
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
        
        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """更新按钮样式表"""
        style = f"""
        ToolButton {{
            background-color: {self._bg_color.name()};
            border: {self.border_width}px solid {self._border_color.name()};
            border-top: {self.border_width}px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            text-align: {self.text_alignment};
            border-radius: 3px;
            padding: 5px 10px;
            margin: 1px;
        }}
        ToolButton:hover {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        ToolButton:pressed {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()