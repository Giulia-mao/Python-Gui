from pack.lib.module.gui.QtPack import *

class HyperlinkButton(QPushButton):
    def __init__(self, Content: str, parent: QWidget, NavigateUri: str = "",text_align : str = "center"):
        super().__init__(Content, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Animation properties
        self.text_align = text_align
        self.animation_value = 0
        self.pressed_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.hovered = False
        self.pressed_state = False
        
        # Visual properties
        self.border_radius = 4
        self.font_size = 13
        self.letter_spacing = 0
        
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        if NavigateUri == "":
            pass
        else:
            self.clicked.connect(lambda : self.open_url(NavigateUri))
            
        
    def open_url(self, url_str):
        """通用打开URL方法"""
        url = QUrl(url_str)
        QDesktopServices.openUrl(url)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.normal_color = QColor("#0086fc")
            self.hover_color = QColor("#0086fc")  # Same as normal in dark mode
            self.pressed_color = QColor("#006aff")
            self.hover_bg_color = QColor(71, 71, 71, 150)  # #474747 with alpha
            self.pressed_bg_color = QColor(53, 53, 53, 150)  # #353535 with alpha
        else:
            self.normal_color = QColor("#004fb7")
            self.hover_color = QColor("#004fb7")  # Same as normal in light mode
            self.pressed_color = QColor("#006eff")
            self.hover_bg_color = QColor(194, 194, 194, 255)  # #e5e5e5 with alpha
            self.pressed_bg_color = QColor(205, 205, 205, 255)  # #d3d3d3 with alpha

    def enterEvent(self, event):
        self.hovered = True
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        super().mouseReleaseEvent(event)

    def update_animation(self):
        # Update hover animation
        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        # Update pressed animation
        if self.pressed_state and self.pressed_animation_value < 1:
            self.pressed_animation_value += 0.1
            if self.pressed_animation_value > 1:
                self.pressed_animation_value = 1
        elif not self.pressed_state and self.pressed_animation_value > 0:
            self.pressed_animation_value -= 0.1
            if self.pressed_animation_value < 0:
                self.pressed_animation_value = 0

        # Calculate Content color
        text_color = QColor(
            self.normal_color.red() + int((self.pressed_color.red() - self.normal_color.red()) * self.pressed_animation_value),
            self.normal_color.green() + int((self.pressed_color.green() - self.normal_color.green()) * self.pressed_animation_value),
            self.normal_color.blue() + int((self.pressed_color.blue() - self.normal_color.blue()) * self.pressed_animation_value)
        )

        # Calculate background color
        if self.pressed_animation_value > 0:
            bg_color = QColor(
                self.hover_bg_color.red() + int((self.pressed_bg_color.red() - self.hover_bg_color.red()) * self.pressed_animation_value),
                self.hover_bg_color.green() + int((self.pressed_bg_color.green() - self.hover_bg_color.green()) * self.pressed_animation_value),
                self.hover_bg_color.blue() + int((self.pressed_bg_color.blue() - self.hover_bg_color.blue()) * self.pressed_animation_value),
                int(150 * self.animation_value)  # Animate alpha for smooth appearance
            )
        else:
            bg_color = QColor(
                self.hover_bg_color.red(),
                self.hover_bg_color.green(),
                self.hover_bg_color.blue(),
                int(150 * self.animation_value)
            )

        # Set style
        style = f"""
        background-color: rgba({bg_color.red()}, {bg_color.green()}, {bg_color.blue()}, {bg_color.alpha()/255});
        border: 0px solid rgba(0, 0, 0, 0);
        color: rgb({text_color.red()}, {text_color.green()}, {text_color.blue()});
        letter-spacing: {self.letter_spacing}px;
        border-radius: {self.border_radius}px;
        font-size: {self.font_size}px;
        text-align : {self.text_align};
        
        """

        self.setStyleSheet(style)
class HyperlinkTolButton(QPushButton):
    def __init__(self, Content: str, parent: QWidget, NavigateUri: str = ""):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Animation properties
        self.animation_value = 0
        self.pressed_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.hovered = False
        self.pressed_state = False
        self.setText(Content)   
        # Visual properties
        self.font_size = 13
        self.letter_spacing = 0
        self.border_radiusC = self.height()//2 - 1
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        if NavigateUri == "":
            pass
        else:
            self.clicked.connect(lambda : self.open_url(NavigateUri))
    
    def paintEvent(self, arg__1):
        self.border_radiusC = self.height()
        return super().paintEvent(arg__1)
        
    def open_url(self, url_str):
        """通用打开URL方法"""
        url = QUrl(url_str)
        QDesktopServices.openUrl(url)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.normal_color = QColor("#0086fc")
            self.hover_color = QColor("#0086fc")  # Same as normal in dark mode
            self.pressed_color = QColor("#006aff")
            self.hover_bg_color = QColor(71, 71, 71, 150)  # #474747 with alpha
            self.pressed_bg_color = QColor(53, 53, 53, 150)  # #353535 with alpha
        else:
            self.normal_color = QColor("#004fb7")
            self.hover_color = QColor("#004fb7")  # Same as normal in light mode
            self.pressed_color = QColor("#006eff")
            self.hover_bg_color = QColor(194, 194, 194, 255)  # #e5e5e5 with alpha
            self.pressed_bg_color = QColor(205, 205, 205, 255)  # #d3d3d3 with alpha

    def enterEvent(self, event):
        self.hovered = True
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        super().mouseReleaseEvent(event)

    def update_animation(self):
        # Update hover animation
        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        # Update pressed animation
        if self.pressed_state and self.pressed_animation_value < 1:
            self.pressed_animation_value += 0.1
            if self.pressed_animation_value > 1:
                self.pressed_animation_value = 1
        elif not self.pressed_state and self.pressed_animation_value > 0:
            self.pressed_animation_value -= 0.1
            if self.pressed_animation_value < 0:
                self.pressed_animation_value = 0

        # Calculate Content color
        text_color = QColor(
            self.normal_color.red() + int((self.pressed_color.red() - self.normal_color.red()) * self.pressed_animation_value),
            self.normal_color.green() + int((self.pressed_color.green() - self.normal_color.green()) * self.pressed_animation_value),
            self.normal_color.blue() + int((self.pressed_color.blue() - self.normal_color.blue()) * self.pressed_animation_value)
        )

        # Calculate background color
        if self.pressed_animation_value > 0:
            bg_color = QColor(
                self.hover_bg_color.red() + int((self.pressed_bg_color.red() - self.hover_bg_color.red()) * self.pressed_animation_value),
                self.hover_bg_color.green() + int((self.pressed_bg_color.green() - self.hover_bg_color.green()) * self.pressed_animation_value),
                self.hover_bg_color.blue() + int((self.pressed_bg_color.blue() - self.hover_bg_color.blue()) * self.pressed_animation_value),
                int(150 * self.animation_value)  # Animate alpha for smooth appearance
            )
        else:
            bg_color = QColor(
                self.hover_bg_color.red(),
                self.hover_bg_color.green(),
                self.hover_bg_color.blue(),
                int(150 * self.animation_value)
            )

        # Set style
        style = f"""
        background-color: rgba({bg_color.red()}, {bg_color.green()}, {bg_color.blue()}, {bg_color.alpha()/255});
        border: 0px solid rgba(0, 0, 0, 0);
        color: rgb({text_color.red()}, {text_color.green()}, {text_color.blue()});
        letter-spacing: {self.letter_spacing}px;
        border-radius: {self.border_radiusC//2 - 1}px;
        font-size: {self.font_size}px;
        padding: 0px;
        """

        self.setStyleSheet(style)
