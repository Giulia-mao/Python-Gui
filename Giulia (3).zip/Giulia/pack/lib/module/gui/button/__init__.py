from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.shadow import *
class ButtonC(QPushButton):
    def __init__(self, text="", parent=None,border_width : int = 1,text_alignment : str = "center",shadow : bool = False):
        super().__init__(parent)
        self.shadow = shadow
        self.border_width = border_width
        self.text_alignment = text_alignment
        self.setText(text)
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        

        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

            
        
        # 设置颜色动画
        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(400)  # 更合理的动画时长
        self._animation.setEasingCurve(QEasingCurve.Type.OutExpo)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#424242")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#494949")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")

        else:
            # 浅色模式颜色
            self._default_color = QColor("#DADADA")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
        
        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """更新按钮样式表"""
        style = f"""
        ButtonC {{
            background-color: {self._bg_color.name()};
            border: {self.border_width}px solid {self._border_color.name()};
            border-top: {self.border_width}px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            text-align: {self.text_alignment};
            border-radius: 3px;
            padding: 5px 10px;
        }}
        ButtonC:hover {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        ButtonC:pressed {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        if self.shadow == False:
            pass
        else:
            self.shadow = Shadow.Show(self,None,dy=3,r=10)
            self.shadow.setObjectName("awa")

        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        if self.shadow == False:
            pass
        else:
            try:

                if self.shadow.findChild(QGraphicsDropShadowEffect,"awa") is not None:
                    pass
                else:
                    self.shadow.deleteLater()
            except RuntimeError:
                pass
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()
class Button(QPushButton):
    PressEvent = Signal(bool)
    ReleaseEvent = Signal(bool)
    def __init__(self, text="", parent=None, border_radius : int = 4,border_width : int = 1,text_alignment : str = "center",shadow : bool = False):
        super().__init__(text, parent)
        self.border_width = border_width
        self.border_radius = border_radius
        self.text_alignment = text_alignment
        self.shadow = shadow
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._top_border_color_pressed = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        

        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

            
        
        # 设置颜色动画
        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(500)  # 更合理的动画时长
        self._animation.setEasingCurve(QEasingCurve.Type.OutExpo)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._top_border_color_pressed = QColor("#424242")

            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#1d1d1d")
            self._text_color = QColor("#FFFFFF")

        else:
            # 浅色模式颜色
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
        
        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """更新按钮样式表"""
        style = f"""
        QPushButton {{
            background-color: {self._bg_color.name()};
            border: {self.border_width}px solid {self._border_color.name()};
            border-top: {self.border_width}px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            border-radius: {self.border_radius}px;
            text-align: {self.text_alignment};

        }}
        QPushButton:hover {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        QPushButton:pressed {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        if self.shadow == False:
            pass
        else:
            self.shadow = Shadow.Show(self,None,dy=3,r=10)
            self.shadow.setObjectName("awa")

        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        if self.shadow == False:
            pass
        else:
            try:

                if self.shadow.findChild(QGraphicsDropShadowEffect,"awa") is not None:
                    pass
                else:
                    self.shadow.deleteLater()
            except RuntimeError:
                pass
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        self.PressEvent.emit(True)
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        self.ReleaseEvent.emit(False)
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()

class StyleButton(QPushButton):
    '''
    * 示例Style列表
    "default" : 默认样式

    Style = [
        [#262626 , # 默认颜色
        #2E2E2E  , # 边框颜色
        #424242  , # 上边框颜色
        #424242  , # 悬停颜色
        #ffffff  , # 文字颜色
        #5A5A5A ], # 深色主题样式 # 按下颜色
        [#FFFFFF ,
        #C9C9C9 ,
        #BEBEBE ,
        #DADADA ,
        #000000 ,
        #B9B9B9 ]  # 明亮主题样式
    ] 
    # 若空列表使用 "default" 代替，为默认样式
    defaultStyle = [
        ["default"], # 深色主题样式
        ["default"]  # 明亮主题样式
    ]
    '''
    PressEvent = Signal(bool)
    ReleaseEvent = Signal(bool)
    
    def __init__(self, text="", parent=None, border_radius : int = 4,border_width : int = 1,style : str = "default"):
        super().__init__(text, parent)
        self.border_width = border_width
        self.border_radius = border_radius
        self._default_color = QColor()
        self._bg_color = QColor()
        self._border_color = QColor()
        self._top_border_color = QColor()
        self._hover_color = QColor()
        self._pressed_color = QColor()
        self._text_color = QColor()
        self.stylec = style
        # Style 列表分析

        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

        
        # 设置颜色动画

        self._animation = QPropertyAnimation(self, b"bgColor")
        self._animation.setDuration(700)  # 更合理的动画时长
        self._animation.setEasingCurve(QEasingCurve.Type.OutExpo)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        if self.stylec == "default":

            if is_dark:
                # 深色模式颜色
                self._default_color = QColor("#262626")
                self._border_color = QColor("#2E2E2E")
                self._top_border_color = QColor("#424242")
                self._hover_color = QColor("#424242")
                self._pressed_color = QColor("#5A5A5A")
                self._text_color = QColor("#FFFFFF")

            else:
                # 浅色模式颜色
                self._default_color = QColor("#FFFFFF")
                self._border_color = QColor("#C9C9C9")
                self._top_border_color = QColor("#BEBEBE")
                self._hover_color = QColor("#DADADA")
                self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
        else:
            if is_dark:
                # 深色模式颜色
                if self.stylec[0][0] == "default":
                    self._default_color = QColor("#262626")
                    self._border_color = QColor("#2E2E2E")
                    self._top_border_color = QColor("#424242")
                    self._hover_color = QColor("#424242")
                    self._pressed_color = QColor("#5A5A5A")
                    self._text_color = QColor("#FFFFFF")
                else:

                    self._default_color = QColor(self.stylec[0][0])
                    self._border_color = QColor(self.stylec[0][1])
                    self._top_border_color = QColor(self.stylec[0][2])
                    self._hover_color = QColor(self.stylec[0][3])
                    self._pressed_color = QColor(self.stylec[0][5])
                    self._text_color = QColor(self.stylec[0][4])

            else:
                if self.stylec[1][0] == "default":
                    self._default_color = QColor("#FFFFFF")
                    self._border_color = QColor("#C9C9C9")
                    self._top_border_color = QColor("#BEBEBE")
                    self._hover_color = QColor("#DADADA")
                    self._pressed_color = QColor("#B9B9B9")
                    self._text_color = QColor("#000000")
                else:

                # 浅色模式颜色
                    self._default_color = QColor(self.stylec[1][0])
                    self._border_color = QColor(self.stylec[1][1])
                    self._top_border_color = QColor(self.stylec[1][2])
                    self._hover_color = QColor(self.stylec[1][3])
                    self._pressed_color = QColor(self.stylec[1][5])
                    self._text_color = QColor(self.stylec[1][4])

        self._bg_color = self._default_color
        self._update_style()

    def _update_style(self):
        """更新按钮样式表"""
        style = f"""
        StyleButton {{
            background-color: {self._bg_color.name()};
            border: {self.border_width}px solid {self._border_color.name()};
            border-top: {self.border_width}px solid {self._top_border_color.name()};
            color: {self._text_color.name()};
            border-radius: {self.border_radius}px;
        }}
        StyleButton:hover {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        StyleButton:pressed {{
            border-top: 1px solid {self._top_border_color.name()};
        }}
        """
        self.setStyleSheet(style)
    
    def getBgColor(self):
        return self._bg_color
    
    def setBgColor(self, color):
        self._bg_color = color
        self._update_style()
    
    bgColor = Property(QColor, getBgColor, setBgColor)
    
    def enterEvent(self, event):
        self._animate_color(self._hover_color)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animate_color(self._default_color)
        super().leaveEvent(event)
    
    def mousePressEvent(self, event):
        self.PressEvent.emit(True)
        if event.button() == Qt.LeftButton:
            self._animate_color(self._pressed_color)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        self.ReleaseEvent.emit(False)
        if event.button() == Qt.LeftButton:
            target = self._hover_color if self.underMouse() else self._default_color
            self._animate_color(target)
        super().mouseReleaseEvent(event)
    
    def _animate_color(self, target_color):
        self._animation.stop()
        self._animation.setStartValue(self._bg_color)
        self._animation.setEndValue(target_color)
        self._animation.start()
