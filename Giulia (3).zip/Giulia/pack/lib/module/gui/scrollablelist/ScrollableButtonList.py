from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.button import *
from pack.lib.module.gui.button import Hyperlink
from pack.lib.module.gui.button import TolButton
from pack.lib.module.gui.frame import FrameC
from pack.lib.module.gui.Separator import *
class ScrollableButtonList(QWidget):
    def __init__(self, parent=None,border_radius : int = 0,border_width : int = 0):
        super().__init__(parent)
        self.border_radius = border_radius
        self.border_width = border_width
        self.initUI()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.setStyleSheet(f"""

                ScrollableButtonList{{
                    background-color : rgba(45,45,45,0);
                    border-color : rgba(45,45,45,0);
                    border-style : solid;
                    border-width : {self.border_width}px;
                    border-radius : {self.border_radius}px;
                }}
                ScrollableButtonList::scroll-bar:vertical,
                ScrollableButtonList::scroll-bar:horizontal {{
                    width: 0;
                    height: 0;
                    background: transparent;
                }}
            """)
        else:
            self.setStyleSheet(
                f"""
                ScrollableButtonList{{
                    background-color : rgba(243,243,243,0);
                    border-color : rbga(168,168,168,0);
                    border-style : solid;
                    border-radius : {self.border_radius}px;

                    border-width : {self.border_width}px;
                }}
            """
            )
    def initUI(self):
        # 主布局
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # 创建可滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # 禁用水平滚动条
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)    # 需要时显示垂直滚动条
        self.scroll_area.setStyleSheet("QScrollArea { border: none; }")

        # 创建包含按钮的容器
        self.button_container = FrameC()
        # self.button_container.setStyleSheet("background: red;")
        self.button_layout = QVBoxLayout(self.button_container)
        self.button_layout.setContentsMargins(3,3, 3, 3)
        self.button_layout.setSpacing(2)
        self.button_layout.setAlignment(Qt.AlignTop)  # 按钮从顶部开始排列
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 隐藏水平滚动条
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 将容器设置为滚动区域的子部件
        self.scroll_area.setWidget(self.button_container)
        
        # 将滚动区域添加到主布局
        self.main_layout.addWidget(self.scroll_area)

        # 设置示例按钮（实际使用时可以动态添加）

    def addButton(self, text, onClick=None,event2 = None,button_height : int = 25):
        """动态添加按钮"""
        button = Button(border_width=0,text_alignment="left",shadow=True)
        button.setText(text)
        button.setFixedHeight(button_height)
        button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        button.clicked.connect(lambda : onClick())

        self.button_layout.addWidget(button)
    def addWidget(self,widget):
        self.button_layout.addWidget(widget)
    def addSeparator(self):
        self.button_layout.addWidget(Separator(None))
    def clearButtons(self):
        """清除所有按钮"""
        while self.button_layout.count():
            item = self.button_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

class ScrollableHyperlinkButtonList(QFrame):
    def __init__(self, parent=None,button_shadow_r : int = 5):
        super().__init__(parent)
        self.button_shadow_r = button_shadow_r
        self.initUI()
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.setStyleSheet("""

                ScrollableHyperlinkButtonList{
                    background-color : rgba(45,45,45,0);
                    border-color : rgba(45,45,45,0);
                    border-style : solid;
                    border-width : 1px;
                }
                ScrollableHyperlinkButtonList::scroll-bar:vertical,
                ScrollableHyperlinkButtonList::scroll-bar:horizontal {
                    width: 0;
                    height: 0;
                    background: transparent;
                }
            """)
        else:
            self.setStyleSheet(
                """
                ScrollableHyperlinkButtonList{
                    background-color : rgba(243,243,243,0);
                    border-color : rbga(168,168,168,0);
                    border-style : solid;
                    border-width : 1px;
                }
            """
            )
    def initUI(self):
        # 主布局
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # 创建可滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)  # 禁用水平滚动条
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)    # 需要时显示垂直滚动条
        self.scroll_area.setStyleSheet("QScrollArea { border: none; }")

        # 创建包含按钮的容器
        self.button_container = FrameC()
        # self.button_container.setStyleSheet("background: red;")
        self.button_layout = QVBoxLayout(self.button_container)
        self.button_layout.setContentsMargins(5,5, 5, 5)
        self.button_layout.setSpacing(0)
        self.button_layout.setAlignment(Qt.AlignTop)  # 按钮从顶部开始排列
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 隐藏水平滚动条
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # 将容器设置为滚动区域的子部件
        self.scroll_area.setWidget(self.button_container)
        
        # 将滚动区域添加到主布局
        self.main_layout.addWidget(self.scroll_area)

        # 设置示例按钮（实际使用时可以动态添加）

    def addButton(self, text, onClick=None):
        """动态添加按钮"""
        button = Hyperlink.HyperlinkButton(text,None,onClick)
        button.setFixedHeight(30)
        button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        if onClick:
            button.clicked.connect(onClick)
        self.button_layout.addWidget(button)

    def clearButtons(self):
        """清除所有按钮"""
        while self.button_layout.count():
            item = self.button_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()