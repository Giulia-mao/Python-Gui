from pack.lib.module.gui.button import Button
from pack.lib.module.gui.widget import PopupWidget
from pack.lib.module.gui.scrollablelist import ScrollableButtonList
from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.frame import AnimFrame
from pack.lib.module.gui.shadow import *
from PySide6.QtGui import QPainter, QPen, QPolygon
from PySide6.QtCore import QPropertyAnimation, Property, QEasingCurve, QPoint
from pack.lib.module.gui.button import Button
from pack.lib.module.gui.widget import PopupWidget
from pack.lib.module.gui.scrollablelist import ScrollableButtonList
from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.frame import AnimFrame
from pack.lib.module.gui.shadow import *
from PySide6.QtGui import QPainter, QPen, QPolygon
from PySide6.QtCore import QPropertyAnimation, Property, QEasingCurve, QPoint

class DropDownButton(Button):
    def __init__(self, Content='', parent=None, border_radius=4, 
                 List_Widget_Height: int = 100, List_Widget_Width: int = 200, 
                 button_shadow_r: int = 5, border_width: int = 1,
                 arrow_color: str = None, arrow_size: int = 4):
        super().__init__(str(Content), parent, border_width=border_width)
        self.clicked.connect(self._on_click)
        self.button_shadow_r = button_shadow_r
        self.border_radius = border_radius
        self.arrow_size = arrow_size
        
        # 初始化箭头旋转属性
        self._arrow_rotation = 0  # 0度向下，180度向上
        
        # 自动检测主题颜色
        self._arrow_color = self._get_theme_arrow_color()
        if arrow_color:
            self._arrow_color = QColor(arrow_color)
        
        # 样式设置
        self.List_Widget_Width = List_Widget_Width
        self.List_Widget_Height = List_Widget_Height
        if self.List_Widget_Width < 100:
            self.List_Widget_Width = 100

        self._init_menu_()
        
        # 设置箭头动画
        self._arrow_animation = QPropertyAnimation(self, b"arrowRotation")
        self._arrow_animation.setDuration(2500)
        self._arrow_animation.setEasingCurve(QEasingCurve.Type.OutQuad)

    def _get_theme_arrow_color(self):
        """根据当前主题自动获取箭头颜色"""
        # 获取当前应用的调色板
        palette = QApplication.palette()
        window_color = palette.window().color()
        
        # 计算亮度来判断是深色还是浅色主题
        lightness = window_color.lightness()
        
        # 如果背景色较暗，使用白色箭头；否则使用黑色箭头
        if lightness < 128:  # 深色主题
            return QColor("#FFFFFF")  # 白色
        else:  # 浅色主题
            return QColor("#000000")  # 黑色

    def update_arrow_color_for_theme(self):
        """更新箭头颜色以适应主题变化"""
        self._arrow_color = self._get_theme_arrow_color()
        self.update()
    def addSeparator(self):
        self.item_list.addSeparator()
    def getArrowRotation(self):
        return self._arrow_rotation

    def setArrowRotation(self, rotation):
        self._arrow_rotation = rotation
        self.update()  # 触发重绘

    arrowRotation = Property(float, getArrowRotation, setArrowRotation)

    def _init_menu_(self):
        self._menu = PopupWidget(self)
        self._menu.setAttribute(Qt.WA_TranslucentBackground)
        self._menu.setStyleSheet("background: transparent; border: none;")
        self._menu.resize(self.List_Widget_Width + 10, self.List_Widget_Height + 10)

        self.item_list = ScrollableButtonList.ScrollableButtonList(self._menu)
        self.item_list.show()

        # 设置阴影效果
        self.shadow_effect = QGraphicsDropShadowEffect(self.item_list)
        self.shadow_effect.setBlurRadius(5)
        self.shadow_effect.setColor(QColor(0, 0, 0, 255))
        self.shadow_effect.setOffset(0, 3)
        self.item_list.setGraphicsEffect(self.shadow_effect)
        self.shadow_effect.setEnabled(False)
        
        self._menu.setFocusOutEvent(self._on_menu_focus_out)

    def addButton(self, text, onClick=None):
        """动态添加按钮"""
        self.item_list.addButton(text, onClick)

    def setArrowColor(self, color):
        """设置箭头颜色"""
        self._arrow_color = QColor(color)
        self.update()

    def setArrowSize(self, size):
        """设置箭头大小"""
        self.arrow_size = size
        self.update()

    def paintEvent(self, event):
        """重绘事件，添加自定义箭头"""
        super().paintEvent(event)
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # 计算箭头位置（右侧区域）
        arrow_rect = QRect(self.width() - 25, 0, 20, self.height())
        
        # 绘制箭头
        painter.setPen(QPen(self._arrow_color, 1.5))
        
        # 计算箭头点（考虑旋转动画）
        center = arrow_rect.center()
        arrow_size = self.arrow_size
        
        # 根据旋转角度计算箭头方向
        if self._arrow_rotation == 0:  # 向下
            top = QPoint(center.x() - arrow_size, center.y() - arrow_size//2)
            bottom = QPoint(center.x(), center.y() + arrow_size//2)
            right = QPoint(center.x() + arrow_size, center.y() - arrow_size//2)
        else:  # 向上
            top = QPoint(center.x() - arrow_size, center.y() + arrow_size//2)
            bottom = QPoint(center.x(), center.y() - arrow_size//2)
            right = QPoint(center.x() + arrow_size, center.y() + arrow_size//2)
        
        # 绘制箭头多边形
        arrow = QPolygon([top, bottom, right])
        painter.drawPolyline(arrow)

    def _animate_arrow(self, show_menu: bool):
        """箭头旋转动画"""
        target_rotation = 180 if show_menu else 0
        self._arrow_animation.stop()
        self._arrow_animation.setStartValue(self._arrow_rotation)
        self._arrow_animation.setEndValue(target_rotation)
        self._arrow_animation.start()

    def _on_menu_focus_out(self):
        """菜单失去焦点时的处理"""
        self.shadow_effect.setEnabled(False)
        self._menu.hide()
        self._animate_arrow(False)

    def animation(self):
        """显示动画效果"""
        if hasattr(self, '_menu'):
            self.item_list.setGeometry(QRect(5, 2, self.List_Widget_Width, self.List_Widget_Height))

    def _on_click(self):
        """按钮点击处理"""
        if hasattr(self, '_menu'):
            if self._menu.isVisible():
                # 如果菜单已显示，则隐藏
                self.shadow_effect.setEnabled(False)
                self._menu.hide()
                self._animate_arrow(False)
            else:
                # 显示菜单
                pos = self.mapToGlobal(QPoint(-5, self.height() + 5))
                self._menu.move(pos)
                self._menu.show()
                self.animation()
                self.shadow_effect.setEnabled(True)
                self._animate_arrow(True)

    def hideMenu(self):
        """隐藏下拉菜单"""
        if hasattr(self, '_menu') and self._menu.isVisible():
            self.shadow_effect.setEnabled(False)
            self._menu.hide()
            self._animate_arrow(False)

    def showMenu(self):
        """显示下拉菜单"""
        if hasattr(self, '_menu'):
            pos = self.mapToGlobal(QPoint(-5, self.height() + 5))
            self._menu.move(pos)
            self._menu.show()
            self.animation()
            self.shadow_effect.setEnabled(True)
            self._animate_arrow(True)

    def changeEvent(self, event):
        """处理主题变化事件"""
        super().changeEvent(event)
        if event.type() == QEvent.PaletteChange:
            self.update_arrow_color_for_theme()