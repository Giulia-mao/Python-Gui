
from pack.lib.module.gui.QtPack import *

class AnimatedFrame(QFrame):
    """具有缩放动画效果的交互控件"""
    
    # 控件状态枚举
    NORMAL = 0
    HOVER = 1
    PRESSED = 2
    DISABLED = 3
    hover = Signal(bool)
    pressed = Signal(bool)
    unhover = Signal(bool)
    mouseReleased = Signal(bool)
    mousePressed = Signal(bool)
    focusOut = Signal()  # 修改为无参数的信号
    
    def __init__(self, parent=None, layout : bool = True):
        super().__init__(parent)
        
        # 配置属性
        self._current_state = self.NORMAL
        self._scale_factor = 1.0  # 缩放因子
        self._pulse_radius = 0.0  # 涟漪动画半径
        self._pulse_opacity = 1.0  # 涟漪动画透明度
        
        # 样式配置
        self.border_radius = 3
        self.animation_duration = 300
        
        # 颜色配置
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        
        # 动画设置
        self.scale_animation = QPropertyAnimation(self, b"scale_factor")
        
        self.scale_animation.setEasingCurve(QEasingCurve.Type.OutExpo)
        
        # self.setCursor(Qt.PointingHandCursor)
        if layout:
            self.init_layout()
        else:
            pass
    def init_layout(self):
        """初始化布局管理器"""
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
    def add_widget(self, widget):
        """添加子控件"""
        self.main_layout.addWidget(widget)
    def update_colors(self):
        """根据系统主题初始化颜色方案"""
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.normal_bg_color = QColor(47, 47, 47)  # 主色
            self.hover_bg_color = QColor(57, 57, 57)   # 悬停色
            self.pressed_bg_color = QColor(37, 37, 37)  # 按下色
            self.disabled_bg_color = QColor(67, 67, 67)  # 禁用色
        else:
            self.normal_bg_color = QColor(255, 255, 255)  # 主色
            self.hover_bg_color = QColor(206, 206, 206)   # 悬停色
            self.pressed_bg_color = QColor(186, 186, 186)  # 按下色
            self.disabled_bg_color = QColor(176, 176, 176)  # 禁用色
    
    def set_scale_animation(self, Start: float, End: float,setDuration : int = 300,finished = None):
        self.scale_animation.setStartValue(Start)
        self.scale_animation.setEndValue(End)
        self.scale_animation.setDuration(setDuration)
        self.scale_animation.start()
        if finished is None:
            pass
        else:
            self.scale_animation.finished.connect(finished)

    def get_scale_factor(self):
        return self._scale_factor

    def set_scale_factor(self, value):
        self._scale_factor = value
        self.update()  # 触发重绘

    scale_factor = Property(float, get_scale_factor, set_scale_factor)
    
    def eventFilter(self, obj, event):
        if event.type() == QEvent.FocusOut:
            self.focusOut.emit()  # 发射无参数信号
        return super().eventFilter(obj, event)
    
    def setFocusOutEvent(self, handler):
        """设置焦点离开事件处理器"""
        self.focusOut.connect(handler)

    def mousePressEvent(self, event):
        """鼠标按下事件"""
        self.mousePressed.emit(True)
        super().mousePressEvent(event)
    
    def mouseReleaseEvent(self, event):
        """鼠标释放事件"""
        self.mouseReleased.emit(True)
    
    def enterEvent(self, event):
        self.hover.emit(True)
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        """鼠标离开事件"""
        self.unhover.emit(True)
        super().leaveEvent(event)
    
    def paintEvent(self, event):
        """自定义绘制，并缩放子控件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # 保存当前状态
        painter.save()
        
        # 计算控件尺寸和位置
        width = self.width()
        height = self.height()
        center = QPoint(width // 2, height // 2)
        
        # 根据当前状态选择背景颜色
        if not self.isEnabled():
            bg_color = self.disabled_bg_color
        elif self._current_state == self.PRESSED:
            bg_color = self.pressed_bg_color
        elif self._current_state == self.HOVER:
            bg_color = self.hover_bg_color
        else:  # NORMAL
            bg_color = self.normal_bg_color
        
        # 创建渐变背景
        gradient = QLinearGradient(0, 0, 0, height)
        gradient.setColorAt(0, bg_color.lighter(0))
        gradient.setColorAt(1, bg_color)
        
        # 应用缩放变换（以中心为原点）
        transform = QTransform()
        transform.translate(center.x(), center.y())
        transform.scale(self._scale_factor, self._scale_factor)
        transform.translate(-center.x(), -center.y())
        painter.setTransform(transform)
        
        # 绘制背景
        rect = self.rect().adjusted(0, 0, 0, 0)
        path = QPainterPath()
        path.addRoundedRect(rect, self.border_radius, self.border_radius)
        painter.fillPath(path, gradient)
        
        # 绘制边框
        border_color = bg_color.darker(120)
        painter.setPen(QPen(border_color, 1))
        painter.drawPath(path)
        
        painter.restore()

        # 缩放子控件
        for child in self.findChildren(QWidget):
            if child is self:
                continue
            # 计算缩放后的几何位置
            orig_geom = child.property("_orig_geom")
            if orig_geom is None:
                orig_geom = child.geometry()
                child.setProperty("_orig_geom", orig_geom)
            # 以容器中心为缩放中心
            cx, cy = self.width() / 2, self.height() / 2
            x = orig_geom.x() - cx
            y = orig_geom.y() - cy
            w = orig_geom.width()
            h = orig_geom.height()
            x = x * self._scale_factor + cx
            y = y * self._scale_factor + cy
            w = w * self._scale_factor
            h = h * self._scale_factor
            child.setGeometry(int(x), int(y), int(w), int(h))


