from turtle import Shape
from PySide6.QtCore import *
from PySide6.QtWidgets import *
from PySide6.QtGui import *
from enum import Enum
class FrameStyle:
    """封装QFrame的frameShape和frameShadow枚举"""
    
    class Shape(Enum):
        """框架形状枚举"""
        NoFrame = QFrame.NoFrame
        Box = QFrame.Box
        Panel = QFrame.Panel
        StyledPanel = QFrame.StyledPanel
        HLine = QFrame.HLine
        VLine = QFrame.VLine
        WinPanel = QFrame.WinPanel

    class Shadow(Enum):
        """框架阴影枚举"""
        Plain = QFrame.Plain
        Raised = QFrame.Raised
        Sunken = QFrame.Sunken

class Frame(QFrame):
    def __init__ (self, parent: QWidget):
        super().__init__(parent)


    def ReturnShape(self) -> FrameStyle.Shape:
        """返回当前框架的形状"""
        return FrameStyle.Shape(self.frameShape())

    def ReturnShadow(self) -> FrameStyle.Shadow:
        """返回当前框架的阴影"""
        return FrameStyle.Shadow(self.frameShadow())

    def ReturnStyle(self) -> tuple[FrameStyle.Shape, FrameStyle.Shadow]:
        """返回当前框架的形状和阴影"""
        return self.ReturnShape(), self.ReturnShadow()
    
    def SetShape(self, shape: FrameStyle.Shape):
        """设置框架的形状"""
        self.setFrameShape(shape.value)
    
    def SetShadow(self, shadow: FrameStyle.Shadow):
        """设置框架的阴影"""
        self.setFrameShadow(shadow.value)

    def SetStyle(self, shape: FrameStyle.Shape, shadow: FrameStyle.Shadow):
        """设置框架的形状和阴影"""
        self.SetShape(shape)
        self.SetShadow(shadow)

    def ReturnGeometryInfo(self) -> QRect:
        """返回框架的几何信息"""
        return self.geometry()
class GradientFrame(QFrame):
    hover = Signal(bool)
    pressed = Signal(bool)
    Release = Signal(bool)
    unhover = Signal(bool)
    focus = Signal(bool)

    def __init__(self, parent=None, border_radius: int = 0, border_width: int = 1, 
                  alpha: int = 255,
                 focus: bool = False, minsize: QSize = None, maxsize: QSize = None,Shadows : bool = True,text_align : str = "center"):
        super().__init__(parent)
        self.setMouseTracking(True)
        self.text_align = text_align
        # Size settings
        if minsize is not None:
            self.setMinimumSize(minsize)
        if maxsize is not None:
            self.setMaximumSize(minsize)
        
        # Focus policy
        if not focus:
            self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        
        # Animation properties
        self.animation_value = 0
        self.pressed_animation_value = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(16)
        self.hovered = False
        self.pressed_state = False

        # Visual properties
        self.border_width = border_width
        self.border_radius = border_radius

        self.alpha = alpha
        
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.start_color = QColor(45,45,45)
            self.end_color = QColor(61, 61, 61)
            self.border_color = QColor(61, 61, 61)
            self.end_border_color = QColor(61, 61, 61)
            self.pressed_color = QColor(35, 35, 35)
            self.focus_border_color = QColor(0, 102, 255)
            self.focus_hover_border_color = QColor(58, 137, 255)
        else:
            self.border_color = QColor(168, 168, 168)
            self.start_color = QColor(243, 243, 243)
            self.end_color = QColor(220, 220, 220)
            self.end_border_color = QColor(168, 168, 168)
            self.pressed_color = QColor(195, 195, 195)
            self.focus_border_color = QColor(0, 119, 255)
            self.focus_hover_border_color = QColor(69, 143, 255)
    
    def enterEvent(self, event):
        self.hovered = True
        self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hovered = False
        self.unhover.emit(True)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        self.pressed_state = True
        self.pressed.emit(True)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.pressed_state = False
        self.Release.emit(True)
        super().mouseReleaseEvent(event)

    def focusInEvent(self, event):
        self.focus.emit(True)
        super().focusInEvent(event)
        self.update_animation()

    def focusOutEvent(self, event):
        self.focus.emit(False)
        super().focusOutEvent(event)
        self.update_animation()

    def setOpacity(self, Opacity_num: float):
        effect = QGraphicsOpacityEffect()
        effect.setOpacity(Opacity_num)
        self.setGraphicsEffect(effect)
        
    def update_animation(self):
        # Update animation values
        if self.pressed_state and self.pressed_animation_value < 1:
            self.pressed_animation_value += 0.1
            if self.pressed_animation_value > 1:
                self.pressed_animation_value = 1
        elif not self.pressed_state and self.pressed_animation_value > 0:
            self.pressed_animation_value -= 0.1
            if self.pressed_animation_value < 0:
                self.pressed_animation_value = 0

        if self.hovered and self.animation_value < 1:
            self.animation_value += 0.1
            if self.animation_value > 1:
                self.animation_value = 1
        elif not self.hovered and self.animation_value > 0:
            self.animation_value -= 0.1
            if self.animation_value < 0:
                self.animation_value = 0

        # Calculate base color
        base_color = QColor(
            self.start_color.red() + int((self.end_color.red() - self.start_color.red()) * self.animation_value),
            self.start_color.green() + int((self.end_color.green() - self.start_color.green()) * self.animation_value),
            self.start_color.blue() + int((self.end_color.blue() - self.start_color.blue()) * self.animation_value),
            self.alpha
        )

        # Calculate pressed color
        current_color = QColor(
            base_color.red() + int((self.pressed_color.red() - base_color.red()) * self.pressed_animation_value),
            base_color.green() + int((self.pressed_color.green() - base_color.green()) * self.pressed_animation_value),
            base_color.blue() + int((self.pressed_color.blue() - base_color.blue()) * self.pressed_animation_value),
            self.alpha
        )

        # Calculate border color
        if self.hasFocus():
            if self.hovered:
                border_color = self.focus_hover_border_color
            else:
                border_color = self.focus_border_color
        else:
            border_color = QColor(
                self.border_color.red() + int((self.end_border_color.red() - self.border_color.red()) * self.animation_value),
                self.border_color.green() + int((self.end_border_color.green() - self.border_color.green()) * self.animation_value),
                self.border_color.blue() + int((self.end_border_color.blue() - self.border_color.blue()) * self.animation_value),
                self.alpha
            )

        # Set style
        style = f"""
        Button{{
        background-color: rgba({current_color.red()}, {current_color.green()}, {current_color.blue()}, {self.alpha/255});
        border-color: rgba({border_color.red()}, {border_color.green()}, {border_color.blue()}, {self.alpha/255});
        border-style: solid;
        outline: none;
        border-width: {self.border_width}px;
        border-radius: {self.border_radius}px;
        font-size: 13px;
        text-align : {self.text_align};
        padding : 5px;}}
        """
        
        self.setStyleSheet(style)

class FrameC(QFrame):
    def __init__(self, parent=None, border_radius : int = 4):
        super().__init__(parent)
        self.border_radius = border_radius
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")
            style = f"""
            FrameC {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
            }}
            """
            self.setStyleSheet(style)

        else:
            # 浅色模式颜色
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")

            style = f"""
            FrameC {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
            }}
            """
            self.setStyleSheet(style)