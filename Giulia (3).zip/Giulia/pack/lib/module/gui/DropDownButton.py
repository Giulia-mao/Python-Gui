from pack.lib.module.gui.button import Button
from pack.lib.module.gui.button import ButtonC
from pack.lib.module.gui.widget import PopupWidget
from pack.lib.module.gui.scrollablelist import ScrollableButtonList
from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.shadow import *

class DropDownButton(Button):
    def __init__(self, Content='', parent=None, border_radius=4, 
                 List_Widget_Height: int = 100,List_Widget_Width : int = 200,button_shadow_r : int = 5,border_width : int = 1,Direction : str = "right",shadow : bool = True,button_height : int = 25):
        super().__init__(str(Content),parent,border_width=border_width)
        self.clicked.connect(self._on_click)
        self.shadow = shadow
        self.button_height = button_height
        self.button_shadow_r = button_shadow_r
        self.border_radius = border_radius
        self.Direction = Direction
        #style
        self.List_Widget_Width = List_Widget_Width
        self.List_Widget_Height = List_Widget_Height
        if self.List_Widget_Width < 100:
            self.List_Widget_Width = 100
        
        self._init_menu_()



        # 设置阴影效果
        
    def _init_menu_(self):
        self._menu = PopupWidget(self)
        # 添加示例按钮t
        self._menu.setAttribute(Qt.WA_TranslucentBackground)  # 启用透明背景
        # 确保没有样式表干扰
        self._menu.setStyleSheet("background: transparent; border: none;")
        self._menu.resize(self.List_Widget_Width + 10,self.List_Widget_Height+10)
        self.item_list =ScrollableButtonList.ScrollableButtonList(self._menu)
        # self.item_list =ListWidget(self._menu,border_radius=self.border_radius)
        # self.item_list.Release.connect(self._on_menu_focus_out)
        self.item_list.show()
        # 设置焦点离开事
        Shadow.EffectC(self.item_list,dy=3)
        
        self._menu.setFocusOutEvent(self._on_menu_focus_out)


    # def addItems(self,var : list):
    #     self.item_list.addItems(var)
    def _on_menu_focus_out(self):
        """菜单失去焦点时的处理"""
        self._menu.hide()
    def onClick(self,onClick):
        if onClick == None:
            pass
        else:
            self._menu.hide()
            onClick()
    def addButton(self, text, onClick=None):
        """动态添加按钮"""

        self.item_list.addButton(str("   "+text),lambda : self.onClick(onClick),button_height=self.button_height)

    def addSeparator(self):
        self.item_list.addSeparator()
    def addWidget(self,widget):
        self.item_list.addWidget(widget)
    def animation(self):
        """显示动画效果"""
        if hasattr(self, '_menu'):
            
            
            
            # self.animo = QPropertyAnimation(self._menu)
            # self.animo.setTargetObject(self.item_list)
            # self.animo.setPropertyName(b'geometry')
            # self.animo.setStartValue(QRect(5,-400,self.List_Widget_Width,self.List_Widget_Height))
            # self.animo.setEndValue(QRect(5,2,self.List_Widget_Width,self.List_Widget_Height))
            # self.animo.setDuration(600)
            # self.animo.setEasingCurve(QEasingCurve.Type.OutExpo)
            # self.animo.start()
            pass
            self.item_list.setGeometry(QRect(5,2,self.List_Widget_Width,self.List_Widget_Height))

    def _on_click(self):
        """按钮点击处理"""
        if hasattr(self, '_menu'):
            # 计算显示位置（按钮左下角）
            if self.Direction == "right":
                pos = self.mapToGlobal(QPoint(-5, self.height()+5))
                self._menu.move(pos)
                self._menu.show()
                self.animation()
            if self.Direction == "left":
                pos = self.mapToGlobal(QPoint(-self.List_Widget_Width+self.width(), self.height()+5))
                self._menu.move(pos)
                self._menu.show()
                self.animation()
    def enterEvent(self, event):
        if self.shadow == True:

            self.Shadowx = Shadow.Show(self,dy=3,r=10,color=None)
            self.Shadowx.setObjectName("awa")

        return super().enterEvent(event)
    def leaveEvent(self, event):
        if self.shadow == True:
            try :
                if self.Shadowx.findChild(QGraphicsDropShadowEffect,"awa") is not None:
                    pass
                else:
                    self.Shadowx.deleteLater()
            except RuntimeError:
                pass

        return super().leaveEvent(event)
    
class DropDownButtonC(ButtonC):
    def __init__(self, Content='', parent=None, border_radius=4, 
                 List_Widget_Height: int = 100,List_Widget_Width : int = 200,button_shadow_r : int = 5,border_width : int = 1,Direction : str = "right",shadow : bool = True):
        super().__init__(str(Content),parent,border_width=border_width)
        self.clicked.connect(self._on_click)
        self.Shadow = shadow
        self.button_shadow_r = button_shadow_r
        self.border_radius = border_radius
        self.Direction = Direction
        #style
        self.List_Widget_Width = List_Widget_Width
        self.List_Widget_Height = List_Widget_Height
        if self.List_Widget_Width < 100:
            self.List_Widget_Width = 100
        
        self._init_menu_()



        # 设置阴影效果
        
    def _init_menu_(self):
        self._menu = PopupWidget(self)
        # 添加示例按钮t
        self._menu.setAttribute(Qt.WA_TranslucentBackground)  # 启用透明背景
        # 确保没有样式表干扰
        self._menu.setStyleSheet("background: transparent; border: none;")
        self._menu.resize(self.List_Widget_Width + 10,self.List_Widget_Height+10)
        self.item_list =ScrollableButtonList.ScrollableButtonList(self._menu)
        # self.item_list =ListWidget(self._menu,border_radius=self.border_radius)
        # self.item_list.Release.connect(self._on_menu_focus_out)
        self.item_list.show()
        # 设置焦点离开事
        Shadow.EffectC(self.item_list,dy=3)
        
        self._menu.setFocusOutEvent(self._on_menu_focus_out)


    # def addItems(self,var : list):
    #     self.item_list.addItems(var)
    def _on_menu_focus_out(self):
        """菜单失去焦点时的处理"""
        self._menu.hide()
    def onClick(self,onClick):
        if onClick == None:
            pass
        else:
            self._menu.hide()
            onClick()
    def addButton(self, text, onClick=None):
        """动态添加按钮"""

        self.item_list.addButton(str("   "+text),lambda : self.onClick(onClick))

    def addSeparator(self):
        self.item_list.addSeparator()
    def addWidget(self,widget):
        self.item_list.addWidget(widget)
    def animation(self):
        """显示动画效果"""
        if hasattr(self, '_menu'):
            
            
            
            # self.animo = QPropertyAnimation(self._menu)
            # self.animo.setTargetObject(self.item_list)
            # self.animo.setPropertyName(b'geometry')
            # self.animo.setStartValue(QRect(5,-400,self.List_Widget_Width,self.List_Widget_Height))
            # self.animo.setEndValue(QRect(5,2,self.List_Widget_Width,self.List_Widget_Height))
            # self.animo.setDuration(600)
            # self.animo.setEasingCurve(QEasingCurve.Type.OutExpo)
            # self.animo.start()
            pass
            self.item_list.setGeometry(QRect(5,2,self.List_Widget_Width,self.List_Widget_Height))

    def _on_click(self):
        """按钮点击处理"""
        if hasattr(self, '_menu'):
            # 计算显示位置（按钮左下角）
            if self.Direction == "right":
                pos = self.mapToGlobal(QPoint(-5, self.height()+5))
                self._menu.move(pos)
                self._menu.show()
                self.animation()
            if self.Direction == "left":
                pos = self.mapToGlobal(QPoint(-self.List_Widget_Width+self.width(), self.height()+5))
                self._menu.move(pos)
                self._menu.show()
                self.animation()
    def enterEvent(self, event):
        if self.Shadow == True:

            self.Shadowx = Shadow.Show(self,dy=3,r=10,color=None)
            self.Shadowx.setObjectName("awa")

        return super().enterEvent(event)
    def leaveEvent(self, event):
        if self.shadow == True:
            try :
                if self.Shadowx.findChild(QGraphicsDropShadowEffect,"awa") is not None:
                    pass
                else:
                    self.Shadowx.deleteLater()
            except RuntimeError:
                pass

        return super().leaveEvent(event)
    
    