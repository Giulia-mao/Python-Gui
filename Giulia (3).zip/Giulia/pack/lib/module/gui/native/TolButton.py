from pack.lib.module.gui.QtPack import *

class NativeToolButton(QToolButton):
    def __init__(self, text="", parent=None, border_radius : int = 4,border_width : int = 1):
        super().__init__(parent)
        self.border_radius = border_radius
        self.border_width = border_width
        self.update_colors()
        QApplication.instance().paletteChanged.connect(self.update_colors)

        self.setText(text)

    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            # 深色模式颜色
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")
            style = f"""
            NativeToolButton {{
                background-color: {self._default_color.name()};
                border: {self.border_width}px solid {self._border_color.name()};
                border-top: {self.border_width}px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
                padding : 0px;
            }}
            NativeToolButton:hover {{
                background-color : {self._hover_color.name()};

                border-top: 1px solid {self._top_border_color.name()};
            }}
            NativeToolButton:pressed {{
                background-color : {self._pressed_color.name()};
            
                border-top: 1px solid {self._top_border_color.name()};
            }}
            """
            self.setStyleSheet(style)

        else:
            # 浅色模式颜色
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")

            style = f"""
            NativeToolButton {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: {self.border_radius}px;
            }}
            NativeToolButton:hover {{
                background-color : {self._hover_color.name()};

                border-top: 1px solid {self._top_border_color.name()};
            }}
            NativeToolButton:pressed {{
                background-color : {self._pressed_color.name()};
            
                border-top: 1px solid {self._top_border_color.name()};
            }}
            """
            self.setStyleSheet(style)