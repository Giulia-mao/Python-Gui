from pack.lib.module.gui.QtPack import *

class HyperlinkButton(QPushButton):
    def __init__(self, Content: str, parent: QWidget, NavigateUri: str = ""):
        super().__init__(Content, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Visual properties
        self.border_radius = 4
        self.font_size = 13
        self.letter_spacing = 0
        
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        if NavigateUri == "":
            pass
        else:
            self.clicked.connect(lambda : self.open_url(NavigateUri))
            
        
    def open_url(self, url_str):
        """通用打开URL方法"""
        url = QUrl(url_str)
        QDesktopServices.openUrl(url)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.normal_color = QColor("#0086fc")
            self.hover_color = QColor("#0086fc")  # Same as normal in dark mode
            self.pressed_color = QColor("#006aff")
            self.hover_bg_color = QColor(71, 71, 71, 150)  # #474747 with alpha
            self.pressed_bg_color = QColor(53, 53, 53, 150)  # #353535 with alpha
            

            self.setStyleSheet(f"""
                QPushButton{{
                    background-color : rgba(0,0,0,0);
                    border : 1px solid rgba(0,0,0,0);
                    border-radius : {self.border_radius}px;
                    color : {self.normal_color.name()};
                }}
                QPushButton:hover{{
                    background-color : rgba({self.hover_bg_color.red()}, {self.hover_bg_color.green()}, {self.hover_bg_color.blue()}, {self.hover_bg_color.alpha()/255});
                    color : {self.hover_color.name()};

                }}
                QPushButton:pressed{{
                    background-color : rgba({self.pressed_bg_color.red()}, {self.pressed_bg_color.green()}, {self.pressed_bg_color.blue()}, {self.pressed_bg_color.alpha()/255});
                    color : {self.pressed_color.name()};
                }}
            """)
        else:
            self.normal_color = QColor("#004fb7")
            self.hover_color = QColor("#004fb7")  # Same as normal in light mode
            self.pressed_color = QColor("#006eff")
            self.hover_bg_color = QColor(194, 194, 194, 255)  # #e5e5e5 with alpha
            self.pressed_bg_color = QColor(205, 205, 205, 255)  # #d3d3d3 with alpha
            self.setStyleSheet(f"""
                QPushButton{{
                    background-color : rgba(0,0,0,0);
                    border : 1px solid rgba(0,0,0,0);
                    border-radius : {self.border_radius}px;
                    color : {self.normal_color.name()};
                }}
                QPushButton:hover{{
                    background-color : rgba({self.hover_bg_color.red()}, {self.hover_bg_color.green()}, {self.hover_bg_color.blue()}, {self.hover_bg_color.alpha()/255});
                    color : {self.hover_color.name()};

                }}
                QPushButton:pressed{{
                    background-color : rgba({self.pressed_bg_color.red()}, {self.pressed_bg_color.green()}, {self.pressed_bg_color.blue()}, {self.pressed_bg_color.alpha()/255});
                    color : {self.pressed_color.name()};
                }}
            """)
        # Set style
        
class HyperlinkTolButton(QPushButton):
    def __init__(self, Content: str, parent: QWidget, NavigateUri: str = ""):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Animation properties
        self.setText(Content)   
        # Visual properties
        self.font_size = 13
        self.letter_spacing = 0
        self.border_radiusC = self.height()//2 - 1
        # Color setup
        QApplication.instance().paletteChanged.connect(self.update_colors)
        self.update_colors()
        if NavigateUri == "":
            pass
        else:
            self.clicked.connect(lambda : self.open_url(NavigateUri))
    
    def paintEvent(self, arg__1):
        self.border_radiusC = self.height() //2 -1
        return super().paintEvent(arg__1)
        
    def open_url(self, url_str):
        """通用打开URL方法"""
        url = QUrl(url_str)
        QDesktopServices.openUrl(url)
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128

        if is_dark:
            self.normal_color = QColor("#0086fc")
            self.hover_color = QColor("#0086fc")  # Same as normal in dark mode
            self.pressed_color = QColor("#006aff")
            self.hover_bg_color = QColor(71, 71, 71, 150)  # #474747 with alpha
            self.pressed_bg_color = QColor(53, 53, 53, 150)  # #353535 with alpha
            

            self.setStyleSheet(f"""
                QPushButton{{
                    background-color : rgba(0,0,0,0);
                    border : 1px solid rgba(0,0,0,0);
                    border-radius : {self.border_radiusC}px;
                    color : {self.normal_color.name()};
                }}
                QPushButton:hover{{
                    background-color : rgba({self.hover_bg_color.red()}, {self.hover_bg_color.green()}, {self.hover_bg_color.blue()}, {self.hover_bg_color.alpha()/255});
                    color : {self.hover_color.name()};

                }}
                QPushButton:pressed{{
                    background-color : rgba({self.pressed_bg_color.red()}, {self.pressed_bg_color.green()}, {self.pressed_bg_color.blue()}, {self.pressed_bg_color.alpha()/255});
                    color : {self.pressed_color.name()};
                }}
            """)
        else:
            self.normal_color = QColor("#004fb7")
            self.hover_color = QColor("#004fb7")  # Same as normal in light mode
            self.pressed_color = QColor("#006eff")
            self.hover_bg_color = QColor(194, 194, 194, 255)  # #e5e5e5 with alpha
            self.pressed_bg_color = QColor(205, 205, 205, 255)  # #d3d3d3 with alpha
            self.setStyleSheet(f"""
                QPushButton{{
                    background-color : rgba(0,0,0,0);
                    border : 1px solid rgba(0,0,0,0);
                    border-radius : {self.border_radiusC}px;
                    color : {self.normal_color.name()};
                }}
                QPushButton:hover{{
                    background-color : rgba({self.hover_bg_color.red()}, {self.hover_bg_color.green()}, {self.hover_bg_color.blue()}, {self.hover_bg_color.alpha()/255});
                    color : {self.hover_color.name()};

                }}
                QPushButton:pressed{{
                    background-color : rgba({self.pressed_bg_color.red()}, {self.pressed_bg_color.green()}, {self.pressed_bg_color.blue()}, {self.pressed_bg_color.alpha()/255});
                    color : {self.pressed_color.name()};
                }}
            """)

