import os

# 获取当前脚本所在目录
current_dir = os.path.dirname(os.path.abspath(__file__))

# 列出所有文件夹
folders = [f for f in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, f))]


class Module:

    def module_list():
        print("同级目录下的文件夹:")
        for folder in folders:
            print(folder)