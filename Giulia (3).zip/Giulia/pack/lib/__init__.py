import re
def modify_txt_after_character(file_path, target_char, new_content, insert_mode=True):
    """
    在TXT文件中指定字符后修改或插入内容
    
    参数:
    file_path (str): 文件路径
    target_char (str): 目标字符
    new_content (str): 要插入或替换的新内容
    insert_mode (bool): 插入模式(True)或替换模式(False)
    """
    try:
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # 找到所有目标字符的位置
        modified_content = []
        index = 0
        content_length = len(content)
        
        while index < content_length:
            # 查找下一个目标字符
            char_index = content.find(target_char, index)
            
            if char_index == -1:
                # 没有找到更多目标字符，添加剩余内容
                modified_content.append(content[index:])
                break
            
            # 添加目标字符之前的内容
            modified_content.append(content[index:char_index + 1])
            
            if insert_mode:
                # 插入模式：在目标字符后添加新内容
                modified_content.append(new_content)
                index = char_index + 1
            else:
                # 替换模式：用新内容替换目标字符后的内容直到下一个目标字符
                next_index = content.find(target_char, char_index + 1)
                if next_index == -1:
                    modified_content.append(new_content)
                    index = content_length
                else:
                    modified_content.append(new_content)
                    index = next_index
        
        # 合并修改后的内容
        final_content = ''.join(modified_content)
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(final_content)
        
        print(f"文件已成功修改: {file_path}")
        return True
        
    except FileNotFoundError:
        print(f"错误: 文件 '{file_path}' 未找到")
        return False
    except Exception as e:
        print(f"修改文件时发生错误: {str(e)}")
        return False


def add_text_after_specific_line(file_path, target_text, text_to_add):
    """
    在文件中找到指定文本所在行，并在其后添加内容
    
    参数:
    file_path (str): 文件路径
    target_text (str): 要查找的目标文本
    text_to_add (str): 要添加的文本
    """
    try:
        # 读取文件所有行
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        
        # 查找目标文本所在行并添加内容
        modified = False
        for i, line in enumerate(lines):
            if target_text in line:
                # 在找到的行后面添加新内容
                # 这里使用line.endswith()检查是否已包含等号和空格，避免重复添加
                if line.strip().endswith('='):
                    # 如果行以=结尾，直接添加文本
                    lines[i] = line.rstrip('\n') + ' ' + text_to_add + '\n'
                else:
                    # 否则在目标文本后添加
                    lines[i] = line.replace(target_text, target_text + text_to_add)
                modified = True
                break  # 只处理第一个匹配项
        
        if not modified:
            print(f"未找到目标文本: {target_text}")
            return False
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(lines)
        
        print(f"已在文件 '{file_path}' 中成功添加内容")
        return True
        
    except FileNotFoundError:
        print(f"错误: 文件 '{file_path}' 未找到")
        return False
    except Exception as e:
        print(f"处理文件时发生错误: {str(e)}")
        return False


def replace_text_in_file(file_path, old_text, new_text, replace_all=True, case_sensitive=True):
    """
    在文件中替换指定文本
    
    参数:
    file_path (str): 文件路径
    old_text (str): 要被替换的旧文本
    new_text (str): 用于替换的新文本
    replace_all (bool): 是否替换所有匹配项，默认为True
    case_sensitive (bool): 是否区分大小写，默认为True
    """
    try:
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # 处理不区分大小写的情况
        modified_content = content
        if not case_sensitive:
            # 构建替换正则表达式
            import re
            if replace_all:
                modified_content = re.sub(re.escape(old_text), new_text, content, flags=re.IGNORECASE)
            else:
                modified_content = re.sub(re.escape(old_text), new_text, content, count=1, flags=re.IGNORECASE)
        else:
            # 区分大小写的替换
            if replace_all:
                modified_content = content.replace(old_text, new_text)
            else:
                modified_content = content.replace(old_text, new_text, 1)
        
        # 检查内容是否有变化
        if modified_content == content:
            print(f"未找到需要替换的文本: '{old_text}'")
            return False
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(modified_content)
        
        print(f"文件 '{file_path}' 替换完成")
        return True
        
    except FileNotFoundError:
        print(f"错误: 文件 '{file_path}' 未找到")
        return False
    except Exception as e:
        print(f"处理文件时发生错误: {str(e)}")
        return False


def replace_config_value(file_path, target_config, new_value):
    """
    替换指定配置项后面的内容
    
    参数:
    file_path (str): 文件路径（自定义）
    target_config (str): 目标配置项（自定义，如"AUTOMATICALLY-READ-SERIAL-PORTS"）
    new_value (str): 要设置的新值（自定义）
    """
    try:
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # 构建正则表达式模式，支持配置项前后的空格变化
        # 转义目标配置项中的特殊字符，确保正则匹配正确
        pattern = re.escape(target_config) + r'\s*=\s*.*'
        full_pattern = r'(' + pattern + r')'
        
        # 检查是否有匹配项
        if not re.search(pattern, content):
            print(f"未找到配置项: {target_config}")
            return False
        
        # 执行替换：保留配置项名称和等号，替换后面的内容
        # 使用回调函数确保替换正确
        def replace_match(match):
            # 提取配置项名称部分（包含可能的空格和等号）
            config_part = re.match(re.escape(target_config) + r'\s*=\s*', match.group(0)).group(0)
            return config_part + new_value
        
        modified_content = re.sub(pattern, replace_match, content)
        
        # 验证是否真的发生了更改
        if modified_content == content:
            print("未进行任何更改，可能新值与原值相同")
            return False
        
        # 写回文件
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(modified_content)
        
        print(f"成功更新配置项: {target_config}")
        print(f"文件路径: {file_path}")
        print(f"新值: {new_value}")
        return True
        
    except FileNotFoundError:
        print(f"错误: 文件 '{file_path}' 未找到，请检查路径是否正确")
        return False
    except Exception as e:
        print(f"处理文件时发生错误: {str(e)}")
        return False


# 使用示例 - 所有变量均可自定义
def create_or_overwrite_file(file_path, content, encoding='utf-8'):
    """
    创建新文件或重写已有文件的内容
    
    参数:
    file_path (str): 文件路径
    content (str): 要写入的内容
    encoding (str): 文件编码格式，默认为'utf-8'
    
    返回:
    bool: 操作是否成功
    """
    try:
        # 使用'w'模式打开文件：如果文件不存在则创建，如果存在则清空内容后写入新内容
        with open(file_path, 'w', encoding=encoding) as file:
            file.write(content)
        
        print(f"文件操作成功: {file_path}")
        return True
        
    except PermissionError:
        print(f"错误: 没有权限操作文件 '{file_path}'")
        return False
    except IsADirectoryError:
        print(f"错误: '{file_path}' 是一个目录，不是文件")
        return False
    except Exception as e:
        print(f"操作文件时发生错误: {str(e)}")
        return False



import pkg_resources

def list_packages_pkg_resources(format_type='list'):
    """
    使用 pkg_resources 列出所有包
    format_type: 'list'返回列表, 'dict'返回字典
    """
    try:
        packages = {pkg.key: pkg.version for pkg in pkg_resources.working_set}
        sorted_packages = dict(sorted(packages.items()))
        
        if format_type == 'dict':
            return sorted_packages
        elif format_type == 'list':
            # 返回包名列表和版本列表
            names = list(sorted_packages.keys())
            versions = list(sorted_packages.values())
            return names, versions
        else:
            return sorted_packages
            
    except Exception as e:
        print(f"错误: {e}")
        return [], [] if format_type == 'list' else {}


import subprocess
import sys
import threading

def run_python_file_with_realtime_output(file_path):
    """运行 Python 文件并实时捕获输出"""
    
    def read_output(pipe, output_type):
        """读取输出流的线程函数"""
        for line in iter(pipe.readline, ''):
            if output_type == 'stdout':
                print(f"[STDOUT] {line}", end='')
            else:
                print(f"[STDERR] {line}", end='')
        pipe.close()
    
    try:
        # 启动进程
        process = subprocess.Popen(
            [sys.executable, file_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding='utf-8',
            bufsize=1,  # 行缓冲
            universal_newlines=True
        )
        
        # 创建线程来读取输出
        stdout_thread = threading.Thread(
            target=read_output, 
            args=(process.stdout, 'stdout')
        )
        stderr_thread = threading.Thread(
            target=read_output, 
            args=(process.stderr, 'stderr')
        )
        
        stdout_thread.start()
        stderr_thread.start()
        
        # 等待进程结束
        return_code = process.wait()
        
        # 等待输出线程结束
        stdout_thread.join()
        stderr_thread.join()
        
        print(f"\n程序执行完成，退出码: {return_code}")
        return return_code
        
    except FileNotFoundError:
        print(f"错误: 文件 {file_path} 未找到")
        return 1
    except Exception as e:
        print(f"运行错误: {e}")
        return 1

# 使用示例
if __name__ == "__main__":
    file_to_run = r"C:\Users\Administrator\Downloads\deepseek_python_20250823_9c9203.py"
    run_python_file_with_realtime_output(file_to_run)