from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.window import *
from pack.lib.module.gui.button import *
from pack.lib.module.gui.widget import *
from pack.lib.module.gui.frame import *
from pack.lib.module.gui.DropDownButton import *
from pack.lib.module.gui.comboBox import *
from pack.lib.module.gui.textedit import *
from pack.lib.module.gui.button import TolButton
from pack.lib.module.gui.window import *
from pack.lib.module.gui.MdiSubWindow import *
import sys

class StyleWindows(PopupWidget):
    def __init__(self, parent,title : str = "Giulia"):
        super().__init__(parent)
        Shadow.Show(self,color=Qt.black,r=3)
        self.title = title
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.__init_gui__()
        self.setMinimumSize(310,210)
    def resize(self,width,height):
        self.resize(width,height)

    def __init_gui__(self):


        self.layoutc = QVBoxLayout(self)
        self.layoutc.setContentsMargins(0,0,0,0)
        self.layoutc.setSpacing(0)
        self.layoutc.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        self.bar = FrameC(border_radius=0)
        self.bar.setFixedHeight(33)

        # add Layout of self.bar

        self.bar_button = QHBoxLayout(self.bar)
        self.bar_button.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.bar_button.setSpacing(0)
        self.bar_button.setContentsMargins(5,0,5,0)

        exit_button_style = [
            [QColor("#262626"),
             QColor("#262626"),
             QColor("#262626"),
             QColor("#c43f3f"),
             QColor("#ffffff"),
             QColor("#c21717")],
            [QColor("#FFFFFF") ,
            QColor("#C9C9C9") ,
            QColor("#BEBEBE") ,
            QColor("#c43f3f") ,
            QColor("#000000") ,
            QColor("#c21717") ] 

        ]

        self.titlebar = QLabel(str(self.title))

        self.button = StyleButton("x",None,border_width=0,style=exit_button_style)
        self.button.setFixedSize(30,30)
        self.button.clicked.connect(sys.exit)
        self.bar_button.addWidget(self.titlebar)
        self.bar_button.addStretch()
        self.bar_button.addWidget(self.button)
        main_widget = Widget(None)
        Shadow.Show(main_widget,color=Qt.black,r=10)

        self.layoutc.addWidget(self.bar)
        self.layoutc.addWidget(main_widget)


app = QApplication([])

window = StyleWindows(None)
window.show()

app.exec()