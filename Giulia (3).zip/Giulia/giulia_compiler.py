from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *
import sys
import os

# 添加路径
sys.path.append(os.path.dirname(__file__))

try:
    from pack.compile.giulia_interpreter import compile_giulia
except ImportError as e:
    print(f"导入错误: {e}")
    # 备用实现
    def compile_giulia(code):
        return f"Giulia编译器\n代码:\n{code}\n\n输出:\nHello, Giulia!"

from pack.compile.giulia_parser import parser
from pack.compile.giulia_interpreter import GiuliaInterpreter

class GiuliaCompilerTab:
    """Giulia 编译器符号表"""
    
    def __init__(self):
        self.symbols = {}
        self.parent = None
    
    def set(self, name, value):
        self.symbols[name] = value
    
    def get(self, name):
        value = self.symbols.get(name)
        if value is None and self.parent:
            return self.parent.get(name)
        return value
    
    def create_child_scope(self):
        child = GiuliaCompilerTab()
        child.parent = self
        return child

class GiuliaCompiler:
    def __init__(self):
        self.compiler_tab = GiuliaCompilerTab()
        self.interpreter = GiuliaInterpreter()
    
    def compile(self, code):
        """编译Giulia代码"""
        try:
            # 语法分析
            ast = parser.parse(code)
            
            if ast is None:
                return "语法分析失败"
            
            # 解释执行
            output, errors = self.interpreter.interpret(code)
            
            if errors:
                return errors
            else:
                return output if output else "执行完成（无输出）"
                
        except Exception as e:
            return f"编译错误: {str(e)}"

# 简化接口函数
def compile_giulia(code):
    compiler = GiuliaCompiler()
    return compiler.compile(code)

def run_giulia_code(code):
    return compile_giulia(code)

class GiuliaCodeEditor(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFont(QFont("Consolas", 11))
        
    def keyPressEvent(self, event):
        # 简单的自动缩进
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            cursor = self.textCursor()
            current_line = cursor.block().text()
            indent = len(current_line) - len(current_line.lstrip())
            super().keyPressEvent(event)
            cursor.insertText(' ' * indent)
        else:
            super().keyPressEvent(event)

class GiuliaCompilerWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # 代码编辑器和输出
        splitter = QSplitter(Qt.Vertical)
        
        self.editor = GiuliaCodeEditor()
        self.editor.setPlainText("""// Giulia 语言示例
function main() {
    print("Hello, Giulia!");
    
    a = 10
    b = 20
    result = a + b
    print("10 + 20 = " + result)
    
    if (result > 25) {
        print("结果大于25")
    } else {
        print("结果小于等于25")
    }
}

main()
""")
        
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Consolas", 10))
        
        splitter.addWidget(self.editor)
        splitter.addWidget(self.output)
        splitter.setSizes([400, 200])
        
        layout.addWidget(splitter)
    
    def run_code(self):
        code = self.editor.toPlainText()
        try:
            result = compile_giulia(code)
            self.output.setPlainText(str(">>>")+result)
        except Exception as e:
            self.output.setPlainText(f"执行错误: {str(e)}")
    
    def clear_all(self):
        self.editor.clear()
        self.output.clear()

def create_compiler_tab():
    """创建编译器标签页"""
    return GiuliaCompilerWidget()

def addCompilerTab(self):
    """添加Giulia编译器标签页"""
    compiler_tab = create_compiler_tab()
    self.Tab_widget.addTab(compiler_tab, "Giulia编译器")

def modifyFileMenu(self):
    """修改文件菜单，添加编译器选项"""
    self.file.addSeparator()
    self.file.addButton("打开Giulia编译器", onClick=self.addCompilerTab)