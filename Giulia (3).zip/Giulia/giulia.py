from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.window import *
from pack.lib.module.gui.button import *
from pack.lib.module.gui.widget import *
from pack.lib.module.gui.frame import *
from pack.lib.module.gui.DropDownButton import *
from pack.lib.module.gui.comboBox import *
from pack.lib.module.gui.textedit import *
from pack.lib.module.gui.button import TolButton
from pack.lib.module.gui.window import *

import sys
import os

# 动态导入编译器模块
try:
    from giulia_compiler import GiuliaCompilerTab, addCompilerTab, modifyFileMenu
except ImportError as e:
    print(f"编译器导入错误: {e}")
    # 创建备用函数
    def addCompilerTab(self):
        print("编译器功能暂不可用")
    
    def modifyFileMenu(self):
        pass
    
    class GiuliaCompilerTab(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            label = QLabel("Giulia编译器暂不可用")
            layout = QVBoxLayout(self)
            layout.addWidget(label)

class MainApp(MainWindow):
    def __init__(self, parent=None, title="MainWindow", width=800, height=600):
        super().__init__(parent, title, width, height)
        
        self.widget = QWidget(None)
        self.setCentralWidget(self.widget)
        
        self.__init_gui__()
    
    def update_colors(self):
        palette = QApplication.palette()
        is_dark = palette.window().color().lightness() < 128
        
        if is_dark:
            self._default_color = QColor("#262626")
            self._border_color = QColor("#2E2E2E")
            self._top_border_color = QColor("#424242")
            self._hover_color = QColor("#424242")
            self._pressed_color = QColor("#5A5A5A")
            self._text_color = QColor("#FFFFFF")

            style_sheet = f"""
            QTabWidget::pane {{
                border: 1px solid #505050;
                background-color: #121212;
            }}
            
            QTabWidget::tab-bar {{
                alignment: left;
            }}
            
            QTabBar::tab {{
                background-color: #333333;
                border: 0px solid #505050;
                padding: 6px 10px;
                margin-right: 2px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }}
            
            QTabBar::tab:selected {{
                color : white;

                background-color: #0061ab;
                border-bottom-color: #0061ab;
            }}
            
            QTabBar::tab:hover:!selected {{
                background-color: #4b4b4b;
            }}

            
            QPushButton {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: 3px;
                padding : 3px 8px;
            }}
            QPushButton:hover {{
                background-color : {self._hover_color.name()};

                border-top: 1px solid {self._top_border_color.name()};
            }}
            QPushButton:pressed {{
                background-color : {self._pressed_color.name()};
            
                border-top: 1px solid {self._top_border_color.name()};
            }}
            QPushButton:focus {{
                color : black;
                background-color : #0084ff;
            }}
            """
            QApplication.instance().setStyleSheet(style_sheet)
        else:
            self._default_color = QColor("#FFFFFF")
            self._border_color = QColor("#C9C9C9")
            self._top_border_color = QColor("#BEBEBE")
            self._hover_color = QColor("#DADADA")
            self._pressed_color = QColor("#B9B9B9")
            self._text_color = QColor("#000000")
            style_sheet = f"""
            QTabWidget::pane {{
                border: 1px solid #dcdcdc;
                background-color: #f0f0f0;
            }}
            
            QTabWidget::tab-bar {{
                alignment: left;
            }}
            
            QTabBar::tab {{
                background-color: #f0f0f0;
                border: 0px solid #f0f0f0;
                padding: 6px 10px;
                margin-right: 2px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }}
            
            QTabBar::tab:selected {{
                color : white;
                background-color: #0091ff;
                border-bottom-color: #0091ff;
            }}
            
            QTabBar::tab:hover:!selected {{
                background-color: #c2c2c2;
            }}
            QPushButton {{
                background-color: {self._default_color.name()};
                border: 1px solid {self._border_color.name()};
                border-top: 1px solid {self._top_border_color.name()};
                color: {self._text_color.name()};
                border-radius: 3px;
                padding : 3px 8px;
            }}
            QPushButton:hover {{
                background-color : {self._hover_color.name()};

                border-top: 1px solid {self._top_border_color.name()};
            }}
            QPushButton:pressed {{
                background-color : {self._pressed_color.name()};
            
                border-top: 1px solid {self._top_border_color.name()};
            }}
            QPushButton:focus {{
                background-color : #0084ff;
                color : white;
            }}
            """
            QApplication.instance().setStyleSheet(style_sheet)
        return super().update_colors()

    def __init_gui__(self):
        self.widget = Widget(self)
        self.setCentralWidget(self.widget)

        self.layoutc = QVBoxLayout(self.widget)
        self.layoutc.setContentsMargins(0,0,0,0)
        self.layoutc.setSpacing(0)
        self.layoutc.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.widget.setLayout(self.layoutc)

        self.menuBarc = FrameC(None, border_radius=0)
        self.menuBarc.setFixedHeight(40)
        self.menuBarc_layout = QHBoxLayout(self.menuBarc)
        self.menuBarc_layout.setContentsMargins(5,0,5,0)
        self.menuBarc_layout.setSpacing(0)
        self.menuBarc_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        self.file = DropDownButton(Content="文件", border_radius=3, border_width=0, List_Widget_Width=150, List_Widget_Height=300)
        self.file.setFixedSize(40,30)
        self.file.addButton("打开文件",onClick=self.addNewFileTab)
        self.file.addButton("创建文件",onClick=self.addNewFileTab)
        self.file.addSeparator()
        self.file.addButton("保存")
        self.file.addButton("另存为")
        self.file.addButton("全部保存")
        self.file.addSeparator()
        self.file.addButton("新建窗口")
        self.file.addButton("关闭窗口",onClick=self.deleteLater)
        self.file.addSeparator()
        self.file.addButton("创建新选项卡", self.addHelloTab)                
        self.file.addSeparator()
        self.file.addButton("打开Giulia编译器", self.addCompilerTab)  # 添加编译器选项
        self.file.addSeparator()
        self.file.addButton("退出", onClick=self.deleteLater)

        self.finda = DropDownButton("查找", None, border_radius=3, border_width=0, List_Widget_Width=120, List_Widget_Height=150)
        self.finda.setFixedSize(40,30)
        self.finda.addButton("字符段查找")
        self.finda.addButton("方法查找")
        self.finda.addButton("类查找")
        self.finda.addSeparator()
        self.finda.addButton("设置", self.gexhua)
        self.finda.addSeparator()
        self.finda.addButton("删除", self.finda.deleteLater)

        self.View = DropDownButton("查看", None, border_radius=3, border_width=0, List_Widget_Width=100, List_Widget_Height=65)
        self.View.setFixedSize(40,30)
        self.View.addButton("外观", self.ViewC)
        self.View.addSeparator()
        self.View.addButton("删除", self.View.deleteLater)

        self.Com = DropDownButton("终端", None, border_radius=3, border_width=0, List_Widget_Width=150, List_Widget_Height=95)
        self.Com.setFixedSize(40,30)
        self.Com.addButton("新建终端")
        self.Com.addButton("正在运行中的终端")
        self.Com.addSeparator()
        self.Com.addButton("删除", self.Com.deleteLater)

        self.help = DropDownButton("帮助", None, border_radius=3, border_width=0, List_Widget_Width=150, List_Widget_Height=95, Direction="left")
        self.help.setFixedSize(40,30)
        self.help.addButton("检查更新")
        self.help.addSeparator()
        self.help.addButton("关于Giulia IDE")
        self.help.addSeparator()
        self.help.addButton("版本 : 0.9.23.25")

        self.file_list = DropDownButton("曾经打开的文件", None, border_radius=3, border_width=0, List_Widget_Height=250, List_Widget_Width=160)
        self.file_list.setFixedSize(100,30)
        self.file_list.addButton("无")
        self.file_list.addSeparator()
        self.file_list.addButton("删除", self.file_list.deleteLater)

        self.menuBarc_layout.addWidget(self.file)
        self.menuBarc_layout.addWidget(self.finda)
        self.menuBarc_layout.addWidget(self.View)
        self.menuBarc_layout.addWidget(self.Com)
        self.menuBarc_layout.addWidget(self.file_list)
        self.menuBarc_layout.addStretch()
        self.menuBarc_layout.addWidget(self.help)

        # IDE
        IDE_widget = QWidget()
        self.layout_IDE = QVBoxLayout(IDE_widget)
        self.layout_IDE.setContentsMargins(0,0,0,0)
        self.layout_IDE.setSpacing(0)
        self.layout_IDE.setAlignment(Qt.AlignmentFlag.AlignTop)

        self.Tab_widget = QTabWidget()
        self.Tab_widget.setMovable(True)
        self.Tab_widget.setTabShape(QTabWidget.Rounded)
        self.Tab_widget.setTabPosition(QTabWidget.North)
        self.Tab_widget.setTabsClosable(True)
        self.Tab_widget.tabCloseRequested.connect(self.on_tab_close_requested)
        self.layout_IDE.addWidget(self.Tab_widget)

        self.addHelloTab()

        self.layoutc.addWidget(self.menuBarc)
        self.layoutc.addWidget(IDE_widget)

    def addCompilerTab(self):
        """添加Giulia编译器标签页"""
        try:
            from giulia_compiler import create_compiler_tab
            compiler_tab = create_compiler_tab()
            self.Tab_widget.addTab(compiler_tab, "Giulia编译器")
        except ImportError as e:
            # 创建简单的错误标签页
            error_widget = QWidget()
            layout = QVBoxLayout(error_widget)
            label = QLabel("Giulia编译器加载失败\n错误信息: " + str(e))
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(label)
            self.Tab_widget.addTab(error_widget, "Giulia编译器")
    
    def addHelloTab(self):
        widget = QWidget()
        layoutc = QVBoxLayout(widget)
        layoutc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layoutc.setContentsMargins(0,0,0,0)
        layoutc.setSpacing(15)
        
        newFile = Button("创建新文件", None, shadow=True)
        openfile = Button("打开文件", None, shadow=True)
        compilerBtn = Button("打开Giulia编译器", None, shadow=True)
        
        def event_new_file():
            widget.deleteLater()
            self.addNewFileTab()
        
        def event_compiler():
            widget.deleteLater()
            self.addCompilerTab()
        
        newFile.clicked.connect(event_new_file)
        openfile.clicked.connect(event_new_file)
        compilerBtn.clicked.connect(event_compiler)
        
        newFile.setFixedSize(180,40)
        openfile.setFixedSize(180,40)
        compilerBtn.setFixedSize(180,40)
        
        layoutc.addWidget(newFile)
        layoutc.addWidget(openfile)
        layoutc.addWidget(compilerBtn)
        
        self.Tab_widget.addTab(widget, "欢迎")

    def on_tab_close_requested(self, index):
        """关闭标签页请求"""
        reply = QMessageBox.question(self, "确认关闭", 
                                   "确定要关闭这个标签页吗？",
                                   QMessageBox.Yes | QMessageBox.No)
        
        if reply == QMessageBox.Yes:
            self.Tab_widget.removeTab(index)

    def ViewC(self):
        widget = QWidget()
        layoutc = QHBoxLayout(widget)
        layoutc.setContentsMargins(0,0,0,0)
        layoutc.setSpacing(0)
        layoutc.setAlignment(Qt.AlignmentFlag.AlignLeft)
        
        Menu_bar = FrameC(None, border_radius=0)
        Menu_bar.setFixedWidth(190)
        MenuBar_Layoutc = QVBoxLayout(Menu_bar)
        MenuBar_Layoutc.setAlignment(Qt.AlignmentFlag.AlignTop)
        MenuBar_Layoutc.setContentsMargins(5,5,5,5)
        
        windows = Button("   窗口设置", border_width=0, shadow=True, text_alignment='left')
        windows.setFixedHeight(30)
        Font = Button("   字体设置", border_width=0, shadow=True, text_alignment='left')
        Font.setFixedHeight(30)
        GUi = Button("   用户界面设置", border_width=0, shadow=True, text_alignment='left')
        GUi.setFixedHeight(30)

        MenuBar_Layoutc.addWidget(windows)
        MenuBar_Layoutc.addWidget(Font)
        MenuBar_Layoutc.addWidget(GUi)
        
        layoutc.addWidget(Menu_bar)
        self.Tab_widget.addTab(widget, "外观")

    def gexhua(self):
        self.windowc = QDialog(self)
        pos = self.finda.mapToGlobal(QPoint(50,55))
        self.windowc.resize(350,120)
        self.windowc.move(pos)
        self.windowc.show()

    def addNewFileTab(self):

        widget = QWidget()
        layoutc = QVBoxLayout(widget)
        layoutc.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignCenter)
        layoutc.setContentsMargins(0,0,0,0)
        layoutc.setSpacing(0)

        menubar = FrameC(border_radius=0)
        menubar.setFixedHeight(35)

        newFile = PlainTextEdit(None)
        newFile.setFont(QFont("Consolas",13))
        newFile.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        layoutc.addWidget(menubar, 0)
        layoutc.addWidget(newFile, 1)
        self.Tab_widget.addTab(widget, "新文件")
    
    def paintEvent(self, event):
        return super().paintEvent(event)

if __name__ == "__main__":
    app = QApplication([])
    window = MainApp(title="Giulia IDE", width=1000, height=700)
    window.show()
    app.exec()