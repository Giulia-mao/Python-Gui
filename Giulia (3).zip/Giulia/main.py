if __name__ == "__main__":
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r') as f:
            code = f.read()
        run_giulia_code(code)
    else:
        # 示例代码
        sample_code = """
        // 基本变量和函数
        function greet(name) {
            return "Hello, " + name + "!";
        }
        
        // 控制流
        if (true) {
            print(greet("Giulia"));
        }
        
        // 数组操作
        array numbers = [1, 2, 3, 4, 5];
        print(numbers);
        print(len(numbers));
        """
        
        run_giulia_code(sample_code)