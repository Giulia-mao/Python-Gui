# 测试代码
from pack.compile.giulia_interpreter import compile_giulia

# 测试函数定义和调用
code = '''
var i = 0;
while (i < 3) {
  print("Count: " + i);
  i = i + 1;
}
'''


result = compile_giulia(code)
print("结果:", result)
