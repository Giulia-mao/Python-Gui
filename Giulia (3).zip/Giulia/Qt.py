from pack.lib.module.gui.button import *
from pack.lib.module.gui.window import *
from pack.lib.module.gui.QtPack import *
from pack.lib.module.gui.label import *
from pack.lib.module.gui.DropDownButton import *

class BlurWidget(QWidget):
    def __init__ (self, parent : QWidget = None):
        super().__init__(parent)

        


class MainWindow(MainWindow):
    def __init__(self, parent = None, title = "MainWindow", width = 800, height = 600):
        super().__init__(parent, title, width, height)

        self.__init_gui__()
    def __init_gui__(self):
        self.Button = DropDownButton("你好世界",self)
        self.Button.setGeometry(50,50,150,30)

if __name__ == "__main__":
    app = QApplication([])
    app.setAttribute(Qt.AA_UseSoftwareOpenGL, False)

    window = MainWindow()
    window.show()

    app.exec()